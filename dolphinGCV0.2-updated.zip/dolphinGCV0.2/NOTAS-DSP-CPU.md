# Notas Técnicas de Desempenho — PlayStation 3 (Cell PPU & SPU)

## 1. Desempenho do CPU (Cell PPU + AltiVec + LTO)
- **Arquitetura Alvo:** PowerPC 64-bit Cell Broadband Engine (`-mcpu=cell -maltivec -mabi=altivec -O3 -flto`)
- **Endianness:** Big-Endian nativo (compatível diretamente com a arquitetura Broadway/Gekko do Wii/GameCube).
- **FPS Médio (Menu XMB / UI):** 60 FPS
- **FPS Médio (In-Game):** _[Preencher após testes nos jogos]_

## 2. Comportamento do DSP (Offload para SPU)
- **Modo de Execução:** Processamento de áudio desacoplado da PPU e enviado para uma **SPU** dedicada (`DSP_OFFLOAD_SPU=1`).
- **Taxa de Amostragem:** `48000 Hz` (nativa do hardware de áudio do PS3 via `libaudio`).
- **Ajustes Aplicados:** `AUDIO_STRETCHING=1` ativo para evitar cortes de som caso o RSX sofra quedas de frame.

## 3. Recomendações de Uso no PS3
- **Resolução de Saída:** Configurar o PS3 em **720p (1280x720)** para aliviar a largura de banda de memória do RSX (256 MB VRAM).
- **Armazenamento:** Preferir o **HDD interno** (`/dev_hdd0/game/DOLPHINGC/USRDIR/DolphinGC/`) em vez da porta USB 2.0 para evitar engasgos durante o streaming.
- **Formatos Recomendados:** `.gcm` ou `.wbfs` não fragmentados.
