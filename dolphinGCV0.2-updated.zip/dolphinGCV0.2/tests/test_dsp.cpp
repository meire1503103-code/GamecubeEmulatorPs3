// Testes da interface do DSP (mailbox, DSP_CONTROL, DMA da ARAM, AI DMA) ligada ao MMIO.
// Todos os testes sao SIMULADOS (nao ha microcodigo de DSP real nem ISO envolvida).
#include "check.h"
#include "memory.h"
#include "mmio.h"
#include "system.h"

#include <cstdio>
#include <string>
#include <vector>

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;

struct Rig {
  Memory mem; MmioHandler hw;
  bool Init() {
    std::string e;
    if (!mem.Init(e)) return false;
    mem.SetMmio(&hw);
    hw.Attach(&mem, nullptr);
    return true;
  }
  uint32_t R(uint32_t off, unsigned size) { uint32_t v = 0xDEADBEEF; mem.Read(0xCC005000u + off, size, v); return v; }
  void W(uint32_t off, unsigned size, uint32_t v) { mem.Write(0xCC005000u + off, size, v); }
  uint32_t Pi() { uint32_t v = 0; mem.Read(0xCC003000u, 4, v); return v; }
};

struct EchoHle : DspHle {
  int resets = 0, asserts = 0; std::vector<uint32_t> mails;
  void OnReset(DspInterface&) override { ++resets; }
  void OnMail(DspInterface& d, uint32_t m) override { mails.push_back(m); d.PostMailToCpu(m ^ 0xFFFF, true); }
  void OnAssertInt(DspInterface&) override { ++asserts; }
};

void TestMailbox() {
  std::printf("[SIM] DSP: mailbox inicial 0x8071FEED e consumo ao ler a metade baixa\n");
  Rig r; CHECK(r.Init());
  CHECK(r.R(0x04, 2) == 0x8071u);                  // HI com bit 15 (valido)
  CHECK(r.R(0x06, 2) == 0xFEEDu);                  // ler LO consome
  CHECK((r.R(0x04, 2) & 0x8000u) == 0);            // valido limpo
  r.hw.Reset();
  CHECK(r.R(0x04, 4) == 0x8071FEEDu);              // leitura de 32 bits devolve o mail inteiro
  CHECK((r.R(0x04, 2) & 0x8000u) == 0);            // ...e consome
}

void TestMailToDsp() {
  std::printf("[SIM] DSP: mail CPU->DSP entregue ao gancho HLE (16 e 32 bits)\n");
  Rig r; CHECK(r.Init());
  EchoHle h; r.hw.dsp().SetHle(&h);
  r.W(0x00, 2, 0x1234); r.W(0x02, 2, 0x5678);
  CHECK(h.mails.size() == 1 && h.mails[0] == 0x12345678u);
  CHECK((r.R(0x00, 2) & 0x8000u) == 0);            // consumido: o CPU nao fica preso no poll
  r.W(0x00, 4, 0x00A1B2C3u);
  CHECK(h.mails.size() == 2 && h.mails[1] == 0x00A1B2C3u);
  CHECK(r.hw.dsp().mails_from_cpu() == 2);
  // Resposta do HLE: valido + interrupcao DSPINT (mascara desligada => sem PI).
  CHECK((r.R(0x04, 2) & 0x8000u) != 0);
  CHECK((r.R(0x0A, 2) & DSPCR_DSPINT) != 0);
  CHECK((r.Pi() & PI_INT_DSP) == 0);
  // Sem HLE o mail e apenas descartado.
  Rig r2; CHECK(r2.Init());
  r2.W(0x00, 4, 0x11112222u);
  CHECK(r2.hw.dsp().mails_from_cpu() == 1);
}

void TestControlInterrupts() {
  std::printf("[SIM] DSP: DSP_CONTROL (escrever 1 limpa, mascaras, linha de PI, reset, assert)\n");
  Rig r; CHECK(r.Init());
  EchoHle h; r.hw.dsp().SetHle(&h);
  r.W(0x00, 4, 0x00000001u);                       // HLE responde e levanta DSPINT
  CHECK((r.Pi() & PI_INT_DSP) == 0);
  r.W(0x0A, 2, DSPCR_DSPINT_MASK | DSPCR_DSPINT);  // liga a mascara e escreve 1 em DSPINT (limpa a flag)
  // Reenvia um mail para o HLE levantar a flag de novo (agora com a mascara ligada).
  CHECK((r.R(0x0A, 2) & DSPCR_DSPINT) == 0);
  r.W(0x00, 4, 0x00000002u);
  CHECK((r.R(0x0A, 2) & DSPCR_DSPINT) != 0);
  CHECK((r.Pi() & PI_INT_DSP) != 0);               // flag & mascara => PI bit 6
  CHECK(r.hw.InterruptPending() == false);         // PI_INTMSR ainda zero
  r.mem.Write(0xCC003004u, 4, PI_INT_DSP);
  CHECK(r.hw.InterruptPending() == true);
  r.W(0x0A, 2, DSPCR_DSPINT_MASK | DSPCR_DSPINT);  // limpa
  CHECK((r.Pi() & PI_INT_DSP) == 0 && !r.hw.InterruptPending());
  // Reset do DSP: IROM anuncia 0x8071FEED de novo e o gancho e avisado.
  r.R(0x06, 2);
  r.W(0x0A, 2, DSPCR_RESET);
  CHECK(h.resets == 1 && r.R(0x04, 4) == 0x8071FEEDu);
  // DSPAssertInt chama o gancho so na borda de subida.
  r.W(0x0A, 2, DSPCR_ASSERT_INT); r.W(0x0A, 2, DSPCR_ASSERT_INT);
  CHECK(h.asserts == 1);
}

void TestAramDma() {
  std::printf("[SIM] DSP: DMA da ARAM (RAM->ARAM->RAM) + interrupcao ARINT\n");
  Rig r; CHECK(r.Init());
  for (uint32_t i = 0; i < 64; ++i) r.mem.Write(0x80010000u + i, 1, 0x40 + i);
  r.W(0x0A, 2, DSPCR_ARINT_MASK);
  // RAM -> ARAM: MMADDR=0x10000, ARADDR=0x2000, CNT=64 (bit 31 = 0).
  r.W(0x20, 4, 0x00010000u); r.W(0x24, 4, 0x00002000u);
  r.W(0x28, 2, 0x0000); r.W(0x2A, 2, 64);
  CHECK(r.hw.dsp().aram_dmas() == 1 && r.hw.dsp().aram_dma_errors() == 0);
  CHECK((r.R(0x0A, 2) & DSPCR_ARINT) != 0 && (r.Pi() & PI_INT_DSP) != 0);
  uint8_t b[64] = {0};
  CHECK(r.hw.dsp().AramRead(0x2000, b, 64) && b[0] == 0x40 && b[63] == 0x7F);
  // ARAM -> RAM em outro endereco (bit 31 do contador = 1).
  r.W(0x0A, 2, DSPCR_ARINT_MASK | DSPCR_ARINT);    // limpa a flag
  CHECK((r.Pi() & PI_INT_DSP) == 0);
  r.W(0x20, 4, 0x00020000u); r.W(0x24, 4, 0x00002000u);
  r.W(0x28, 2, 0x8000); r.W(0x2A, 2, 64);
  uint32_t v = 0;
  CHECK(r.mem.Read(0x80020000u, 4, v) && v == 0x40414243u);
  CHECK(r.mem.Read(0x8002003Cu, 4, v) && v == 0x7C7D7E7Fu);
  // Erros: ARAM fora do limite nao copia nada e e contado.
  r.W(0x24, 4, 0x00FFFFC0u); r.W(0x28, 2, 0x0000); r.W(0x2A, 2, 128);
  CHECK(r.hw.dsp().aram_dma_errors() == 1);
}

struct Sink { int blocks = 0; uint8_t first = 0; };
void SinkFn(const uint8_t* b, void* u) { Sink* s = static_cast<Sink*>(u); if (s->blocks++ == 0) s->first = b[0]; }

void TestAiDma() {
  std::printf("[SIM] DSP: AI DMA consome blocos de 32 bytes e gera AIINT ao fim do buffer\n");
  Rig r; CHECK(r.Init());
  for (uint32_t i = 0; i < 128; ++i) r.mem.Write(0x80030000u + i, 1, 0x90 + i);
  Sink s; r.hw.dsp().SetAudioSink(SinkFn, &s);
  r.W(0x0A, 2, DSPCR_AIINT_MASK);
  r.W(0x30, 2, 0x0003); r.W(0x32, 2, 0x0000);      // endereco 0x00030000
  r.W(0x36, 2, 0x8000 | 4);                         // liga, 4 blocos
  CHECK(r.R(0x3A, 2) == 4);
  r.hw.Tick(kStepsPerAiBlock * 3);
  CHECK(r.hw.dsp().ai_blocks_played() == 3 && r.R(0x3A, 2) == 1);
  CHECK((r.Pi() & PI_INT_DSP) == 0);
  r.hw.Tick(kStepsPerAiBlock);
  CHECK(r.hw.dsp().ai_blocks_played() == 4);
  CHECK((r.R(0x0A, 2) & DSPCR_AIINT) != 0 && (r.Pi() & PI_INT_DSP) != 0);
  CHECK(s.blocks == 4 && s.first == 0x90);
  CHECK(r.R(0x3A, 2) == 4);                         // recarregou: reproducao continua
  r.W(0x36, 2, 4);                                  // desliga
  r.hw.Tick(kStepsPerAiBlock * 10);
  CHECK(r.hw.dsp().ai_blocks_played() == 4);
}

void TestRunSystemIrq() {
  std::printf("[SIM] DSP: interrupcao do DSP chega a CPU pelo RunSystem (excecao 0x500)\n");
  Memory mem; std::string e; CHECK(mem.Init(e));
  MmioHandler hw; mem.SetMmio(&hw); hw.Attach(&mem, nullptr);
  Cpu cpu(mem); cpu.Reset(0x80003000u);
  for (uint32_t i = 0; i < 0x2000; i += 4) mem.Write(0x80003000u + i, 4, 0x60000000u);  // nops
  mem.Write(0xCC003004u, 4, PI_INT_DSP);
  mem.Write(0xCC00500Au, 2, DSPCR_AIINT_MASK);
  mem.Write(0xCC005030u, 2, 0x0003); mem.Write(0xCC005032u, 2, 0);
  mem.Write(0xCC005036u, 2, 0x8000 | 1);            // 1 bloco => AIINT apos 81000 passos
  cpu.msr = 0x8000u;
  const StopReason r = RunSystem(cpu, hw, 4096ull * 4);
  (void)r;
  CHECK(hw.dsp().ai_blocks_played() == 0 && cpu.last_exception == Exception::None);
  // Perto de um bloco: roda mais ate a interrupcao acontecer.
  uint64_t guard = 0;
  while (cpu.last_exception != Exception::ExternalInterrupt && guard < 40) { cpu.pc = 0x80003000u; RunSystem(cpu, hw, 4096ull * 16); ++guard; }
  CHECK(cpu.last_exception == Exception::ExternalInterrupt);
  CHECK(hw.dsp().ai_blocks_played() >= 1);
}

}  // namespace

int main() {
  TestMailbox();
  TestMailToDsp();
  TestControlInterrupts();
  TestAramDma();
  TestAiDma();
  TestRunSystemIrq();
  std::printf("\n[SIM] test_dsp: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
