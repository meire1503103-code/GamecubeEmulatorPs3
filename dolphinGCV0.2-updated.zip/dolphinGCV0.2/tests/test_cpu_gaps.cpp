// Instrucoes do Gekko que faltavam para rodar codigo de jogos: FP indexado, psq indexado, strings,
// mcrxr, mtfsfi, registradores de segmento, time base gravavel e decrementador (excecao 0x900).
// Todos os testes sao SIMULADOS (codigo montado a mao; nenhum jogo real foi executado).
#include "check.h"
#include "cpu.h"
#include "memory.h"

#include <cmath>
#include <cstdio>
#include <string>

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;
const uint32_t kCode = 0x80003000u, kData = 0x80001000u;

uint32_t X31(uint32_t d, uint32_t a, uint32_t b, uint32_t xo) {
  return (31u << 26) | (d << 21) | (a << 16) | (b << 11) | (xo << 1);
}
uint32_t Mtspr(uint32_t spr, uint32_t rs) { return X31(rs, spr & 31, spr >> 5, 467); }
uint32_t Mfspr(uint32_t spr, uint32_t rd) { return X31(rd, spr & 31, spr >> 5, 339); }
uint32_t Psq(uint32_t xo6, uint32_t d, uint32_t a, uint32_t b, uint32_t w, uint32_t i) {
  return (4u << 26) | (d << 21) | (a << 16) | (b << 11) | (w << 10) | (i << 7) | (xo6 << 1);
}
const uint32_t kNop = 0x60000000u;

struct Rig {
  Memory mem; Cpu cpu;
  Rig() : cpu(mem) { std::string e; mem.Init(e); cpu.Reset(kCode); cpu.msr = 0x2000u; }
  void Put(uint32_t idx, uint32_t inst) { mem.Write(kCode + 4 * idx, 4, inst); }
  StopReason Go(unsigned n) { StopReason r = StopReason::Running; for (unsigned i = 0; i < n && r == StopReason::Running; ++i) r = cpu.Step(); return r; }
};

void TestFpIndexed() {
  std::printf("[SIM] lfsx/lfdx/stfsx/stfdx/stfiwx e formas com update\n");
  Rig t;
  t.mem.Write(kData, 4, 0x40490FDBu);                       // pi em float
  t.mem.Write(kData + 8, 4, 0x400921FBu); t.mem.Write(kData + 12, 4, 0x54442D18u);  // pi em double
  t.cpu.gpr[3] = kData; t.cpu.gpr[4] = 0;
  t.cpu.gpr[5] = 8;
  t.Put(0, X31(1, 3, 4, 535));                              // lfsx f1,r3,r4
  t.Put(1, X31(2, 3, 5, 599));                              // lfdx f2,r3,r5
  CHECK(t.Go(2) == StopReason::Running);
  CHECK(std::fabs(t.cpu.fpr[1] - 3.14159274) < 1e-6);
  CHECK(t.cpu.ps1(1) == t.cpu.ps0(1));                      // lfsx replica em ps1
  CHECK(std::fabs(t.cpu.fpr[2] - 3.141592653589793) < 1e-12);
  // stfsx / stfdx / stfiwx
  t.cpu.gpr[6] = 0x100;
  t.Put(2, X31(1, 3, 6, 663));                              // stfsx f1,r3,r6
  t.Put(3, X31(2, 3, 6, 727));                              // stfdx f2,r3,r6 (sobrescreve 8 bytes)
  CHECK(t.Go(2) == StopReason::Running);
  uint32_t v = 0;
  CHECK(t.mem.Read(kData + 0x100, 4, v) && v == 0x400921FBu);
  CHECK(t.mem.Read(kData + 0x104, 4, v) && v == 0x54442D18u);
  t.cpu.fpr[7] = 0; t.cpu.fpr[7] = 0.0;
  t.Put(4, X31(2, 3, 6, 983));                              // stfiwx f2,r3,r6: palavra baixa de f2
  CHECK(t.Go(1) == StopReason::Running);
  CHECK(t.mem.Read(kData + 0x100, 4, v) && v == 0x54442D18u);
  // update: rA recebe o endereco efetivo
  t.cpu.gpr[3] = kData; t.cpu.gpr[4] = 0;
  t.Put(5, X31(1, 3, 5, 567));                              // lfsux f1,r3,r5
  CHECK(t.Go(1) == StopReason::Running && t.cpu.gpr[3] == kData + 8);
  t.Put(6, X31(1, 0, 5, 567));                              // lfsux com rA = 0: invalida
  CHECK(t.Go(1) == StopReason::Unimplemented);
  // FP indisponivel (MSR[FP] = 0) => excecao 0x800
  Rig u; u.cpu.msr = 0;
  u.cpu.gpr[3] = kData; u.Put(0, X31(1, 3, 4, 535));
  CHECK(u.Go(1) == StopReason::Running && u.cpu.pc == 0x800);
}

void TestLfsFillsPs1() {
  std::printf("[SIM] lfs (D-form) replica o valor em ps0 e ps1\n");
  Rig t;
  t.mem.Write(kData, 4, 0x3FC00000u);                       // 1.5f
  t.cpu.gpr[3] = kData;
  t.Put(0, (48u << 26) | (1u << 21) | (3u << 16));          // lfs f1,0(r3)
  CHECK(t.Go(1) == StopReason::Running);
  CHECK(t.cpu.ps0(1) == 1.5f && t.cpu.ps1(1) == 1.5f);
}

void TestPsqIndexed() {
  std::printf("[SIM] psq_lx / psq_stx / psq_lux / psq_stux\n");
  Rig t;
  // GQR2: carga int16 com escala 0 (tipo 7), gravacao int16 com escala 0
  t.cpu.gpr[10] = (7u << 16) | 7u;
  t.Put(0, Mtspr(914, 10));
  t.mem.Write(kData, 2, 0xFFFE);                            // -2
  t.mem.Write(kData + 2, 2, 5);
  t.cpu.gpr[3] = kData; t.cpu.gpr[4] = 0;
  t.Put(1, Psq(6, 1, 3, 4, 0, 2));                          // psq_lx f1,r3,r4,0,2
  CHECK(t.Go(2) == StopReason::Running);
  CHECK(t.cpu.ps0(1) == -2.0f && t.cpu.ps1(1) == 5.0f);
  // W = 1: so ps0 e ps1 = 1.0
  t.Put(2, Psq(6, 2, 3, 4, 1, 2));
  CHECK(t.Go(1) == StopReason::Running && t.cpu.ps0(2) == -2.0f && t.cpu.ps1(2) == 1.0f);
  // psq_stx guarda os dois valores quantizados
  t.cpu.gpr[5] = 0x40;
  t.cpu.set_ps(6, 100.0f, -7.0f);
  t.Put(3, Psq(7, 6, 3, 5, 0, 2));                          // psq_stx f6,r3,r5,0,2
  CHECK(t.Go(1) == StopReason::Running);
  uint32_t v = 0;
  CHECK(t.mem.Read(kData + 0x40, 2, v) && v == 100u);
  CHECK(t.mem.Read(kData + 0x42, 2, v) && v == 0xFFF9u);
  // formas com update
  t.cpu.gpr[3] = kData; t.cpu.gpr[4] = 0x40;
  t.Put(4, Psq(38, 8, 3, 4, 0, 2));                         // psq_lux f8,r3,r4,0,2
  CHECK(t.Go(1) == StopReason::Running && t.cpu.gpr[3] == kData + 0x40 && t.cpu.ps0(8) == 100.0f && t.cpu.ps1(8) == -7.0f);
  t.cpu.gpr[3] = kData; t.cpu.gpr[4] = 0x80;
  t.Put(5, Psq(39, 8, 3, 4, 0, 2));                         // psq_stux
  CHECK(t.Go(1) == StopReason::Running && t.cpu.gpr[3] == kData + 0x80);
  CHECK(t.mem.Read(kData + 0x80, 2, v) && v == 100u);
  // as formas ps_* existentes continuam resolvendo (ps_add f9 = f6 + f6)
  t.Put(6, (4u << 26) | (9u << 21) | (6u << 16) | (6u << 11) | (21u << 1));
  CHECK(t.Go(1) == StopReason::Running && t.cpu.ps0(9) == 200.0f && t.cpu.ps1(9) == -14.0f);
}

void TestMiscInstructions() {
  std::printf("[SIM] mcrxr, mtfsfi, strings, registradores de segmento, no-ops de TLB\n");
  Rig t;
  t.cpu.xer = 0xE0000000u;                                  // SO | OV | CA
  t.Put(0, X31(5 << 2, 0, 0, 512));                         // mcrxr cr5
  CHECK(t.Go(1) == StopReason::Running);
  CHECK(((t.cpu.cr >> (28 - 4 * 5)) & 0xF) == 0xE && (t.cpu.xer & 0xE0000000u) == 0);
  t.Put(1, (63u << 26) | (3u << 23) | (0xAu << 12) | (134u << 1));   // mtfsfi crf3,0xA
  CHECK(t.Go(1) == StopReason::Running && ((t.cpu.fpscr >> 16) & 0xF) == 0xA);
  // lswi / stswi: 6 bytes
  const char txt[] = "ABCDEFG";
  for (unsigned i = 0; i < 7; ++i) t.mem.Write(kData + i, 1, static_cast<uint8_t>(txt[i]));
  t.cpu.gpr[3] = kData;
  t.Put(2, X31(8, 3, 6, 597));                              // lswi r8,r3,6
  CHECK(t.Go(1) == StopReason::Running);
  CHECK(t.cpu.gpr[8] == 0x41424344u && t.cpu.gpr[9] == 0x45460000u);
  t.cpu.gpr[4] = kData + 0x200;
  t.Put(3, X31(8, 4, 6, 725));                              // stswi r8,r4,6
  CHECK(t.Go(1) == StopReason::Running);
  uint32_t v = 0;
  CHECK(t.mem.Read(kData + 0x200, 4, v) && v == 0x41424344u);
  CHECK(t.mem.Read(kData + 0x204, 2, v) && v == 0x4546u);
  // lswx com contagem no XER
  t.cpu.xer = 3; t.cpu.gpr[3] = kData; t.cpu.gpr[4] = 0;
  t.Put(4, X31(12, 3, 4, 533));                             // lswx r12,r3,r4
  CHECK(t.Go(1) == StopReason::Running && t.cpu.gpr[12] == 0x41424300u);
  // mtsr / mfsr / mtsrin / mfsrin
  t.cpu.gpr[13] = 0x00ABCDEFu;
  t.Put(5, X31(13, 7, 0, 210));                             // mtsr 7,r13
  t.Put(6, X31(14, 7, 0, 595));                             // mfsr r14,7
  CHECK(t.Go(2) == StopReason::Running && t.cpu.gpr[14] == 0x00ABCDEFu);
  t.cpu.gpr[15] = 0x30000000u; t.cpu.gpr[16] = 0x11223344u;
  t.Put(7, X31(16, 0, 15, 242));                            // mtsrin r16,r15 (SR3)
  t.Put(8, X31(17, 0, 15, 659));                            // mfsrin r17,r15
  CHECK(t.Go(2) == StopReason::Running && t.cpu.gpr[17] == 0x11223344u);
  // tlbie / tlbsync / dcbi: sem efeito
  t.Put(9, X31(0, 0, 3, 306)); t.Put(10, X31(0, 0, 0, 566)); t.Put(11, X31(0, 3, 4, 470));
  const uint32_t pc0 = t.cpu.pc;
  CHECK(t.Go(3) == StopReason::Running && t.cpu.pc == pc0 + 12);
}

void TestTimeBaseAndDecrementer() {
  std::printf("[SIM] time base gravavel (mttbl/mttbu) e decrementador (excecao 0x900)\n");
  Rig t;
  t.cpu.gpr[3] = 0x12345678u; t.cpu.gpr[4] = 0x9u;
  t.Put(0, Mtspr(284, 3));                                  // mttbl
  t.Put(1, Mtspr(285, 4));                                  // mttbu
  t.Put(2, Mfspr(268, 5));                                  // mftb r5
  t.Put(3, Mfspr(269, 6));                                  // mftbu r6
  CHECK(t.Go(4) == StopReason::Running);
  CHECK(t.cpu.gpr[6] == 9u && t.cpu.gpr[5] >= 0x12345678u && t.cpu.gpr[5] < 0x12345680u);

  // DEC: 5 ticks = 72 passos; com MSR[EE] ligado a excecao entra no vetor 0x900.
  Rig d;
  for (uint32_t i = 0; i < 400; ++i) d.Put(i, kNop);
  d.cpu.gpr[3] = 5;
  d.Put(0, Mtspr(22, 3));
  d.Put(1, Mfspr(22, 7));
  d.cpu.msr = 0x8000u;
  CHECK(d.Go(2) == StopReason::Running);
  CHECK(d.cpu.gpr[7] <= 5u);                                // ja decrementando
  unsigned n = 0;
  while (d.cpu.last_exception != Exception::Decrementer && n < 200) { d.Go(1); ++n; }
  CHECK(d.cpu.last_exception == Exception::Decrementer && d.cpu.pc == 0x900);
  CHECK(n >= 60 && n <= 80);                                // ~72 passos
  CHECK(d.cpu.srr0 >= kCode && d.cpu.srr0 < kCode + 4 * 100);
  CHECK((d.cpu.msr & 0x8000u) == 0);                        // EE desligado no tratador
  // Nao repete sem novo DEC: depois de rfi nada dispara de novo.
  d.mem.Write(0x900, 4, 0x4C000064u);                       // rfi
  d.cpu.msr |= 0;                                           // (rfi restaura MSR de srr1, com EE)
  d.Go(1);
  CHECK(d.cpu.pc == d.cpu.srr0 && (d.cpu.msr & 0x8000u) != 0);
  d.cpu.last_exception = Exception::None;
  d.Go(20);
  CHECK(d.cpu.last_exception == Exception::None);

  // Pendente enquanto EE = 0: dispara assim que EE liga.
  Rig p;
  for (uint32_t i = 0; i < 400; ++i) p.Put(i, kNop);
  p.cpu.gpr[3] = 1;
  p.Put(0, Mtspr(22, 3));
  p.cpu.msr = 0;
  p.Go(60);
  CHECK(p.cpu.last_exception == Exception::None);
  p.cpu.msr = 0x8000u;
  p.Go(1);
  CHECK(p.cpu.last_exception == Exception::Decrementer && p.cpu.pc == 0x900);

  // Externa tem prioridade sobre a do decrementador.
  Rig q;
  for (uint32_t i = 0; i < 400; ++i) q.Put(i, kNop);
  q.cpu.gpr[3] = 0; q.Put(0, Mtspr(22, 3));
  q.cpu.msr = 0; q.Go(40);
  q.cpu.msr = 0x8000u; q.cpu.RequestExternalInterrupt();
  q.Go(1);
  CHECK(q.cpu.last_exception == Exception::ExternalInterrupt && q.cpu.pc == 0x500);
}

}  // namespace

int main() {
  TestFpIndexed();
  TestLfsFillsPs1();
  TestPsqIndexed();
  TestMiscInstructions();
  TestTimeBaseAndDecrementer();
  std::printf("\n[SIM] test_cpu_gaps: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
