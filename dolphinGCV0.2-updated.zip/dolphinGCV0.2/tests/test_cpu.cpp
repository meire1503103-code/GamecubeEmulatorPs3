// Testes do interpretador Gekko + memoria. Sem toolchain PPC no host, as
// instrucoes sao codificadas por helpers abaixo, que sao validados contra
// palavras bem conhecidas (blr, mflr r0, stwu r1,-16(r1)...).
#include "check.h"
#include "cpu.h"
#include "memory.h"

#include <cstdint>
#include <cstdlib>
#include <string>
#include <vector>

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;

// ---- encoders ----
uint32_t D(uint32_t op, uint32_t rt, uint32_t ra, int32_t imm) {
  return (op << 26) | (rt << 21) | (ra << 16) | (uint32_t(imm) & 0xFFFF);
}
uint32_t X(uint32_t rt, uint32_t ra, uint32_t rb, uint32_t xo, uint32_t rc = 0) {
  return (31u << 26) | (rt << 21) | (ra << 16) | (rb << 11) | (xo << 1) | rc;
}
uint32_t M(uint32_t op, uint32_t rs, uint32_t ra, uint32_t sh, uint32_t mb, uint32_t me, uint32_t rc = 0) {
  return (op << 26) | (rs << 21) | (ra << 16) | (sh << 11) | (mb << 6) | (me << 1) | rc;
}
uint32_t B(int32_t off, bool lk = false) { return (18u << 26) | (uint32_t(off) & 0x03FFFFFC) | (lk ? 1u : 0u); }
uint32_t BC(uint32_t bo, uint32_t bi, int32_t off, bool lk = false) {
  return (16u << 26) | (bo << 21) | (bi << 16) | (uint32_t(off) & 0xFFFC) | (lk ? 1u : 0u);
}
uint32_t XL(uint32_t bo, uint32_t bi, uint32_t xo, bool lk = false) {
  return (19u << 26) | (bo << 21) | (bi << 16) | (xo << 1) | (lk ? 1u : 0u);
}
uint32_t CRL(uint32_t d, uint32_t a, uint32_t b, uint32_t xo) {  // crxor, creqv...
  return (19u << 26) | (d << 21) | (a << 16) | (b << 11) | (xo << 1);
}
uint32_t SPRF(uint32_t spr) { return ((spr & 31) << 16) | ((spr >> 5) << 11); }
uint32_t MFSPR(uint32_t rt, uint32_t spr) { return (31u << 26) | (rt << 21) | SPRF(spr) | (339u << 1); }
uint32_t MTSPR(uint32_t spr, uint32_t rs) { return (31u << 26) | (rs << 21) | SPRF(spr) | (467u << 1); }

uint32_t LI(uint32_t r, int32_t v) { return D(14, r, 0, v); }
uint32_t LIS(uint32_t r, int32_t v) { return D(15, r, 0, v); }
uint32_t ORI(uint32_t ra, uint32_t rs, uint32_t v) { return D(24, rs, ra, int32_t(v)); }
uint32_t ADDI(uint32_t rt, uint32_t ra, int32_t v) { return D(14, rt, ra, v); }
const uint32_t SC = 17u << 26 | 2;
const uint32_t BLR = 0x4E800020u;
const uint32_t LT = 8, GT = 4, EQ = 2;

const uint32_t kBase = 0x80003100u;

// Monta um programa em kBase, termina com 'sc', roda e devolve o motivo.
struct Machine {
  Memory mem;
  Cpu cpu;
  Machine() : cpu(mem) { std::string e; mem.Init(e); }
  StopReason Run(const std::vector<uint32_t>& prog, uint64_t max = 100000) {
    std::vector<uint32_t> p = prog;
    p.push_back(SC);
    for (size_t i = 0; i < p.size(); ++i) mem.Write(kBase + uint32_t(i * 4), 4, p[i]);
    cpu.Reset(kBase);
    return cpu.Run(max);
  }
  uint32_t& r(unsigned n) { return cpu.gpr[n]; }
  unsigned crf(unsigned f) const { return (cpu.cr >> (28 - 4 * f)) & 0xF; }
  bool ca() const { return (cpu.xer & 0x20000000u) != 0; }
  bool ov() const { return (cpu.xer & 0x40000000u) != 0; }
  bool so() const { return (cpu.xer & 0x80000000u) != 0; }
};

void TestEncoders() {
  std::printf("[SIM] encoders vs palavras conhecidas\n");
  CHECK(BLR == 0x4E800020u);
  CHECK(MFSPR(0, 8) == 0x7C0802A6u);          // mflr r0
  CHECK(MTSPR(9, 0) == 0x7C0903A6u);          // mtctr r0
  CHECK(D(37, 1, 1, -16) == 0x9421FFF0u);     // stwu r1,-16(r1)
  CHECK(LI(3, 5) == 0x38600005u);             // li r3,5
  CHECK(LIS(3, 0x8000) == 0x3C608000u);       // lis r3,0x8000
  CHECK(ORI(0, 0, 0) == 0x60000000u);         // nop
  CHECK(BC(16, 0, -8) == 0x4200FFF8u);        // bdnz -8
}

void TestMemory() {
  std::printf("[SIM] Memory\n");
  Memory m; std::string e;
  CHECK(m.Init(e));
  uint32_t p = 0;
  CHECK(m.Translate(0x80000000u, p) && p == 0);
  CHECK(m.Translate(0xC0001234u, p) && p == 0x1234);
  CHECK(m.Translate(0x00001000u, p) && p == 0x1000);
  CHECK(m.Translate(0x817FFFFFu, p) && p == 0x17FFFFF);
  CHECK(!m.Translate(0x81800000u, p));   // 24 MiB exatos: fora
  CHECK(m.Translate(0xCC000000u, p) && p == 0x0C000000u);   // janela MMIO (fisico 0x0C000000)
  { uint32_t t; CHECK(!m.Read(0xCC000000u, 4, t)); }        // sem barramento ligado, continua falhando
  CHECK(!m.Translate(0xCC010000u, p));   // fora da janela MMIO
  CHECK(!m.Translate(0x90000000u, p));
  CHECK(m.Write(0x80000100u, 4, 0x11223344u));
  uint32_t v = 0;
  CHECK(m.Read(0x80000100u, 1, v) && v == 0x11);   // big-endian
  CHECK(m.Read(0x80000103u, 1, v) && v == 0x44);
  CHECK(m.Read(0xC0000100u, 2, v) && v == 0x1122);  // mirror nao cacheado
  CHECK(m.Read(0x80000102u, 2, v) && v == 0x3344);
  CHECK(m.Write(0x817FFFFCu, 4, 1));
  CHECK(!m.Write(0x817FFFFDu, 4, 1));              // atravessa o fim
  CHECK(!m.Read(0x80000000u, 3, v));               // tamanho invalido
  uint8_t buf[4];
  CHECK(!m.ReadBlock(0x817FFFFFu, buf, 2));
  CHECK(m.ReadBlock(0x80000100u, buf, 4) && buf[0] == 0x11 && buf[3] == 0x44);
  CHECK(m.Fill(0x80000100u, 0xAA, 4) && m.Read(0x80000100u, 4, v) && v == 0xAAAAAAAAu);
}

void TestAlu() {
  std::printf("[SIM] ALU\n");
  Machine m;
  CHECK(m.Run({LIS(3, int32_t(0x8000) - 0x10000), ORI(3, 3, 0x1234), LI(4, -1)}) == StopReason::Syscall);
  CHECK(m.r(3) == 0x80001234u);       // lis com imediato negativo (0x8000 como int16)
  CHECK(m.r(4) == 0xFFFFFFFFu);

  // addic / carry: 0xFFFFFFFF + 1 = 0 com CA=1
  m.Run({LI(3, -1), D(12, 4, 3, 1)});
  CHECK(m.r(4) == 0 && m.ca());
  // addc/adde: soma de 64 bits (0x00000001_FFFFFFFF + 0x00000000_00000001)
  m.Run({LI(3, -1), LI(4, 1), LI(5, 1), LI(6, 0),
         X(7, 3, 4, 10),   // addc r7,r3,r4  -> 0, CA=1
         X(8, 5, 6, 138)}); // adde r8,r5,r6 -> 1+0+1 = 2
  CHECK(m.r(7) == 0 && m.r(8) == 2);
  // subf: r5 = r4 - r3 ; subfc carry
  m.Run({LI(3, 3), LI(4, 10), X(5, 3, 4, 40)});
  CHECK(m.r(5) == 7);
  m.Run({LI(3, 10), LI(4, 3), X(5, 3, 4, 8)});      // subfc: 3-10 = -7, sem carry
  CHECK(m.r(5) == 0xFFFFFFF9u && !m.ca());
  m.Run({LI(3, 3), LI(4, 10), X(5, 3, 4, 8)});      // subfc: 10-3, com carry
  CHECK(m.r(5) == 7 && m.ca());
  m.Run({LI(3, 5), X(4, 3, 0, 104)});               // neg
  CHECK(m.r(4) == 0xFFFFFFFBu);
  // subfic r4,r3,100 -> 100-5
  m.Run({LI(3, 5), D(8, 4, 3, 100)});
  CHECK(m.r(4) == 95 && m.ca());

  // overflow com OE e SO pegajoso: 0x7FFFFFFF + 1
  m.Run({LIS(3, 0x7FFF), ORI(3, 3, 0xFFFF), LI(4, 1), X(5, 3, 4, 266 + 512, 1)});
  CHECK(m.r(5) == 0x80000000u && m.ov() && m.so());
  CHECK(m.crf(0) == (LT | 1));                      // negativo + SO
  m.Run({LI(3, 1), LI(4, 1), X(5, 3, 4, 266 + 512)});  // sem overflow: OV limpo
  CHECK(!m.ov());
  // neg de INT_MIN estoura
  m.Run({LIS(3, -0x8000 + 0), X(4, 3, 0, 104 + 512)});
  CHECK(m.r(4) == 0x80000000u && m.ov());

  // mullw / mulli / mulhw / mulhwu
  m.Run({LI(3, -3), LI(4, 7), X(5, 3, 4, 235), D(7, 6, 3, 5)});
  CHECK(m.r(5) == uint32_t(-21) && m.r(6) == uint32_t(-15));
  m.Run({LIS(3, 0x4000), LIS(4, 0x0004), X(5, 3, 4, 75), X(6, 3, 4, 11)});
  CHECK(m.r(5) == 0x00010000u && m.r(6) == 0x00010000u);   // 2^30 * 2^18 = 2^48 >> 32 = 2^16
  m.Run({LI(3, -1), LI(4, 2), X(5, 3, 4, 75), X(6, 3, 4, 11)});
  CHECK(m.r(5) == 0xFFFFFFFFu && m.r(6) == 1);             // -2>>32 = -1 | 0xFFFFFFFF*2 >> 32 = 1

  // divw / divwu / divisao por zero
  m.Run({LI(3, 100), LI(4, 7), X(5, 3, 4, 491), X(6, 3, 4, 459)});
  CHECK(m.r(5) == 14 && m.r(6) == 14);
  m.Run({LI(3, -100), LI(4, 7), X(5, 3, 4, 491)});
  CHECK(m.r(5) == uint32_t(-14));
  m.Run({LI(3, 5), LI(4, 0), X(5, 3, 4, 491 + 512)});
  CHECK(m.ov() && m.so());

  // logicas
  m.Run({LI(3, 0xF0), LI(4, 0x3C), X(3, 5, 4, 28), X(3, 6, 4, 444), X(3, 7, 4, 316),
         X(3, 8, 4, 124), X(3, 9, 4, 60)});
  CHECK(m.r(5) == 0x30 && m.r(6) == 0xFC && m.r(7) == 0xCC);   // and or xor
  CHECK(m.r(8) == ~0xFCu && m.r(9) == 0xC0);                   // nor andc
  m.Run({LI(3, 0x80), X(3, 4, 0, 954), LIS(5, 0), ORI(5, 5, 0x8000), X(5, 6, 0, 922)});
  CHECK(m.r(4) == 0xFFFFFF80u && m.r(6) == 0xFFFF8000u);       // extsb extsh
  m.Run({LI(3, 1), X(3, 4, 0, 26), LI(5, 0), X(5, 6, 0, 26)});
  CHECK(m.r(4) == 31 && m.r(6) == 32);                          // cntlzw
  m.Run({D(25, 0, 3, 0)});  // oris r3,r0,0 (nada)
  m.Run({LI(3, 0x00FF), D(28, 3, 4, 0x0F0F)});                  // andi. r4,r3,0x0F0F
  CHECK(m.r(4) == 0x000F && m.crf(0) == GT);
  m.Run({LI(3, 0x00F0), D(28, 3, 4, 0x000F)});
  CHECK(m.r(4) == 0 && m.crf(0) == EQ);
  m.Run({LI(3, 0x00F0), D(26, 3, 4, 0x00FF), D(27, 3, 5, 1)});  // xori, xoris
  CHECK(m.r(4) == 0x000F && m.r(5) == 0x000100F0u);
}

void TestShiftRotate() {
  std::printf("[SIM] shifts e rotacoes\n");
  Machine m;
  const uint32_t load = 0x12345678u;
  std::vector<uint32_t> init = {LIS(3, 0x1234), ORI(3, 3, 0x5678)};
  auto prog = [&](uint32_t inst) { std::vector<uint32_t> p = init; p.push_back(inst); return p; };

  m.Run(prog(M(21, 3, 4, 8, 0, 23)));   // slwi r4,r3,8   = rlwinm 8,0,23
  CHECK(m.r(4) == (load << 8));
  m.Run(prog(M(21, 3, 4, 24, 8, 31)));  // srwi r4,r3,8   = rlwinm 24,8,31
  CHECK(m.r(4) == (load >> 8));
  m.Run(prog(M(21, 3, 4, 0, 24, 31)));  // clrlwi r4,r3,24
  CHECK(m.r(4) == 0x78);
  m.Run(prog(M(21, 3, 4, 8, 0, 31)));   // rotlwi r4,r3,8
  CHECK(m.r(4) == 0x34567812u);
  m.Run(prog(M(21, 3, 4, 4, 31, 0)));   // mascara com wrap (mb > me): bits 31 e 0
  CHECK(m.r(4) == (0x23456781u & 0x80000001u));
  // rlwimi: insere 0xAB em bits 16..23 de 0xFFFFFFFF
  m.Run({LI(3, 0xAB), LI(4, -1), M(20, 3, 4, 8, 16, 23)});
  CHECK(m.r(4) == 0xFFFFABFFu);
  // rlwnm com contagem em registrador
  m.Run({LIS(3, 0x1234), ORI(3, 3, 0x5678), LI(5, 8), M(23, 3, 4, 5, 0, 31)});
  CHECK(m.r(4) == 0x34567812u);
  // Rc em rlwinm: resultado zero -> EQ
  m.Run({LI(3, 0), M(21, 3, 4, 0, 0, 31, 1)});
  CHECK(m.crf(0) == EQ);

  // slw / srw (>= 32 zera)
  m.Run({LI(3, 1), LI(4, 4), X(3, 5, 4, 24), LI(6, 32), X(3, 7, 6, 24), LI(8, -1), X(8, 9, 4, 536)});
  CHECK(m.r(5) == 16 && m.r(7) == 0 && m.r(9) == 0x0FFFFFFFu);
  // sraw / srawi e CA
  m.Run({LI(3, -8), X(3, 4, 1, 824)});          // srawi r4,r3,1 : -8>>1, nenhum 1 saiu
  CHECK(m.r(4) == 0xFFFFFFFCu && !m.ca());
  m.Run({LI(3, -7), X(3, 4, 1, 824)});          // -7>>1 = -4, saiu um 1 => CA
  CHECK(m.r(4) == 0xFFFFFFFCu && m.ca());
  m.Run({LI(3, -1), LI(5, 40), X(3, 4, 5, 792)});  // sraw com n>=32
  CHECK(m.r(4) == 0xFFFFFFFFu && m.ca());
  m.Run({LI(3, 64), LI(5, 3), X(3, 4, 5, 792)});
  CHECK(m.r(4) == 8 && !m.ca());
}

void TestCompareBranch() {
  std::printf("[SIM] comparacao e branches\n");
  Machine m;
  m.Run({LI(3, 3), D(11, 0, 3, 5)});             // cmpwi r3,5
  CHECK(m.crf(0) == LT);
  m.Run({LI(3, 7), D(11, 0, 3, 5)});
  CHECK(m.crf(0) == GT);
  m.Run({LI(3, 5), D(11, 2 << 2, 3, 5)});        // cmpwi cr2,r3,5 (BF fica em rt>>2)
  CHECK(m.crf(2) == EQ && m.crf(0) == 0);
  // signed vs unsigned: 0xFFFFFFFF vs 1
  m.Run({LI(3, -1), LI(4, 1), X(0, 3, 4, 0), X(1 << 2, 3, 4, 32)});  // cmpw cr0 ; cmplw cr1
  CHECK(m.crf(0) == LT && m.crf(1) == GT);

  // blt (BO=12,BI=0): pula o 'li r5,99' quando r3<5
  m.Run({LI(3, 3), D(11, 0, 3, 5), BC(12, 0, 8), LI(5, 99), LI(6, 1)});
  CHECK(m.r(5) == 0 && m.r(6) == 1);
  m.Run({LI(3, 9), D(11, 0, 3, 5), BC(12, 0, 8), LI(5, 99), LI(6, 1)});
  CHECK(m.r(5) == 99);
  // bne (BO=4,BI=2) e beq (BO=12,BI=2)
  m.Run({LI(3, 5), D(11, 0, 3, 5), BC(4, 2, 8), LI(5, 99), LI(6, 1)});
  CHECK(m.r(5) == 99);
  m.Run({LI(3, 5), D(11, 0, 3, 5), BC(12, 2, 8), LI(5, 99), LI(6, 1)});
  CHECK(m.r(5) == 0);

  // laco com CTR: soma 1..10 = 55
  m.Run({LI(3, 0), LI(5, 0), LI(4, 10), MTSPR(9, 4),
         ADDI(5, 5, 1),          // loop:
         X(3, 3, 5, 266),        // add r3,r3,r5  (rS slot = rD)
         BC(16, 0, -8)});        // bdnz loop
  CHECK(m.r(3) == 55 && m.cpu.ctr == 0);
  // bdz (BO=18): sai quando CTR chega a 0
  m.Run({LI(4, 1), MTSPR(9, 4), BC(18, 0, 8), LI(5, 99), LI(6, 1)});
  CHECK(m.r(5) == 0 && m.r(6) == 1);

  // bl / blr: funcao em kBase+16 faz r3 = 42
  // idx0: bl +16 (-> idx4) | idx1: li r7,1 | idx2: b +16 (-> sc, idx6) | idx3: (nao executa)
  // idx4: li r3,42 | idx5: blr (volta para idx1) | idx6: sc (anexado por Run)
  CHECK(m.Run({B(16, true), LI(7, 1), B(16), B(0), LI(3, 42), BLR}) == StopReason::Syscall);
  CHECK(m.r(3) == 42 && m.r(7) == 1);
  CHECK(m.cpu.lr == kBase + 4);
  CHECK(m.cpu.steps() == 6);   // bl, li, blr, li, b, sc
  // branch absoluto para tras com b: loop infinito e limite de passos
  CHECK(m.Run({B(0)}, 50) == StopReason::StepLimit);
  // bctr / bctrl
  m.Run({LIS(3, 0x8000), ORI(3, 3, 0x3114), MTSPR(9, 3), XL(20, 0, 528, true), LI(4, 7), LI(5, 8)});
  // bctrl esta em idx3 (+0xC): lr = +0x10 (idx4, 'li r4,7'); alvo 0x80003114 = idx5,
  // entao 'li r4,7' e pulado e 'li r5,8' executa.
  CHECK(m.cpu.lr == kBase + 0x10 && m.r(4) == 0);
  CHECK(m.r(5) == 8);
}

void TestCrSpr() {
  std::printf("[SIM] CR, SPR, MSR\n");
  Machine m;
  m.Run({LIS(3, 0x1234), ORI(3, 3, 0x5678), X(3, 0, 0, 144 + 0) | (0xFFu << 12)});  // mtcrf 0xFF,r3
  CHECK(m.cpu.cr == 0x12345678u);
  m.Run({LIS(3, 0x1234), ORI(3, 3, 0x5678), X(3, 0, 0, 144) | (0x80u << 12), X(4, 0, 0, 19)});  // mtcrf 0x80 ; mfcr
  CHECK(m.r(4) == 0x10000000u);   // so o campo 0 (nibble 1) foi copiado
  // crxor 6,6,6 (crclr) e creqv 6,6,6 (crset) em cr1.eq
  m.Run({CRL(6, 6, 6, 289), CRL(6, 6, 6, 193)});
  CHECK(m.cpu.cr == 0);
  m.Run({CRL(6, 6, 6, 289)});
  CHECK(m.cpu.cr == (0x80000000u >> 6));
  // mcrf cr1,cr0
  m.Run({LIS(3, 0x4000), X(3, 0, 0, 144) | (0xFFu << 12), (19u << 26) | (1u << 23) | (0u << 18)});
  CHECK(m.crf(1) == 4 && m.crf(0) == 4);
  // SPRs: LR, CTR, XER, genericos (HID0=1008, GQR0=912)
  m.Run({LI(3, 0x77), MTSPR(8, 3), MFSPR(4, 8), MTSPR(9, 3), MFSPR(5, 9)});
  CHECK(m.r(4) == 0x77 && m.cpu.lr == 0x77 && m.r(5) == 0x77 && m.cpu.ctr == 0x77);
  m.Run({LI(3, 0x55), MTSPR(1008, 3), MFSPR(4, 1008), MTSPR(912, 3), MFSPR(5, 912)});
  CHECK(m.r(4) == 0x55 && m.r(5) == 0x55);
  // XER: mtspr/mfspr preserva CA
  m.Run({LIS(3, 0x2000), MTSPR(1, 3), D(12, 4, 0, 0)});   // CA=1 ; addic r4,0,0 reseta CA
  CHECK(!m.ca());
  // mftb avanca com o tempo
  m.Run({(31u << 26) | (3u << 21) | SPRF(268) | (371u << 1), ORI(0, 0, 0), ORI(0, 0, 0), ORI(0, 0, 0)});
  const uint32_t t0 = m.r(3);
  m.Run(std::vector<uint32_t>(40, ORI(0, 0, 0)));
  CHECK(m.cpu.time_base() >= 3 && t0 == 0);
  // mfmsr / mtmsr
  m.Run({LI(3, 0x2030), X(3, 0, 0, 146), X(4, 0, 0, 83)});
  CHECK(m.r(4) == 0x2030);
}

void TestLoadStore() {
  std::printf("[SIM] load/store\n");
  Machine m;
  const uint32_t data = 0x80010000u;
  auto base = [&]() { return std::vector<uint32_t>{LIS(10, 0x8001 - 0x10000)}; };
  std::vector<uint32_t> p = base();
  p.push_back(LIS(3, 0x1122)); p.push_back(ORI(3, 3, 0x3344));
  p.push_back(D(36, 3, 10, 0));        // stw r3,0(r10)
  p.push_back(D(34, 4, 10, 0));        // lbz r4,0(r10)  -> 0x11 (big-endian)
  p.push_back(D(34, 5, 10, 3));        // lbz r5,3(r10)  -> 0x44
  p.push_back(D(40, 6, 10, 2));        // lhz r6,2(r10)  -> 0x3344
  p.push_back(D(32, 7, 10, 0));        // lwz r7,0(r10)
  m.Run(p);
  CHECK(m.r(4) == 0x11 && m.r(5) == 0x44 && m.r(6) == 0x3344 && m.r(7) == 0x11223344u);
  uint32_t v = 0;
  CHECK(m.mem.Read(data, 4, v) && v == 0x11223344u);

  // sth/stb + lha (extensao de sinal) vs lhz
  p = base();
  p.push_back(LI(3, -128));            // 0xFFFFFF80
  p.push_back(D(44, 3, 10, 0));        // sth -> 0xFF80
  p.push_back(D(42, 4, 10, 0));        // lha -> 0xFFFFFF80
  p.push_back(D(40, 5, 10, 0));        // lhz -> 0x0000FF80
  p.push_back(D(38, 3, 10, 8));        // stb  -> 0x80
  p.push_back(D(34, 6, 10, 8));        // lbz  -> 0x80
  m.Run(p);
  CHECK(m.r(4) == 0xFFFFFF80u && m.r(5) == 0xFF80u && m.r(6) == 0x80);

  // stwu r1,-16(r1) / lwzu: update forms
  m.Run({LIS(1, 0x8001 - 0x10000), ORI(1, 1, 0x0100), LI(3, 77), D(37, 3, 1, -16), D(33, 4, 1, 0)});
  CHECK(m.r(1) == 0x800100F0u && m.r(4) == 77);
  m.Run({LIS(1, 0x8001 - 0x10000), LI(3, 5), D(37, 3, 1, 8), D(32, 4, 1, 0)});
  CHECK(m.r(1) == 0x80010008u && m.r(4) == 5);

  // indexados: stwx / lwzx / lbzx / byte-reverse
  p = base();
  p.push_back(LI(11, 0x20));
  p.push_back(LIS(3, 0x1122)); p.push_back(ORI(3, 3, 0x3344));
  p.push_back(X(3, 10, 11, 151));      // stwx r3,r10,r11
  p.push_back(X(4, 10, 11, 23));       // lwzx
  p.push_back(X(5, 10, 11, 534));      // lwbrx -> 0x44332211
  p.push_back(X(3, 10, 11, 662));      // stwbrx (inverte ao gravar)
  p.push_back(X(6, 10, 11, 23));       // lwzx -> 0x44332211
  p.push_back(X(7, 10, 11, 790));      // lhbrx -> bswap16(0x4433) = 0x3344
  m.Run(p);
  CHECK(m.r(4) == 0x11223344u && m.r(5) == 0x44332211u && m.r(6) == 0x44332211u && m.r(7) == 0x3344);

  // rA = 0 significa zero no calculo de EA (lwz r3,0x4000(0))
  m.mem.Write(0x00004000u, 4, 0xCAFEBABEu);
  m.Run({D(32, 3, 0, 0x4000)});
  CHECK(m.r(3) == 0xCAFEBABEu);

  // lmw / stmw: r29..r31
  p = base();
  p.push_back(LI(29, 1)); p.push_back(LI(30, 2)); p.push_back(LI(31, 3));
  p.push_back(D(47, 29, 10, 0x40));    // stmw r29,0x40(r10)
  p.push_back(LI(29, 0)); p.push_back(LI(30, 0)); p.push_back(LI(31, 0));
  p.push_back(D(46, 29, 10, 0x40));    // lmw
  m.Run(p);
  CHECK(m.r(29) == 1 && m.r(30) == 2 && m.r(31) == 3);

  // dcbz zera 32 bytes alinhados
  m.mem.Fill(data + 0x80, 0xFF, 64);
  m.Run({LIS(10, 0x8001 - 0x10000), LI(11, 0x85), X(0, 10, 11, 1014)});
  uint8_t b[64];
  m.mem.ReadBlock(data + 0x80, b, 64);
  CHECK(b[0] == 0 && b[31] == 0 && b[32] == 0xFF);   // 0x85 & ~31 = 0x80
}

void TestEndToEndProgram() {
  std::printf("[SIM] programa integrado PowerPC (comparacao, branches e memoria)\n");
  Machine m;
  const uint32_t data = 0x80010000u;

  // Programa PowerPC sintético:
  // 1) confere um valor com cmpwi/beq;
  // 2) grava 0x1234 na RAM e lê de volta;
  // 3) soma 1, grava e lê novamente;
  // 4) compara o resultado e grava r9=1 (sucesso) ou r9=-1 (falha).
  // Todos os desvios são relativos ao endereço da própria instrução.
  const std::vector<uint32_t> program = {
      LI(3, 7),                    // 0: li r3,7
      D(11, 0, 3, 7),             // 1: cmpwi cr0,r3,7
      BC(12, 2, 8),               // 2: beq +8 -> índice 4
      B(40),                      // 3: falha -> índice 13
      LI(4, 0x1234),              // 4
      LIS(6, int32_t(0x8001) - 0x10000), // 5: r6 = 0x80010000
      D(36, 4, 6, 0),             // 6: stw r4,0(r6)
      D(32, 7, 6, 0),             // 7: lwz r7,0(r6)
      ADDI(7, 7, 1),              // 8: addi r7,r7,1
      D(36, 7, 6, 4),             // 9: stw r7,4(r6)
      D(32, 8, 6, 4),             // 10: lwz r8,4(r6)
      D(11, 0, 8, 0x1235),        // 11: cmpwi cr0,r8,0x1235
      BC(12, 2, 12),              // 12: beq +12 -> índice 15
      LI(9, -1),                  // 13: falha
      B(8),                       // 14: pula o caminho de sucesso -> índice 16
      LI(9, 1),                   // 15: sucesso
      SC                          // 16: encerra o programa de teste
  };

  CHECK(m.Run(program) == StopReason::Syscall);
  CHECK(m.r(3) == 7);
  CHECK(m.r(7) == 0x1235u);
  CHECK(m.r(8) == 0x1235u);
  CHECK(m.r(9) == 1u);
  uint32_t stored0 = 0, stored1 = 0;
  CHECK(m.mem.Read(data, 4, stored0) && stored0 == 0x1234u);
  CHECK(m.mem.Read(data + 4, 4, stored1) && stored1 == 0x1235u);
  CHECK(m.cpu.pc == kBase + 17u * 4u);
}

void TestStops() {
  std::printf("[SIM] condicoes de parada\n");
  Machine m;
  // acesso a MMIO ainda nao mapeado
  CHECK(m.Run({LIS(3, 0xCC00 - 0x10000), D(32, 4, 3, 0)}) == StopReason::MemFault);
  CHECK(m.cpu.fault_addr == 0xCC000000u);
  CHECK(m.cpu.pc == kBase + 4);                // pc fica na instrucao que falhou
  CHECK(m.Run({LIS(3, 0xCC00 - 0x10000), D(36, 4, 3, 0x20)}) == StopReason::MemFault);
  CHECK(m.cpu.fault_addr == 0xCC000020u);
  // fetch em endereco nao mapeado
  CHECK(m.Run({LIS(3, 0x7000), MTSPR(9, 3), XL(20, 0, 528)}) == StopReason::MemFault);
  CHECK(m.cpu.fault_addr == 0x70000000u);
  // pc desalinhado
  m.cpu.Reset(kBase + 2);
  CHECK(m.cpu.Step() == StopReason::MemFault);
  // opcode 62 ainda nao implementado na arquitetura 32-bit Gekko.
  CHECK(m.Run({D(62, 1, 3, 0)}) == StopReason::Unimplemented);
  CHECK(m.cpu.pc == kBase && (m.cpu.last_instr >> 26) == 62);
  // eciwx (xo 310, acesso externo controlado) continua nao implementado; lswx/lwarx/stwcx. ja sao
  // (ver test_cpu_gaps e test_cpu_fixes)
  CHECK(m.Run({X(3, 0, 4, 310)}) == StopReason::Unimplemented);
  // sc: pc ja aponta para a proxima instrucao
  CHECK(m.Run({}) == StopReason::Syscall);
  CHECK(m.cpu.pc == kBase + 4);
  // acesso que atravessa o fim da MEM1
  CHECK(m.Run({LIS(3, 0x8180 - 0x10000), ADDI(3, 3, 0), D(32, 4, 3, 0)}) == StopReason::MemFault);
}

}  // namespace

int main() {
  TestEncoders();
  TestMemory();
  TestAlu();
  TestShiftRotate();
  TestCompareBranch();
  TestCrSpr();
  TestLoadStore();
  TestEndToEndProgram();
  TestStops();
  std::printf("\n[SIM] test_cpu: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
