#include "cpu.h"

#include <cstring>
#include <cfenv>
#include <cmath>
#include <limits>

namespace dps3 {
namespace {

uint32_t Rotl(uint32_t x, unsigned n) { n &= 31; return n ? (x << n) | (x >> (32 - n)) : x; }

// Mascara PowerPC: bits mb..me (numeracao IBM, bit 0 = MSB), com wrap se mb > me.
constexpr uint32_t kMsrEE = 1u << 15;  // MSR[EE] (bit 16 na numeracao IBM) = 0x8000

uint32_t Mask(unsigned mb, unsigned me) {
  const uint32_t m1 = 0xFFFFFFFFu >> mb;
  const uint32_t m2 = 0xFFFFFFFFu << (31 - me);
  return mb <= me ? (m1 & m2) : (m1 | m2);
}

// x + y + cin, com carry e overflow (formulacao unica para add*/subf*/neg:
// subf = ~a + b + 1).
uint32_t AddCore(uint32_t x, uint32_t y, uint32_t cin, bool* ca, bool* ov) {
  const uint64_t s = uint64_t(x) + y + cin;
  const uint32_t r = static_cast<uint32_t>(s);
  if (ca) *ca = (s >> 32) != 0;
  if (ov) *ov = (((x ^ r) & (y ^ r)) >> 31) != 0;
  return r;
}

uint32_t Bswap32(uint32_t v) {
  return (v << 24) | ((v & 0xFF00u) << 8) | ((v >> 8) & 0xFF00u) | (v >> 24);
}
uint32_t Bswap16(uint32_t v) { return ((v & 0xFFu) << 8) | ((v >> 8) & 0xFFu); }
uint32_t FloatBits(float value) {
  uint32_t bits = 0;
  std::memcpy(&bits, &value, sizeof(bits));
  return bits;
}
float BitsFloat(uint32_t bits) {
  float value = 0.0f;
  std::memcpy(&value, &bits, sizeof(value));
  return value;
}
uint64_t DoubleBits(double value) {
  uint64_t bits = 0;
  std::memcpy(&bits, &value, sizeof(bits));
  return bits;
}
double BitsDouble(uint64_t bits) {
  double value = 0.0;
  std::memcpy(&value, &bits, sizeof(value));
  return value;
}

bool TrapCondition(uint32_t to, int32_t a, int32_t b, uint32_t ua, uint32_t ub) {
  return ((to & 0x10u) && a < b) || ((to & 0x08u) && a > b) ||
         ((to & 0x04u) && a == b) || ((to & 0x02u) && ua < ub) ||
         ((to & 0x01u) && ua > ub);
}

}  // namespace

const char* StopReasonName(StopReason r) {
  switch (r) {
    case StopReason::Running: return "em execucao";
    case StopReason::Syscall: return "syscall (sc)";
    case StopReason::Unimplemented: return "instrucao nao implementada";
    case StopReason::MemFault: return "acesso a memoria nao mapeada";
    case StopReason::StepLimit: return "limite de passos";
    case StopReason::Cancelled: return "cancelado pelo usuario";
  }
  return "?";
}

void Cpu::Reset(uint32_t entry) {
  std::memset(gpr, 0, sizeof gpr);
  std::memset(fpr, 0, sizeof fpr);
  std::memset(ps1_, 0, sizeof ps1_);
  fpscr = 0;
  std::memset(spr_, 0, sizeof spr_);
  pc = entry; lr = ctr = cr = xer = msr = 0;
  fault_addr = last_instr = 0;
  srr0 = srr1 = dar = dsisr = 0;
  last_exception = Exception::None;
  external_interrupt_pending_ = false;
  exception_taken_this_step_ = false;
  reserve_valid_ = false;
  reserve_addr_ = 0;
  steps_ = 0;
  tb_offset_ = 0;
  dec_at_write_ = 0;
  dec_tick_at_write_ = 0;
  dec_deadline_steps_ = ~0ull;
  dec_pending_ = false;
  std::memset(sr_, 0, sizeof sr_);
}

uint32_t Cpu::ReadSpr(uint32_t n) const {
  switch (n) {
    case 1: return xer;
    case 18: return dsisr;
    case 19: return dar;
    case 26: return srr0;
    case 27: return srr1;
    case 8: return lr;
    case 9: return ctr;
    case 22: return DecValue();
    case 268: return static_cast<uint32_t>(time_base());        // TBL
    case 269: return static_cast<uint32_t>(time_base() >> 32);  // TBU
    default:
      if (n >= 528 && n <= 535) return mem_.GetIbat((n - 528) / 2, ((n - 528) % 2) == 0);
      if (n >= 536 && n <= 543) return mem_.GetDbat((n - 536) / 2, ((n - 536) % 2) == 0);
      return n < 1024 ? spr_[n] : 0;
  }
}

void Cpu::WriteSpr(uint32_t n, uint32_t v) {
  switch (n) {
    case 1: xer = v; break;
    case 18: dsisr = v; break;
    case 19: dar = v; break;
    case 26: srr0 = v; break;
    case 27: srr1 = v; break;
    case 8: lr = v; break;
    case 9: ctr = v; break;
    case 22: ArmDecrementer(v); break;
    case 284: {  // mttbl
      const uint64_t tb = (time_base() & 0xFFFFFFFF00000000ull) | v;
      tb_offset_ = tb - steps_ / 12;
      break;
    }
    case 285: {  // mttbu
      const uint64_t tb = (time_base() & 0xFFFFFFFFull) | (uint64_t(v) << 32);
      tb_offset_ = tb - steps_ / 12;
      break;
    }
    default:
      if (n >= 528 && n <= 535) mem_.SetIbat((n - 528) / 2, ((n - 528) % 2) == 0, v);
      else if (n >= 536 && n <= 543) mem_.SetDbat((n - 536) / 2, ((n - 536) % 2) == 0, v);
      if (n < 1024) spr_[n] = v;
      break;
  }
}

// Decrementador: conta 1 por tick do time base (steps/12). A excecao 0x900 e gerada quando o
// valor passa de 0 para 0xFFFFFFFF; o prazo e guardado em passos de CPU para o Step() ficar barato.
uint32_t Cpu::DecValue() const {
  return dec_at_write_ - static_cast<uint32_t>(steps_ / 12 - dec_tick_at_write_);
}

void Cpu::ArmDecrementer(uint32_t value) {
  dec_at_write_ = value;
  dec_tick_at_write_ = steps_ / 12;
  dec_deadline_steps_ = (dec_tick_at_write_ + static_cast<uint64_t>(value) + 1) * 12;
}

void Cpu::SetCrField(unsigned f, unsigned bits4) {
  const unsigned sh = 28 - 4 * f;
  cr = (cr & ~(0xFu << sh)) | ((bits4 & 0xFu) << sh);
}

void Cpu::RecordCr0(uint32_t r) {
  const int32_t s = static_cast<int32_t>(r);
  SetCrField(0, (s < 0 ? 8u : s > 0 ? 4u : 2u) | So());
}

void Cpu::CmpS(unsigned f, int32_t x, int32_t y) {
  SetCrField(f, (x < y ? 8u : x > y ? 4u : 2u) | So());
}
void Cpu::CmpU(unsigned f, uint32_t x, uint32_t y) {
  SetCrField(f, (x < y ? 8u : x > y ? 4u : 2u) | So());
}

bool Cpu::BranchCondition(uint32_t bo, uint32_t bi) {
  bool ctr_ok = true;
  if (!(bo & 4)) {  // decrementa CTR
    --ctr;
    ctr_ok = (ctr != 0) != (((bo >> 1) & 1) != 0);
  }
  const bool cond_ok = (bo & 0x10) || (CrBit(bi) == (((bo >> 3) & 1) != 0));
  return ctr_ok && cond_ok;
}

bool Cpu::CheckAlignment(uint32_t ea, unsigned size) {
  if ((size == 2 && (ea & 1u)) || (size == 4 && (ea & 3u))) {
    fault_addr = ea;
    RaiseException(Exception::Alignment, ea, 0);
    return false;
  }
  return true;
}

bool Cpu::Load(uint32_t ea, unsigned size, bool sign, uint32_t& v) {
  if (!CheckAlignment(ea, size)) return false;
  uint32_t t;
  if (!((!DrEnabled() && mem_.FastRead(ea, size, t)) || mem_.Read(ea, size, t, false, DrEnabled()))) { fault_addr = ea; return false; }
  if (sign) {
    if (size == 1) t = static_cast<uint32_t>(static_cast<int32_t>(static_cast<int8_t>(t)));
    else if (size == 2) t = static_cast<uint32_t>(static_cast<int32_t>(static_cast<int16_t>(t)));
  }
  v = t;
  return true;
}

bool Cpu::Store(uint32_t ea, unsigned size, uint32_t v) {
  if (!CheckAlignment(ea, size)) return false;
  if (!((!DrEnabled() && mem_.FastWrite(ea, size, v)) || mem_.Write(ea, size, v, DrEnabled()))) { fault_addr = ea; return false; }
  return true;
}

void Cpu::RaiseException(Exception type, uint32_t fault_address, uint32_t syndrome) {
  uint32_t vector = 0;
  switch (type) {
    case Exception::ExternalInterrupt: vector = 0x500; break;
    case Exception::Alignment: vector = 0x600; break;
    case Exception::Program: vector = 0x700; break;
    case Exception::SystemCall: vector = 0xC00; break;
    case Exception::FloatingPointUnavailable: vector = 0x800; break;
    case Exception::Decrementer: vector = 0x900; break;
    case Exception::None: return;
  }
  srr0 = pc;
  srr1 = msr;
  if (type == Exception::Alignment) { dar = fault_address; dsisr = syndrome; }
  // Exceção: MSR <- MSR[ME,IP] (ILE nao modelado); desliga EE, PR, FP, IR, DR etc.
  msr &= (1u << 12) | (1u << 6);
  pc = vector;
  last_exception = type;
  exception_taken_this_step_ = true;
  if (type == Exception::ExternalInterrupt) external_interrupt_pending_ = false;
  if (type == Exception::Decrementer) dec_pending_ = false;
}

void Cpu::ReturnFromInterrupt() {
  msr = srr1;
  pc = srr0;
  last_exception = Exception::None;
}

// add, addc, adde, addme, addze, subf, subfc, subfe, subfme, subfze, neg,
// mullw, divw, divwu (todos com variantes OE e Rc).
StopReason Cpu::ExecArith(uint32_t inst) {
  const unsigned d = (inst >> 21) & 31, a = (inst >> 16) & 31, b = (inst >> 11) & 31;
  const uint32_t xo = (inst >> 1) & 0x3FF;
  const bool oe = (xo & 512) != 0, rc = (inst & 1) != 0;
  const uint32_t ra = gpr[a], rb = gpr[b];
  const uint32_t ca_in = Ca() ? 1u : 0u;

  uint32_t x = 0, y = 0, cin = 0, res = 0;
  bool upd_ca = false, ov = false, add_like = true;

  switch (xo & 0x1FF) {
    case 266: x = ra; y = rb; break;                                   // add
    case 10:  x = ra; y = rb; upd_ca = true; break;                    // addc
    case 138: x = ra; y = rb; cin = ca_in; upd_ca = true; break;       // adde
    case 234: x = ra; y = 0xFFFFFFFFu; cin = ca_in; upd_ca = true; break;  // addme
    case 202: x = ra; y = 0; cin = ca_in; upd_ca = true; break;        // addze
    case 40:  x = ~ra; y = rb; cin = 1; break;                         // subf
    case 8:   x = ~ra; y = rb; cin = 1; upd_ca = true; break;          // subfc
    case 136: x = ~ra; y = rb; cin = ca_in; upd_ca = true; break;      // subfe
    case 232: x = ~ra; y = 0xFFFFFFFFu; cin = ca_in; upd_ca = true; break;  // subfme
    case 200: x = ~ra; y = 0; cin = ca_in; upd_ca = true; break;       // subfze
    case 104: x = ~ra; y = 0; cin = 1; break;                          // neg
    case 235: {                                                        // mullw
      const int64_t p = int64_t(int32_t(ra)) * int64_t(int32_t(rb));
      res = static_cast<uint32_t>(p);
      ov = p != int64_t(int32_t(res));
      add_like = false;
      break;
    }
    case 491: {                                                        // divw
      const int32_t sa = int32_t(ra), sb = int32_t(rb);
      if (sb == 0 || (sa == INT32_MIN && sb == -1)) { ov = true; res = sa < 0 ? 0xFFFFFFFFu : 0; }
      else res = static_cast<uint32_t>(sa / sb);
      add_like = false;
      break;
    }
    case 459:                                                          // divwu
      if (rb == 0) { ov = true; res = 0; } else res = ra / rb;
      add_like = false;
      break;
    default: return StopReason::Unimplemented;
  }

  if (add_like) {
    bool ca = false;
    res = AddCore(x, y, cin, &ca, &ov);
    if (upd_ca) SetCa(ca);
  }
  if (oe) {
    xer = (xer & ~0x40000000u) | (ov ? 0x40000000u : 0);
    if (ov) xer |= 0x80000000u;  // SO e "pegajoso"
  }
  gpr[d] = res;
  if (rc) RecordCr0(res);
  return StopReason::Running;
}

StopReason Cpu::ExecOp19(uint32_t inst, uint32_t& next) {
  const unsigned d = (inst >> 21) & 31, a = (inst >> 16) & 31, b = (inst >> 11) & 31;
  const uint32_t xo = (inst >> 1) & 0x3FF;
  const bool lk = (inst & 1) != 0;
  switch (xo) {
    case 16: case 528: {  // bclr / bcctr
      const uint32_t target = (xo == 16 ? lr : ctr) & ~3u;
      const bool take = BranchCondition(d, a);  // d = BO, a = BI
      if (lk) lr = pc + 4;
      if (take) next = target;
      return StopReason::Running;
    }
    case 50: ReturnFromInterrupt(); next = pc; return StopReason::Running; // rfi
    case 150: return StopReason::Running;  // isync
    case 0:  SetCrField(d >> 2, (cr >> (28 - 4 * (a >> 2))) & 0xF); return StopReason::Running;  // mcrf
    case 257: case 129: case 289: case 225: case 33: case 449: case 417: case 193: {
      const bool x = CrBit(a), y = CrBit(b);
      bool v = false;
      switch (xo) {
        case 257: v = x && y; break;     // crand
        case 129: v = x && !y; break;    // crandc
        case 289: v = x == y; break;     // creqv
        case 225: v = !(x && y); break;  // crnand
        case 33:  v = !(x || y); break;  // crnor
        case 449: v = x || y; break;     // cror
        case 417: v = x || !y; break;    // crorc
        default:  v = x != y; break;     // crxor
      }
      const uint32_t bit = 0x80000000u >> d;
      cr = v ? (cr | bit) : (cr & ~bit);
      return StopReason::Running;
    }
    default: return StopReason::Unimplemented;
  }
}

StopReason Cpu::ExecOp31(uint32_t inst) {
  const unsigned d = (inst >> 21) & 31, a = (inst >> 16) & 31, b = (inst >> 11) & 31;
  const uint32_t xo = (inst >> 1) & 0x3FF;
  const bool rc = (inst & 1) != 0;
  const uint32_t rs = gpr[d], rb = gpr[b];
  const uint32_t ea_idx = (a ? gpr[a] : 0) + rb;  // enderecos indexados
  uint32_t v = 0;

  // Aritmeticas (com OE). Bases: veja ExecArith. Nenhum xo nao-aritmetico
  // colide com estas bases quando mascarado por 0x1FF.
  switch (xo & 0x1FF) {
    case 266: case 10: case 138: case 234: case 202: case 40: case 8: case 136:
    case 232: case 200: case 104: case 235: case 491: case 459:
      return ExecArith(inst);
    default: break;
  }

  switch (xo) {
    case 4: { // tw
      const uint32_t to = (inst >> 21) & 31;
      if (TrapCondition(to, int32_t(gpr[a]), int32_t(rb), gpr[a], rb)) RaiseException(Exception::Program);
      return StopReason::Running;
    }
    // ---- comparacao ----
    case 0:  CmpS(d >> 2, int32_t(gpr[a]), int32_t(rb)); return StopReason::Running;   // cmp
    case 32: CmpU(d >> 2, gpr[a], rb); return StopReason::Running;                     // cmpl

    // ---- multiplicacao alta ----
    case 75:                                                                           // mulhw
      gpr[d] = static_cast<uint32_t>((int64_t(int32_t(gpr[a])) * int64_t(int32_t(rb))) >> 32);
      if (rc) { RecordCr0(gpr[d]); }
      return StopReason::Running;
    case 11:                                                                           // mulhwu
      gpr[d] = static_cast<uint32_t>((uint64_t(gpr[a]) * uint64_t(rb)) >> 32);
      if (rc) { RecordCr0(gpr[d]); }
      return StopReason::Running;

    // ---- logicas (destino = rA, fonte = rS) ----
    case 28:  v = rs & rb; break;      // and
    case 60:  v = rs & ~rb; break;     // andc
    case 444: v = rs | rb; break;      // or
    case 412: v = rs | ~rb; break;     // orc
    case 316: v = rs ^ rb; break;      // xor
    case 124: v = ~(rs | rb); break;   // nor
    case 476: v = ~(rs & rb); break;   // nand
    case 284: v = ~(rs ^ rb); break;   // eqv
    case 954: v = static_cast<uint32_t>(int32_t(int8_t(rs))); break;   // extsb
    case 922: v = static_cast<uint32_t>(int32_t(int16_t(rs))); break;  // extsh
    case 26: {                                                         // cntlzw
      unsigned n = 0;
      while (n < 32 && !(rs & (0x80000000u >> n))) ++n;
      v = n;
      break;
    }
    case 24:  v = (rb & 0x20) ? 0 : (rs << (rb & 31)); break;          // slw
    case 536: v = (rb & 0x20) ? 0 : (rs >> (rb & 31)); break;          // srw
    case 792: case 824: {                                              // sraw / srawi
      const unsigned n = xo == 824 ? b : (rb & 0x3F);
      const int32_t s = int32_t(rs);
      if (n >= 32) { v = s < 0 ? 0xFFFFFFFFu : 0; SetCa(s < 0); }
      else {
        v = static_cast<uint32_t>(s >> n);
        SetCa(s < 0 && n > 0 && (rs & ((1u << n) - 1)) != 0);
      }
      break;
    }
    case 20:                                                           // lwarx
      if (!Load(ea_idx, 4, false, v)) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;
      gpr[d] = v; reserve_valid_ = true; reserve_addr_ = ea_idx;
      return StopReason::Running;
    case 150: {                                                        // stwcx. (sempre Rc=1)
      // Um unico nucleo: a reserva so e perdida por outro stwcx./lwarx. Sucesso = CR0[EQ].
      bool ok = false;
      if (reserve_valid_ && reserve_addr_ == ea_idx) {
        if (!Store(ea_idx, 4, rs)) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;
        ok = true;
      }
      reserve_valid_ = false;
      SetCrField(0, (ok ? 2u : 0u) | So());
      return StopReason::Running;
    }

    // ---- CR / SPR / MSR ----
    case 19:  gpr[d] = cr; return StopReason::Running;                  // mfcr
    case 144: {                                                         // mtcrf
      const uint32_t crm = (inst >> 12) & 0xFF;
      for (unsigned f = 0; f < 8; ++f)
        if (crm & (0x80u >> f)) SetCrField(f, (rs >> (28 - 4 * f)) & 0xF);
      return StopReason::Running;
    }
    case 339: case 371: {                                               // mfspr / mftb
      const uint32_t spr = (((inst >> 11) & 31) << 5) | ((inst >> 16) & 31);
      gpr[d] = ReadSpr(spr);
      return StopReason::Running;
    }
    case 467: {                                                         // mtspr
      const uint32_t spr = (((inst >> 11) & 31) << 5) | ((inst >> 16) & 31);
      WriteSpr(spr, rs);
      return StopReason::Running;
    }
    case 83:  gpr[d] = msr; return StopReason::Running;                 // mfmsr
    case 146: msr = rs; return StopReason::Running;                     // mtmsr

    // ---- cache / sync: sem efeito num interpretador de 1 nucleo ----
    case 598: case 854: case 86: case 54: case 278: case 246: case 982:
      return StopReason::Running;                                       // sync eieio dcbf dcbst dcbt dcbtst icbi
    case 1014:                                                          // dcbz
      if (!mem_.Fill(ea_idx & ~31u, 0, 32, DrEnabled())) { fault_addr = ea_idx; return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault; }
      return StopReason::Running;

    // ---- FP indexado ----
    case 535: case 567: case 599: case 631: case 663: case 695: case 727: case 759: case 983:
      return ExecFpIndexed(inst, xo);                                   // lfsx.. stfiwx

    // ---- mcrxr: CR[crfD] <- XER[SO,OV,CA] e limpa esses bits ----
    case 512:
      SetCrField((inst >> 23) & 7, (xer >> 28) & 0xF);
      xer &= 0x1FFFFFFFu;
      return StopReason::Running;

    // ---- registradores de segmento (mtsr/mfsr/mtsrin/mfsrin): guardados, sem efeito na MMU ----
    case 595: gpr[d] = sr_[(inst >> 16) & 15]; return StopReason::Running;   // mfsr
    case 210: sr_[(inst >> 16) & 15] = rs; return StopReason::Running;      // mtsr
    case 659: gpr[d] = sr_[rb >> 28]; return StopReason::Running;           // mfsrin
    case 242: sr_[rb >> 28] = rs; return StopReason::Running;               // mtsrin

    // ---- TLB / cache sem efeito num interpretador sem TLB ----
    case 306: case 566: case 470: return StopReason::Running;               // tlbie tlbsync dcbi

    // ---- strings: lswi/lswx/stswi/stswx ----
    case 597: case 533: case 725: case 661: {
      const bool imm = (xo == 597 || xo == 725);
      const bool load = (xo == 597 || xo == 533);
      uint32_t ea = imm ? (a ? gpr[a] : 0) : ea_idx;
      uint32_t n = imm ? b : (xer & 0x7F);
      if (imm && n == 0) n = 32;
      unsigned reg = d;
      unsigned shift = 24;
      if (load) {
        if (n) gpr[reg] = 0;
        for (uint32_t k = 0; k < n; ++k, ++ea) {
          uint32_t byte = 0;
          if (!Load(ea, 1, false, byte)) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;
          gpr[reg] = (gpr[reg] & ~(0xFFu << shift)) | (byte << shift);
          if (shift == 0) { shift = 24; reg = (reg + 1) & 31; if (k + 1 < n) gpr[reg] = 0; } else shift -= 8;
        }
      } else {
        for (uint32_t k = 0; k < n; ++k, ++ea) {
          if (!Store(ea, 1, (gpr[reg] >> shift) & 0xFF)) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;
          if (shift == 0) { shift = 24; reg = (reg + 1) & 31; } else shift -= 8;
        }
      }
      return StopReason::Running;
    }

    // ---- load/store indexados ----
    case 23: case 55:   if (!Load(ea_idx, 4, false, v)) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;      // lwzx/lwzux
                        gpr[d] = v; if (xo == 55) gpr[a] = ea_idx; return StopReason::Running;
    case 87: case 119:  if (!Load(ea_idx, 1, false, v)) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;      // lbzx/lbzux
                        gpr[d] = v; if (xo == 119) gpr[a] = ea_idx; return StopReason::Running;
    case 279: case 311: if (!Load(ea_idx, 2, false, v)) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;      // lhzx/lhzux
                        gpr[d] = v; if (xo == 311) gpr[a] = ea_idx; return StopReason::Running;
    case 343: case 375: if (!Load(ea_idx, 2, true, v)) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;       // lhax/lhaux
                        gpr[d] = v; if (xo == 375) gpr[a] = ea_idx; return StopReason::Running;
    case 534: if (!Load(ea_idx, 4, false, v)) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;                // lwbrx
              gpr[d] = Bswap32(v); return StopReason::Running;
    case 790: if (!Load(ea_idx, 2, false, v)) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;                // lhbrx
              gpr[d] = Bswap16(v); return StopReason::Running;
    case 151: case 183: if (!Store(ea_idx, 4, rs)) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;           // stwx/stwux
                        if (xo == 183) { gpr[a] = ea_idx; }
                        return StopReason::Running;
    case 215: case 247: if (!Store(ea_idx, 1, rs)) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;           // stbx/stbux
                        if (xo == 247) { gpr[a] = ea_idx; }
                        return StopReason::Running;
    case 407: case 439: if (!Store(ea_idx, 2, rs)) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;           // sthx/sthux
                        if (xo == 439) { gpr[a] = ea_idx; }
                        return StopReason::Running;
    case 662: if (!Store(ea_idx, 4, Bswap32(rs))) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;            // stwbrx
              return StopReason::Running;
    case 918: if (!Store(ea_idx, 2, Bswap16(rs))) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;            // sthbrx
              return StopReason::Running;

    default: return StopReason::Unimplemented;
  }

  // Caminho das logicas/shifts: resultado em rA, Rc opcional.
  gpr[a] = v;
  if (rc) RecordCr0(v);
  return StopReason::Running;
}


void Cpu::ApplyFpscrRounding() const {
  // FPSCR[30..31] (RN): 00 = Nearest, 01 = Toward Zero, 10 = +Inf, 11 = -Inf
  switch (fpscr & 3u) {
    case 0: std::fesetround(FE_TONEAREST); break;
    case 1: std::fesetround(FE_TOWARDZERO); break;
    case 2: std::fesetround(FE_UPWARD); break;
    case 3: std::fesetround(FE_DOWNWARD); break;
  }
}

// Tabela de aproximacao de reciproco (fres / ps_res) com precisao ~12 bits (estilo Gekko)
float Cpu::ApproxRecip(float x) {
  if (x == 0.0f || std::isnan(x) || std::isinf(x)) return 1.0f / x;
  const uint32_t bits = FloatBits(x);
  const uint32_t sign = bits & 0x80000000u;
  const int exp = static_cast<int>((bits >> 23) & 0xFFu) - 127;
  const uint32_t mant = bits & 0x007FFFFFu;
  // Quantiza mantissa para 5 bits de indice (32 entradas) e interpola linearmente
  const uint32_t idx = mant >> 18;
  const float m0 = 1.0f + static_cast<float>(idx) / 32.0f;
  const float m1 = 1.0f + static_cast<float>(idx + 1) / 32.0f;
  const float r0 = 1.0f / m0;
  const float r1 = 1.0f / m1;
  const float frac = static_cast<float>(mant & 0x3FFFFu) / static_cast<float>(1u << 18);
  const float approx_mant = r0 + (r1 - r0) * frac;
  const float mag = std::ldexp(approx_mant, -exp);
  return sign ? -mag : mag;
}

// Tabela de aproximacao de reciproco da raiz quadrada (frsqrte / ps_rsqrte)
float Cpu::ApproxRsqrt(float x) {
  if (x <= 0.0f || std::isnan(x) || std::isinf(x)) return 1.0f / std::sqrt(x);
  const uint32_t bits = FloatBits(x);
  const int exp = static_cast<int>((bits >> 23) & 0xFFu) - 127;
  const uint32_t mant = bits & 0x007FFFFFu;
  const uint32_t idx = mant >> 18;
  const float scale_e = (exp & 1) ? 2.0f : 1.0f;
  const float m0 = (1.0f + static_cast<float>(idx) / 32.0f) * scale_e;
  const float m1 = (1.0f + static_cast<float>(idx + 1) / 32.0f) * scale_e;
  const float r0 = 1.0f / std::sqrt(m0);
  const float r1 = 1.0f / std::sqrt(m1);
  const float frac = static_cast<float>(mant & 0x3FFFFu) / static_cast<float>(1u << 18);
  const float approx_mant = r0 + (r1 - r0) * frac;
  return std::ldexp(approx_mant, -(exp >> 1));
}

StopReason Cpu::ExecFloating(uint32_t inst, uint32_t op) {
  if ((msr & (1u << 13)) == 0) {
    RaiseException(Exception::FloatingPointUnavailable);
    return StopReason::Running;
  }

  const unsigned fd = (inst >> 21) & 31;
  const unsigned fa = (inst >> 16) & 31;
  const unsigned fb = (inst >> 11) & 31;
  const unsigned fc = (inst >> 6) & 31;
  const bool rc = (inst & 1u) != 0;
  const uint32_t xo = (inst >> 1) & (op == 59 ? 31u : 1023u);
  ApplyFpscrRounding();
  // Qualquer saida (inclusive os `return` antecipados) restaura o arredondamento do host.
  struct RoundGuard { ~RoundGuard() { std::fesetround(FE_TONEAREST); } } round_guard;
  const double a = fpr[fa];
  const double b = fpr[fb];
  const double c = fpr[fc];
  double result = 0.0;
  bool writes_result = true;

  if (op == 59 || op == 63) {
    // Arithmetic instructions use the low 5 XO bits; FRC occupies the
    // neighboring five bits and is an independent source register.
    const uint32_t arith_xo = (inst >> 1) & 31u;
    const bool arithmetic = arith_xo == 18 || arith_xo == 20 || arith_xo == 21 ||
        arith_xo == 22 || arith_xo == 23 || arith_xo == 24 || arith_xo == 25 ||
        arith_xo == 26 || arith_xo == 28 || arith_xo == 29 || arith_xo == 30 ||
        arith_xo == 31;
    if (arithmetic) {
      if (op == 59) {
        // Single precision rounds the result to binary32 before widening it
        // into the emulator's binary64 FPR representation.
        const float af = static_cast<float>(a);
        const float bf = static_cast<float>(b);
        const float cf = static_cast<float>(c);
        float rf = 0.0f;
        switch (arith_xo) {
          case 18: rf = af / bf; break;                         // fdivs
          case 20: rf = af - bf; break;                         // fsubs
          case 21: rf = af + bf; break;                         // fadds
          case 22: rf = std::sqrt(bf); break;                   // fsqrts
          case 24: rf = ApproxRecip(bf); break;                // fres (tabela HW)
          case 25: rf = af * cf; break;                         // fmuls
          case 26: rf = ApproxRsqrt(bf); break;                // frsqrtes (tabela HW)
          case 28: rf = std::fma(af, cf, -bf); break;            // fmsubs
          case 29: rf = std::fma(af, cf, bf); break;             // fmadds
          case 30: rf = -std::fma(af, cf, -bf); break;           // fnmsubs
          case 31: rf = -std::fma(af, cf, bf); break;            // fnmadds
          default: return StopReason::Unimplemented;
        }
        result = static_cast<double>(rf);
      } else {
        switch (arith_xo) {
          case 18: result = a / b; break;                       // fdiv
          case 20: result = a - b; break;                       // fsub
          case 21: result = a + b; break;                       // fadd
          case 22: result = std::sqrt(b); break;                 // fsqrt
          case 23: result = (a >= 0.0) ? c : b; break;           // fsel
          case 25: result = a * c; break;                       // fmul
          case 26: result = static_cast<double>(ApproxRsqrt(static_cast<float>(b))); break; // frsqrte
          case 28: result = std::fma(a, c, -b); break;           // fmsub
          case 29: result = std::fma(a, c, b); break;            // fmadd
          case 30: result = -std::fma(a, c, -b); break;          // fnmsub
          case 31: result = -std::fma(a, c, b); break;            // fnmadd
          default: return StopReason::Unimplemented;
        }
      }
      fpr[fd] = result;
      if (rc) SetCrField(1, (fpscr >> 28) & 0xF);
      return StopReason::Running;
    }
  }

  if (op == 59) return StopReason::Unimplemented;
  {
    switch (xo) {
      case 0: case 32: {                                    // fcmpu / fcmpo
        const unsigned bf = (inst >> 23) & 7;
        unsigned flags = 0;
        if (std::isnan(a) || std::isnan(b)) flags = 1;
        else if (a < b) flags = 8;
        else if (a > b) flags = 4;
        else flags = 2;
        SetCrField(bf, flags | So());
        if (std::isnan(a) || std::isnan(b)) fpscr |= (1u << 3); // VX summary (simplified)
        writes_result = false;
        break;
      }
            case 12: result = static_cast<double>(static_cast<float>(b)); break; // frsp
      case 14: case 15: {                                   // fctiw / fctiwz
        int32_t iv = 0;
        if (std::isnan(b) || b <= -2147483648.0) iv = INT32_MIN;
        else if (b >= 2147483647.0) iv = INT32_MAX;
        else iv = (xo == 15) ? static_cast<int32_t>(std::trunc(b)) : static_cast<int32_t>(std::nearbyint(b));
        fpr[fd] = BitsDouble(0xFFF8000000000000ull | static_cast<uint32_t>(iv));
        writes_result = false;
        break;
      }
      case 18: result = a / b; break;                       // fdiv
      case 20: result = a - b; break;                       // fsub
      case 21: result = a + b; break;                       // fadd
      case 22: result = std::sqrt(b); break;                 // fsqrt
      case 23: result = (a >= 0.0) ? c : b; break;           // fsel
      case 25: result = a * c; break;                       // fmul
      case 26: result = static_cast<double>(ApproxRsqrt(static_cast<float>(b))); break; // frsqrte (modeled exactly)
      case 28: result = std::fma(a, c, -b); break;           // fmsub
      case 29: result = std::fma(a, c, b); break;            // fmadd
      case 30: result = -std::fma(a, c, -b); break;          // fnmsub
      case 31: result = -std::fma(a, c, b); break;            // fnmadd
      case 40: result = -b; break;                           // fneg
      case 72: result = b; break;                            // fmr
      case 136: result = -std::fabs(b); break;               // fnabs
      case 264: result = std::fabs(b); break;                // fabs
      case 583: {                                             // mffs
        fpr[fd] = BitsDouble(0xFFF8000000000000ull | fpscr);  // FPSCR na palavra baixa
        writes_result = false;
        break;
      }
      case 711: {                                             // mtfsf (field mask)
        const uint32_t fm = (inst >> 17) & 0xFF;
        const uint32_t source = static_cast<uint32_t>(DoubleBits(b) & 0xFFFFFFFFull);  // palavra baixa
        for (unsigned field = 0; field < 8; ++field) {
          if (fm & (0x80u >> field)) {
            const unsigned shift = 28 - 4 * field;
            fpscr = (fpscr & ~(0xFu << shift)) | (source & (0xFu << shift));
          }
        }
        writes_result = false;
        break;
      }
      case 134: {                                            // mtfsfi
        const unsigned bf = (inst >> 23) & 7;
        const uint32_t imm = (inst >> 12) & 0xF;
        const unsigned shift = 28 - 4 * bf;
        fpscr = (fpscr & ~(0xFu << shift)) | (imm << shift);
        writes_result = false;
        break;
      }
      case 38: case 70: {                                    // mtfsb1 / mtfsb0
        const unsigned bit = (inst >> 21) & 31;
        const uint32_t mask = 1u << (31 - bit);
        if (xo == 38) fpscr |= mask; else fpscr &= ~mask;
        writes_result = false;
        break;
      }
      case 64: {                                             // mcrfs
        const unsigned bf = (inst >> 23) & 7;
        const unsigned bfa = (inst >> 18) & 7;
        const unsigned shift = 28 - 4 * bfa;
        const unsigned nibble = (fpscr >> shift) & 0xF;
        SetCrField(bf, nibble);
        fpscr &= ~(0xFu << shift);
        writes_result = false;
        break;
      }
      default: return StopReason::Unimplemented;
    }
  }

  if (writes_result) fpr[fd] = result;
  if (rc) {
    // Rc on FP instructions copies the FPSCR's summary condition to CR1.
    SetCrField(1, (fpscr >> 28) & 0xF);
  }
  std::fesetround(FE_TONEAREST);
  return StopReason::Running;
}


float Cpu::ps0(unsigned idx) const {
  return static_cast<float>(fpr[idx & 31]);
}

float Cpu::ps1(unsigned idx) const {
  return ps1_[idx & 31];
}

void Cpu::set_ps0(unsigned idx, float val) {
  fpr[idx & 31] = static_cast<double>(val);
}

void Cpu::set_ps1(unsigned idx, float val) {
  ps1_[idx & 31] = val;
}

void Cpu::set_ps(unsigned idx, float v0, float v1) {
  fpr[idx & 31] = static_cast<double>(v0);
  ps1_[idx & 31] = v1;
}

float Cpu::Dequantize(uint32_t raw, uint8_t type, uint8_t scale) const {
  const int8_t signed_scale = static_cast<int8_t>(scale << 2) >> 2;
  const float factor = std::ldexp(1.0f, -signed_scale);

  switch (type) {
    case 0: return BitsFloat(raw);
    case 4: return static_cast<float>(static_cast<uint8_t>(raw)) * factor;
    case 5: return static_cast<float>(static_cast<uint16_t>(raw)) * factor;
    case 6: return static_cast<float>(static_cast<int8_t>(raw)) * factor;
    case 7: return static_cast<float>(static_cast<int16_t>(raw)) * factor;
    default: return 0.0f;
  }
}

uint32_t Cpu::Quantize(float val, uint8_t type, uint8_t scale) const {
  const int8_t signed_scale = static_cast<int8_t>(scale << 2) >> 2;
  const float scaled = std::ldexp(val, signed_scale);

  auto clamp_i = [](float v, int32_t lo, int32_t hi) -> int32_t {
    if (std::isnan(v)) return 0;
    if (v <= static_cast<float>(lo)) return lo;
    if (v >= static_cast<float>(hi)) return hi;
    return static_cast<int32_t>(std::trunc(v));  // Gekko trunca (nao arredonda) ao quantizar
  };

  switch (type) {
    case 0: return FloatBits(val);
    case 4: return static_cast<uint32_t>(clamp_i(scaled, 0, 255)) & 0xFFu;
    case 5: return static_cast<uint32_t>(clamp_i(scaled, 0, 65535)) & 0xFFFFu;
    case 6: return static_cast<uint32_t>(clamp_i(scaled, -128, 127)) & 0xFFu;
    case 7: return static_cast<uint32_t>(clamp_i(scaled, -32768, 32767)) & 0xFFFFu;
    default: return 0;
  }
}

StopReason Cpu::QuantizedAccess(unsigned fd, uint32_t ea, bool w, unsigned gqr_idx, bool is_load) {
  const uint32_t gqr = ReadSpr(912 + gqr_idx);
  const uint8_t type  = is_load ? ((gqr >> 16) & 7) : (gqr & 7);
  const uint8_t scale = is_load ? ((gqr >> 24) & 0x3F) : ((gqr >> 8) & 0x3F);

  unsigned elem_size = 4;
  if (type == 4 || type == 6) elem_size = 1;
  else if (type == 5 || type == 7) elem_size = 2;

  if (is_load) {
    uint32_t raw0 = 0, raw1 = 0;
    if (!mem_.Read(ea, elem_size, raw0, false, DrEnabled())) { fault_addr = ea; return StopReason::MemFault; }
    const float v0 = Dequantize(raw0, type, scale);
    float v1 = 1.0f;
    if (!w) {
      if (!mem_.Read(ea + elem_size, elem_size, raw1, false, DrEnabled())) { fault_addr = ea + elem_size; return StopReason::MemFault; }
      v1 = Dequantize(raw1, type, scale);
    }
    set_ps(fd, v0, v1);
  } else {
    const uint32_t raw0 = Quantize(ps0(fd), type, scale);
    if (!mem_.Write(ea, elem_size, raw0, DrEnabled())) { fault_addr = ea; return StopReason::MemFault; }
    if (!w) {
      const uint32_t raw1 = Quantize(ps1(fd), type, scale);
      if (!mem_.Write(ea + elem_size, elem_size, raw1, DrEnabled())) { fault_addr = ea + elem_size; return StopReason::MemFault; }
    }
  }
  return StopReason::Running;
}

StopReason Cpu::ExecQuantizedLoadStore(uint32_t inst, uint32_t op) {
  if ((msr & (1u << 13)) == 0) {
    RaiseException(Exception::FloatingPointUnavailable);
    return StopReason::Running;
  }

  const unsigned fd = (inst >> 21) & 31;
  const unsigned a  = (inst >> 16) & 31;
  const bool w      = ((inst >> 15) & 1) != 0;
  const unsigned i  = (inst >> 12) & 7;
  const int32_t disp = int16_t((inst & 0xFFFu) << 4) >> 4;

  const uint32_t ra0 = a ? gpr[a] : 0;
  const uint32_t ea = ra0 + static_cast<uint32_t>(disp);
  const bool is_load = (op == 56 || op == 57);
  const bool update  = (op == 57 || op == 61);

  const StopReason r = QuantizedAccess(fd, ea, w, i, is_load);
  if (r != StopReason::Running) return r;
  if (update && a != 0) gpr[a] = ea;
  return StopReason::Running;
}

// psq_lx frD,rA,rB,W,I | psq_stx | psq_lux | psq_stux: W = bit 21 (IBM) = 0x400, I = bits 22-24 = 0x380.
StopReason Cpu::ExecQuantizedIndexed(uint32_t inst) {
  if ((msr & (1u << 13)) == 0) {
    RaiseException(Exception::FloatingPointUnavailable);
    return StopReason::Running;
  }
  const unsigned fd = (inst >> 21) & 31;
  const unsigned a  = (inst >> 16) & 31;
  const unsigned b  = (inst >> 11) & 31;
  const bool w      = (inst & 0x400u) != 0;
  const unsigned i  = (inst >> 7) & 7;
  const uint32_t xo6 = (inst >> 1) & 0x3F;
  const bool is_load = (xo6 == 6 || xo6 == 38);
  const bool update  = (xo6 == 38 || xo6 == 39);
  const uint32_t ea = (a ? gpr[a] : 0) + gpr[b];

  const StopReason r = QuantizedAccess(fd, ea, w, i, is_load);
  if (r != StopReason::Running) return r;
  if (update && a != 0) gpr[a] = ea;
  return StopReason::Running;
}

// Load/store de ponto flutuante indexados (opcode 31).
StopReason Cpu::ExecFpIndexed(uint32_t inst, uint32_t xo) {
  if ((msr & (1u << 13)) == 0) {
    RaiseException(Exception::FloatingPointUnavailable);
    return StopReason::Running;
  }
  const unsigned d = (inst >> 21) & 31, a = (inst >> 16) & 31, b = (inst >> 11) & 31;
  const uint32_t ea = (a ? gpr[a] : 0) + gpr[b];
  const bool update = (xo == 567 || xo == 631 || xo == 695 || xo == 759);
  if (update && a == 0) return StopReason::Unimplemented;  // forma invalida (rA = 0)

  switch (xo) {
    case 535: case 567: {                                   // lfsx / lfsux
      if (!CheckAlignment(ea, 4)) return StopReason::Running;
      uint32_t bits = 0;
      if (!mem_.Read(ea, 4, bits, false, DrEnabled())) { fault_addr = ea; return StopReason::MemFault; }
      set_ps(d, BitsFloat(bits), BitsFloat(bits));
      break;
    }
    case 599: case 631: {                                   // lfdx / lfdux
      if (!CheckAlignment(ea, 4)) return StopReason::Running;
      uint8_t bytes[8];
      if (!mem_.ReadBlock(ea, bytes, sizeof(bytes), DrEnabled())) { fault_addr = ea; return StopReason::MemFault; }
      uint64_t bits = 0;
      for (unsigned k = 0; k < 8; ++k) bits = (bits << 8) | bytes[k];
      fpr[d] = BitsDouble(bits);
      break;
    }
    case 663: case 695: {                                   // stfsx / stfsux
      if (!CheckAlignment(ea, 4)) return StopReason::Running;
      if (!mem_.Write(ea, 4, FloatBits(static_cast<float>(fpr[d])), DrEnabled())) { fault_addr = ea; return StopReason::MemFault; }
      break;
    }
    case 727: case 759: {                                   // stfdx / stfdux
      if (!CheckAlignment(ea, 4)) return StopReason::Running;
      const uint64_t bits = DoubleBits(fpr[d]);
      uint8_t bytes[8];
      for (unsigned k = 0; k < 8; ++k) bytes[k] = static_cast<uint8_t>(bits >> (56 - 8 * k));
      if (!mem_.WriteBlock(ea, bytes, sizeof(bytes), DrEnabled())) { fault_addr = ea; return StopReason::MemFault; }
      break;
    }
    case 983: {                                             // stfiwx: palavra baixa dos 64 bits do FPR
      if (!CheckAlignment(ea, 4)) return StopReason::Running;
      if (!mem_.Write(ea, 4, static_cast<uint32_t>(DoubleBits(fpr[d]) & 0xFFFFFFFFull), DrEnabled())) { fault_addr = ea; return StopReason::MemFault; }
      break;
    }
    default: return StopReason::Unimplemented;
  }
  if (update) gpr[a] = ea;
  return StopReason::Running;
}

StopReason Cpu::ExecPairedSingles(uint32_t inst) {
  if ((msr & (1u << 13)) == 0) {
    RaiseException(Exception::FloatingPointUnavailable);
    return StopReason::Running;
  }

  const unsigned fd = (inst >> 21) & 31;
  const unsigned fa = (inst >> 16) & 31;
  const unsigned fb = (inst >> 11) & 31;
  const unsigned fc = (inst >> 6) & 31;
  const bool rc     = (inst & 1u) != 0;
  const uint32_t xo5  = (inst >> 1) & 31u;
  const uint32_t xo10 = (inst >> 1) & 1023u;

  const float a0 = ps0(fa), a1 = ps1(fa);
  const float b0 = ps0(fb), b1 = ps1(fb);
  const float c0 = ps0(fc), c1 = ps1(fc);

  switch (xo5) {
    case 10: set_ps(fd, a0 + b1, c1); break;                                   // ps_sum0: ps0 = a0+b1, ps1 = c1
    case 11: set_ps(fd, c0, a0 + b1); break;                                   // ps_sum1: ps0 = c0, ps1 = a0+b1
    case 12: set_ps(fd, a0 * c0, a1 * c0); break;                              // ps_muls0
    case 13: set_ps(fd, a0 * c1, a1 * c1); break;                              // ps_muls1
    case 14: set_ps(fd, std::fma(a0, c0, b0), std::fma(a1, c0, b1)); break;    // ps_madds0
    case 15: set_ps(fd, std::fma(a0, c1, b0), std::fma(a1, c1, b1)); break;    // ps_madds1
    case 18: set_ps(fd, a0 / b0, a1 / b1); break;                              // ps_div
    case 20: set_ps(fd, a0 - b0, a1 - b1); break;                              // ps_sub
    case 21: set_ps(fd, a0 + b0, a1 + b1); break;                              // ps_add
    case 23: set_ps(fd, (a0 >= 0.0f) ? c0 : b0, (a1 >= 0.0f) ? c1 : b1); break;// ps_sel
    case 24: set_ps(fd, ApproxRecip(b0), ApproxRecip(b1)); break;            // ps_res
    case 25: set_ps(fd, a0 * c0, a1 * c1); break;                              // ps_mul
    case 26: set_ps(fd, ApproxRsqrt(b0), ApproxRsqrt(b1)); break;            // ps_rsqrte
    case 28: set_ps(fd, std::fma(a0, c0, -b0), std::fma(a1, c1, -b1)); break;  // ps_msub
    case 29: set_ps(fd, std::fma(a0, c0, b0), std::fma(a1, c1, b1)); break;    // ps_madd
    case 30: set_ps(fd, -std::fma(a0, c0, -b0), -std::fma(a1, c1, -b1)); break;// ps_nmsub
    case 31: set_ps(fd, -std::fma(a0, c0, b0), -std::fma(a1, c1, b1)); break;  // ps_nmadd
    default: {
      switch (xo10) {
        case 0: case 32: { // ps_cmpu0 / ps_cmpo0
          const unsigned bf = (inst >> 23) & 7;
          const unsigned flags = (std::isnan(a0) || std::isnan(b0)) ? 1 : (a0 < b0) ? 8 : (a0 > b0) ? 4 : 2;
          SetCrField(bf, flags | So());
          return StopReason::Running;
        }
        case 64: case 96: { // ps_cmpu1 / ps_cmpo1
          const unsigned bf = (inst >> 23) & 7;
          const unsigned flags = (std::isnan(a1) || std::isnan(b1)) ? 1 : (a1 < b1) ? 8 : (a1 > b1) ? 4 : 2;
          SetCrField(bf, flags | So());
          return StopReason::Running;
        }
        case 40:  set_ps(fd, -b0, -b1); break;                        // ps_neg
        case 72:  set_ps(fd, b0, b1); break;                          // ps_mr
        case 136: set_ps(fd, -std::fabs(b0), -std::fabs(b1)); break;  // ps_nabs
        case 264: set_ps(fd, std::fabs(b0), std::fabs(b1)); break;    // ps_abs
        case 528: set_ps(fd, a0, b0); break;                          // ps_merge00
        case 560: set_ps(fd, a0, b1); break;                          // ps_merge01
        case 592: set_ps(fd, a1, b0); break;                          // ps_merge10
        case 624: set_ps(fd, a1, b1); break;                          // ps_merge11
        default: return StopReason::Unimplemented;
      }
      break;
    }
  }

  if (rc) SetCrField(1, (fpscr >> 28) & 0xF);
  return StopReason::Running;
}

StopReason Cpu::Step() {
  exception_taken_this_step_ = false;
  if (external_interrupt_pending_ && (msr & kMsrEE)) {
    RaiseException(Exception::ExternalInterrupt);
    ++steps_;
    return StopReason::Running;
  }
  if (steps_ >= dec_deadline_steps_) {   // DEC passou de 0 para 0xFFFFFFFF
    dec_pending_ = true;
    dec_deadline_steps_ = ~0ull;
  }
  if (dec_pending_ && (msr & kMsrEE)) {
    RaiseException(Exception::Decrementer);
    ++steps_;
    return StopReason::Running;
  }
  uint32_t inst;
  if ((pc & 3) || !((!IrEnabled() && mem_.FastRead(pc, 4, inst)) || mem_.Read(pc, 4, inst, true, IrEnabled()))) { fault_addr = pc; return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault; }
  last_instr = inst;

  const uint32_t op = inst >> 26;
  const unsigned d = (inst >> 21) & 31, a = (inst >> 16) & 31, b = (inst >> 11) & 31;
  const int32_t simm = int16_t(inst & 0xFFFF);
  const uint32_t uimm = inst & 0xFFFF;
  const uint32_t ra0 = a ? gpr[a] : 0;
  const uint32_t instruction_pc = pc;
  uint32_t next = pc + 4;
  uint32_t v = 0;
  StopReason r = StopReason::Running;

  switch (op) {
    case 3: { // twi
      const uint32_t to = d;
      if (TrapCondition(to, int32_t(gpr[a]), simm, gpr[a], static_cast<uint32_t>(simm)))
        RaiseException(Exception::Program);
      break;
    }
    case 7:  gpr[d] = gpr[a] * static_cast<uint32_t>(simm); break;  // mulli
    case 8: {                                                       // subfic
      bool ca; gpr[d] = AddCore(~gpr[a], static_cast<uint32_t>(simm), 1, &ca, nullptr); SetCa(ca); break;
    }
    case 10: CmpU(d >> 2, gpr[a], uimm); break;                     // cmpli
    case 11: CmpS(d >> 2, int32_t(gpr[a]), simm); break;            // cmpi
    case 12: case 13: {                                             // addic / addic.
      bool ca; v = AddCore(gpr[a], static_cast<uint32_t>(simm), 0, &ca, nullptr);
      SetCa(ca); gpr[d] = v;
      if (op == 13) RecordCr0(v);
      break;
    }
    case 14: gpr[d] = ra0 + static_cast<uint32_t>(simm); break;     // addi / li
    case 15: gpr[d] = ra0 + (uimm << 16); break;                    // addis / lis

    case 16: {                                                      // bc
      const bool take = BranchCondition(d, a);
      const uint32_t disp = static_cast<uint32_t>(int32_t(int16_t(inst & 0xFFFC)));
      const uint32_t target = (inst & 2) ? disp : pc + disp;
      if (inst & 1) lr = pc + 4;
      if (take) next = target;
      break;
    }
    case 17:                                                        // sc
      pc = next; ++steps_;
      return StopReason::Syscall;
    case 18: {                                                      // b
      uint32_t li = inst & 0x03FFFFFC;
      if (li & 0x02000000) li |= 0xFC000000;
      const uint32_t target = (inst & 2) ? li : pc + li;
      if (inst & 1) lr = pc + 4;
      next = target;
      break;
    }
    case 19: r = ExecOp19(inst, next); break;

    case 20: {                                                      // rlwimi
      const uint32_t m = Mask((inst >> 6) & 31, (inst >> 1) & 31);
      v = (Rotl(gpr[d], b) & m) | (gpr[a] & ~m);
      gpr[a] = v; if (inst & 1) RecordCr0(v);
      break;
    }
    case 21: {                                                      // rlwinm
      v = Rotl(gpr[d], b) & Mask((inst >> 6) & 31, (inst >> 1) & 31);
      gpr[a] = v; if (inst & 1) RecordCr0(v);
      break;
    }
    case 23: {                                                      // rlwnm
      v = Rotl(gpr[d], gpr[b] & 31) & Mask((inst >> 6) & 31, (inst >> 1) & 31);
      gpr[a] = v; if (inst & 1) RecordCr0(v);
      break;
    }
    case 24: gpr[a] = gpr[d] | uimm; break;                         // ori
    case 25: gpr[a] = gpr[d] | (uimm << 16); break;                 // oris
    case 26: gpr[a] = gpr[d] ^ uimm; break;                         // xori
    case 27: gpr[a] = gpr[d] ^ (uimm << 16); break;                 // xoris
    case 28: v = gpr[d] & uimm; gpr[a] = v; RecordCr0(v); break;    // andi.
    case 29: v = gpr[d] & (uimm << 16); gpr[a] = v; RecordCr0(v); break;  // andis.
    case 31: r = ExecOp31(inst); break;
    case 4: {
      const uint32_t xo6 = (inst >> 1) & 0x3F;
      if (xo6 == 6 || xo6 == 7 || xo6 == 38 || xo6 == 39) r = ExecQuantizedIndexed(inst);  // psq_lx/stx/lux/stux
      else r = ExecPairedSingles(inst);
      break;
    }
    case 56: case 57: case 60: case 61:
      r = ExecQuantizedLoadStore(inst, op);
      break;
    case 59: case 63: r = ExecFloating(inst, op); break;

    // ---- floating-point load/store D-form ----
    case 48: case 49: case 50: case 51: {
      if ((msr & (1u << 13)) == 0) {
        RaiseException(Exception::FloatingPointUnavailable);
        return StopReason::Running;
      }
      const uint32_t ea = ra0 + static_cast<uint32_t>(simm);
      const bool single = (op == 48 || op == 49);
      if (!CheckAlignment(ea, 4)) return StopReason::Running;
      if (single) {
        uint32_t bits = 0;
        if (!mem_.Read(ea, 4, bits, false, DrEnabled())) { fault_addr = ea; return StopReason::MemFault; }
        set_ps(d, BitsFloat(bits), BitsFloat(bits));  // lfs/lfsu: Gekko replica o valor em ps0 e ps1
      } else {
        uint8_t bytes[8];
        if (!mem_.ReadBlock(ea, bytes, sizeof(bytes), DrEnabled())) { fault_addr = ea; return StopReason::MemFault; }
        uint64_t bits = 0;
        for (unsigned i = 0; i < 8; ++i) bits = (bits << 8) | bytes[i];
        fpr[d] = BitsDouble(bits);
      }
      if (op & 1u) gpr[a] = ea;
      break;
    }
    case 52: case 53: case 54: case 55: {
      if ((msr & (1u << 13)) == 0) {
        RaiseException(Exception::FloatingPointUnavailable);
        return StopReason::Running;
      }
      const uint32_t ea = ra0 + static_cast<uint32_t>(simm);
      const bool single = (op == 52 || op == 53);
      if (!CheckAlignment(ea, 4)) return StopReason::Running;
      if (single) {
        if (!mem_.Write(ea, 4, FloatBits(static_cast<float>(fpr[d])), DrEnabled())) {
          fault_addr = ea; return StopReason::MemFault;
        }
      } else {
        const uint64_t bits = DoubleBits(fpr[d]);
        uint8_t bytes[8];
        for (unsigned i = 0; i < 8; ++i) bytes[i] = static_cast<uint8_t>(bits >> (56 - 8 * i));
        if (!mem_.WriteBlock(ea, bytes, sizeof(bytes), DrEnabled())) { fault_addr = ea; return StopReason::MemFault; }
      }
      if (op & 1u) gpr[a] = ea;
      break;
    }

    // ---- load/store D-form ----
    case 32: case 33: case 34: case 35: case 40: case 41: case 42: case 43: {
      const uint32_t ea = ra0 + static_cast<uint32_t>(simm);
      const unsigned size = (op <= 33) ? 4 : (op <= 35) ? 1 : 2;     // lwz(u) lbz(u) | lhz(u) lha(u)
      if (!Load(ea, size, op == 42 || op == 43, v)) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;
      gpr[d] = v;
      if (op & 1) gpr[a] = ea;  // formas com update
      break;
    }
    case 36: case 37: case 38: case 39: case 44: case 45: {
      const uint32_t ea = ra0 + static_cast<uint32_t>(simm);
      const unsigned size = (op <= 37) ? 4 : (op <= 39) ? 1 : 2;     // stw(u) stb(u) | sth(u)
      if (!Store(ea, size, gpr[d])) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;
      if (op & 1) gpr[a] = ea;
      break;
    }
    case 46: {                                                      // lmw
      uint32_t ea = ra0 + static_cast<uint32_t>(simm);
      for (unsigned i = d; i < 32; ++i, ea += 4) {
        if (!Load(ea, 4, false, v)) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;
        gpr[i] = v;
      }
      break;
    }
    case 47: {                                                      // stmw
      uint32_t ea = ra0 + static_cast<uint32_t>(simm);
      for (unsigned i = d; i < 32; ++i, ea += 4)
        if (!Store(ea, 4, gpr[i])) return exception_taken_this_step_ ? StopReason::Running : StopReason::MemFault;
      break;
    }
    default: return StopReason::Unimplemented;  // FP, paired singles, trap...
  }

  if (r != StopReason::Running) return r;
  if (pc != instruction_pc) { ++steps_; return StopReason::Running; }
  pc = next;
  ++steps_;
  return StopReason::Running;
}

StopReason Cpu::Run(uint64_t max_steps) {
  for (uint64_t i = 0; i < max_steps; ++i) {
    const StopReason r = Step();
    if (r != StopReason::Running) return r;
  }
  return StopReason::StepLimit;
}

}  // namespace dps3
