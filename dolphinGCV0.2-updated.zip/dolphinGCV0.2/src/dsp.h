// DolphinGC V0.2 - fase 12: interface do DSP (registradores 0xCC005000..0xCC00503F).
//
// Modelo HLE simplificado (nao e ciclo-exato e NAO executa microcodigo do DSP):
//  - caixas de correio CPU->DSP e DSP->CPU (bits de "valido", como o SDK espera);
//  - DSP_CONTROL: reset, halt, interrupcoes AI/ARAM/DSP com suas mascaras (1 limpa);
//  - DMA da ARAM (16 MiB) entre a RAM principal e a ARAM, instantaneo, com interrupcao;
//  - DMA de audio (AI DMA): consome blocos de 32 bytes no ritmo de 48 kHz e gera a interrupcao;
//  - ganchos (DspHle) para um HLE de microcodigo (AX/Zelda) ligar-se depois.
#pragma once
#include <cstddef>
#include <cstdint>
#include <vector>

namespace dps3 {

class Memory;
class DspInterface;

// Gancho para emular o microcodigo do DSP em alto nivel (AX, Zelda...). Todos os metodos sao
// chamados de dentro do acesso MMIO do CPU; use PostMailToCpu() para responder.
class DspHle {
 public:
  virtual ~DspHle() {}
  virtual void OnReset(DspInterface& dsp) = 0;                    // CPU pediu reset do DSP
  virtual void OnMail(DspInterface& dsp, uint32_t mail) = 0;      // CPU enviou 32 bits ao DSP
  virtual void OnAssertInt(DspInterface& dsp) = 0;                // CPU levantou DSPCR[DSPAssertInt]
};

// Offsets (em relacao a 0xCC005000) dos registradores de 16 bits.
enum DspReg : uint32_t {
  DSP_MAIL_TO_HI = 0x00, DSP_MAIL_TO_LO = 0x02,
  DSP_MAIL_FROM_HI = 0x04, DSP_MAIL_FROM_LO = 0x06,
  DSP_CONTROL = 0x0A,
  DSP_AR_SIZE = 0x12, DSP_AR_MODE = 0x16, DSP_AR_REFRESH = 0x1A,
  DSP_AR_DMA_MM_HI = 0x20, DSP_AR_DMA_MM_LO = 0x22,
  DSP_AR_DMA_AR_HI = 0x24, DSP_AR_DMA_AR_LO = 0x26,
  DSP_AR_DMA_CNT_HI = 0x28, DSP_AR_DMA_CNT_LO = 0x2A,
  DSP_AI_DMA_START_HI = 0x30, DSP_AI_DMA_START_LO = 0x32,
  DSP_AI_DMA_CTRL_LEN = 0x36, DSP_AI_DMA_BLOCKS_LEFT = 0x3A
};

// Bits de DSP_CONTROL.
enum DspControlBits : uint16_t {
  DSPCR_RESET = 1u << 0, DSPCR_ASSERT_INT = 1u << 1, DSPCR_HALT = 1u << 2,
  DSPCR_AIINT = 1u << 3, DSPCR_AIINT_MASK = 1u << 4,
  DSPCR_ARINT = 1u << 5, DSPCR_ARINT_MASK = 1u << 6,
  DSPCR_DSPINT = 1u << 7, DSPCR_DSPINT_MASK = 1u << 8,
  DSPCR_AR_DMA_BUSY = 1u << 9, DSPCR_INIT = 1u << 11
};

constexpr uint32_t kAramSize = 16u * 1024u * 1024u;
constexpr uint32_t kAiBlockBytes = 32;               // 8 amostras estereo de 16 bits
constexpr uint64_t kStepsPerAiBlock = 81000;         // 486 MHz / 6000 blocos por segundo (48 kHz)
constexpr uint32_t kDspBoot = 0x8071FEEDu;           // mail do IROM logo apos o reset

// Recebe cada bloco de 32 bytes consumido pelo AI DMA (estereo 16 bits big-endian).
typedef void (*AudioBlockSink)(const uint8_t* block, void* user);

class DspInterface {
 public:
  DspInterface() { Reset(); }
  void Reset();
  void Attach(Memory* mem) { mem_ = mem; }
  void SetHle(DspHle* hle) { hle_ = hle; }
  void SetAudioSink(AudioBlockSink sink, void* user) { sink_ = sink; sink_user_ = user; }

  // Acesso do CPU (offset em relacao a 0xCC005000; size 1, 2 ou 4). false = fora da janela.
  bool Read(uint32_t off, unsigned size, uint32_t& value);
  bool Write(uint32_t off, unsigned size, uint32_t value);

  // Avanca o relogio (passos de CPU): consome blocos do AI DMA.
  void Tick(uint64_t cpu_steps);
  // Linha de interrupcao do DSP para o PI (bit 6 do PI_INTSR): (flag & mascara) de AI/ARAM/DSP.
  bool InterruptLine() const;

  // --- API para um HLE de microcodigo ---
  // Coloca 'mail' na caixa DSP->CPU (bit 31 = valido) e, se 'raise_int', levanta DSPCR[DSPINT].
  void PostMailToCpu(uint32_t mail, bool raise_int);
  void RaiseDspInt() { control_ |= DSPCR_DSPINT; }
  bool AramRead(uint32_t addr, void* dst, size_t len) const;
  bool AramWrite(uint32_t addr, const void* src, size_t len);

  // Diagnostico / testes.
  uint16_t control() const { return control_; }
  uint32_t mail_to_dsp() const { return mail_to_; }
  uint32_t mail_from_dsp() const { return mail_from_; }
  uint64_t mails_from_cpu() const { return mails_from_cpu_; }
  uint64_t aram_dmas() const { return aram_dmas_; }
  uint64_t aram_dma_errors() const { return aram_dma_errors_; }
  uint64_t ai_blocks_played() const { return ai_blocks_; }
  uint32_t ai_blocks_left() const { return ai_left_; }

 private:
  uint16_t Read16(uint32_t off);
  void Write16(uint32_t off, uint16_t v);
  void WriteControl(uint16_t v);
  void RunAramDma();
  void AiConsumeBlock();
  void EnsureAram() { if (aram_.empty()) aram_.assign(kAramSize, 0); }

  Memory* mem_ = nullptr;
  DspHle* hle_ = nullptr;
  AudioBlockSink sink_ = nullptr;
  void* sink_user_ = nullptr;

  uint16_t control_ = 0;
  uint32_t mail_to_ = 0, mail_from_ = 0;       // bit 31 = "valido" (nao lido)
  uint16_t to_hi_latch_ = 0;                   // metade alta escrita, aguardando a baixa
  uint16_t ar_size_ = 0, ar_mode_ = 0, ar_refresh_ = 0;
  uint32_t ar_mm_ = 0, ar_addr_ = 0, ar_cnt_ = 0;
  uint32_t ai_start_ = 0, ai_cur_ = 0, ai_len_ = 0, ai_left_ = 0;
  bool ai_enable_ = false;
  uint64_t ai_acc_ = 0;
  std::vector<uint8_t> aram_;                  // alocada no primeiro uso
  uint64_t mails_from_cpu_ = 0, aram_dmas_ = 0, aram_dma_errors_ = 0, ai_blocks_ = 0;
};

}  // namespace dps3
