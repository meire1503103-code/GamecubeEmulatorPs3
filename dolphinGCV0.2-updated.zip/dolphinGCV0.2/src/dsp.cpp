#include "dsp.h"

#include <algorithm>
#include <cstring>

#include "memory.h"

namespace dps3 {

void DspInterface::Reset() {
  control_ = DSPCR_HALT;            // o DSP sai do reset parado ate o SDK libera-lo
  mail_to_ = 0;
  mail_from_ = kDspBoot;            // 0x8071FEED: o IROM anuncia que esta pronto (bit 31 = valido)
  to_hi_latch_ = 0;
  ar_size_ = ar_mode_ = ar_refresh_ = 0;
  ar_mm_ = ar_addr_ = ar_cnt_ = 0;
  ai_start_ = ai_cur_ = ai_len_ = ai_left_ = 0;
  ai_enable_ = false;
  ai_acc_ = 0;
  mails_from_cpu_ = aram_dmas_ = aram_dma_errors_ = ai_blocks_ = 0;
  if (!aram_.empty()) std::fill(aram_.begin(), aram_.end(), 0);
}

bool DspInterface::InterruptLine() const {
  return ((control_ & DSPCR_AIINT) && (control_ & DSPCR_AIINT_MASK)) ||
         ((control_ & DSPCR_ARINT) && (control_ & DSPCR_ARINT_MASK)) ||
         ((control_ & DSPCR_DSPINT) && (control_ & DSPCR_DSPINT_MASK));
}

void DspInterface::PostMailToCpu(uint32_t mail, bool raise_int) {
  mail_from_ = mail | 0x80000000u;
  if (raise_int) control_ |= DSPCR_DSPINT;
}

bool DspInterface::AramRead(uint32_t addr, void* dst, size_t len) const {
  if (static_cast<uint64_t>(addr) + len > kAramSize) return false;
  if (aram_.empty()) { std::memset(dst, 0, len); return true; }
  std::memcpy(dst, aram_.data() + addr, len);
  return true;
}

bool DspInterface::AramWrite(uint32_t addr, const void* src, size_t len) {
  if (static_cast<uint64_t>(addr) + len > kAramSize) return false;
  EnsureAram();
  std::memcpy(aram_.data() + addr, src, len);
  return true;
}

void DspInterface::RunAramDma() {
  const uint32_t len = ar_cnt_ & 0x7FFFFFFFu;
  const bool aram_to_mram = (ar_cnt_ & 0x80000000u) != 0;
  const uint32_t mm = 0x80000000u | (ar_mm_ & 0x01FFFFFFu);
  const uint32_t ar = ar_addr_ & (kAramSize - 1);
  ++aram_dmas_;
  bool ok = mem_ != nullptr && static_cast<uint64_t>(ar) + len <= kAramSize;
  if (ok && len) {
    EnsureAram();
    if (aram_to_mram) ok = mem_->WriteBlock(mm, aram_.data() + ar, len);
    else {
      std::vector<uint8_t> tmp(len);
      ok = mem_->ReadBlock(mm, tmp.data(), len);
      if (ok) std::memcpy(aram_.data() + ar, tmp.data(), len);
    }
  }
  if (!ok) ++aram_dma_errors_;
  ar_cnt_ &= 0x80000000u;           // contador chega a zero (a direcao permanece)
  control_ |= DSPCR_ARINT;          // fim do DMA da ARAM
}

void DspInterface::AiConsumeBlock() {
  if (sink_ && mem_) {
    uint8_t block[kAiBlockBytes];
    if (mem_->ReadBlock(0x80000000u | (ai_cur_ & 0x01FFFFFFu), block, sizeof block)) sink_(block, sink_user_);
  }
  ai_cur_ += kAiBlockBytes;
  ++ai_blocks_;
  if (--ai_left_ == 0) {            // acabou o buffer: interrupcao de AI e recarrega (reproducao continua)
    control_ |= DSPCR_AIINT;
    ai_cur_ = ai_start_;
    ai_left_ = ai_len_;
  }
}

void DspInterface::Tick(uint64_t cpu_steps) {
  if (!ai_enable_ || ai_len_ == 0) { ai_acc_ = 0; return; }
  ai_acc_ += cpu_steps;
  while (ai_acc_ >= kStepsPerAiBlock && ai_enable_ && ai_left_ > 0) {
    ai_acc_ -= kStepsPerAiBlock;
    AiConsumeBlock();
  }
}

void DspInterface::WriteControl(uint16_t v) {
  const uint16_t w1c = DSPCR_AIINT | DSPCR_ARINT | DSPCR_DSPINT;
  const uint16_t keep = control_ & ~w1c & ~DSPCR_AR_DMA_BUSY;
  const uint16_t irq = control_ & w1c & ~v;                 // escrever 1 limpa a interrupcao
  const uint16_t rw = DSPCR_ASSERT_INT | DSPCR_HALT | DSPCR_AIINT_MASK | DSPCR_ARINT_MASK |
                      DSPCR_DSPINT_MASK | DSPCR_INIT;
  const bool was_assert = (control_ & DSPCR_ASSERT_INT) != 0;
  control_ = static_cast<uint16_t>((keep & ~rw) | (v & rw) | irq);
  if (v & DSPCR_RESET) {                                    // reset: o IROM reaparece com 0x8071FEED
    mail_to_ = 0;
    mail_from_ = kDspBoot;
    if (hle_) hle_->OnReset(*this);
  }
  if ((v & DSPCR_ASSERT_INT) && !was_assert && hle_) hle_->OnAssertInt(*this);
}

uint16_t DspInterface::Read16(uint32_t off) {
  switch (off) {
    case DSP_MAIL_TO_HI: return static_cast<uint16_t>((mail_to_ >> 16) & 0xFFFFu);
    case DSP_MAIL_TO_LO: return static_cast<uint16_t>(mail_to_ & 0xFFFFu);
    case DSP_MAIL_FROM_HI: return static_cast<uint16_t>((mail_from_ >> 16) & 0xFFFFu);  // bit 15 = valido
    case DSP_MAIL_FROM_LO: {
      const uint16_t lo = static_cast<uint16_t>(mail_from_ & 0xFFFFu);
      mail_from_ &= 0x7FFFFFFFu;                            // ler a metade baixa consome o mail
      return lo;
    }
    case DSP_CONTROL: return control_;
    case DSP_AR_SIZE: return ar_size_;
    case DSP_AR_MODE: return ar_mode_;
    case DSP_AR_REFRESH: return ar_refresh_;
    case DSP_AR_DMA_MM_HI: return static_cast<uint16_t>(ar_mm_ >> 16);
    case DSP_AR_DMA_MM_LO: return static_cast<uint16_t>(ar_mm_);
    case DSP_AR_DMA_AR_HI: return static_cast<uint16_t>(ar_addr_ >> 16);
    case DSP_AR_DMA_AR_LO: return static_cast<uint16_t>(ar_addr_);
    case DSP_AR_DMA_CNT_HI: return static_cast<uint16_t>(ar_cnt_ >> 16);
    case DSP_AR_DMA_CNT_LO: return static_cast<uint16_t>(ar_cnt_);
    case DSP_AI_DMA_START_HI: return static_cast<uint16_t>(ai_start_ >> 16);
    case DSP_AI_DMA_START_LO: return static_cast<uint16_t>(ai_start_);
    case DSP_AI_DMA_CTRL_LEN: return static_cast<uint16_t>((ai_enable_ ? 0x8000u : 0u) | (ai_len_ & 0x7FFFu));
    case DSP_AI_DMA_BLOCKS_LEFT: return static_cast<uint16_t>(ai_left_);
    default: return 0;
  }
}

void DspInterface::Write16(uint32_t off, uint16_t v) {
  switch (off) {
    case DSP_MAIL_TO_HI: to_hi_latch_ = v & 0x7FFFu; break;
    case DSP_MAIL_TO_LO: {                                   // a metade baixa fecha o mail
      mail_to_ = (static_cast<uint32_t>(to_hi_latch_) << 16) | v;
      ++mails_from_cpu_;
      if (hle_) hle_->OnMail(*this, mail_to_);               // consumido na hora (HLE); sem HLE, descartado
      mail_to_ &= 0x7FFFFFFFu;                               // bit "valido" limpo: o DSP ja leu
      break;
    }
    case DSP_MAIL_FROM_HI: case DSP_MAIL_FROM_LO: break;     // somente leitura para o CPU
    case DSP_CONTROL: WriteControl(v); break;
    case DSP_AR_SIZE: ar_size_ = v; break;
    case DSP_AR_MODE: ar_mode_ = v; break;
    case DSP_AR_REFRESH: ar_refresh_ = v; break;
    case DSP_AR_DMA_MM_HI: ar_mm_ = (ar_mm_ & 0x0000FFFFu) | (uint32_t(v) << 16); break;
    case DSP_AR_DMA_MM_LO: ar_mm_ = (ar_mm_ & 0xFFFF0000u) | v; break;
    case DSP_AR_DMA_AR_HI: ar_addr_ = (ar_addr_ & 0x0000FFFFu) | (uint32_t(v) << 16); break;
    case DSP_AR_DMA_AR_LO: ar_addr_ = (ar_addr_ & 0xFFFF0000u) | v; break;
    case DSP_AR_DMA_CNT_HI: ar_cnt_ = (ar_cnt_ & 0x0000FFFFu) | (uint32_t(v) << 16); break;
    case DSP_AR_DMA_CNT_LO:                                  // escrever a metade baixa dispara o DMA
      ar_cnt_ = (ar_cnt_ & 0xFFFF0000u) | v;
      RunAramDma();
      break;
    case DSP_AI_DMA_START_HI: ai_start_ = (ai_start_ & 0x0000FFFFu) | (uint32_t(v & 0x03FFu) << 16); break;
    case DSP_AI_DMA_START_LO: ai_start_ = (ai_start_ & 0xFFFF0000u) | (v & 0xFFE0u); break;
    case DSP_AI_DMA_CTRL_LEN: {
      const bool was = ai_enable_;
      ai_enable_ = (v & 0x8000u) != 0;
      ai_len_ = v & 0x7FFFu;
      if (ai_enable_ && !was) { ai_cur_ = ai_start_; ai_left_ = ai_len_; ai_acc_ = 0; }
      if (!ai_enable_) ai_acc_ = 0;
      break;
    }
    default: break;
  }
}

bool DspInterface::Read(uint32_t off, unsigned size, uint32_t& value) {
  if (size == 2) { value = Read16(off & ~1u); return true; }
  if (size == 4) {
    const uint32_t base = off & ~3u;
    const uint32_t hi = Read16(base);          // a leitura do par le a metade alta antes da baixa
    const uint32_t lo = Read16(base + 2);
    value = (hi << 16) | lo;
    return true;
  }
  if (size == 1) {
    const uint16_t w = Read16(off & ~1u);
    value = (off & 1u) ? (w & 0xFFu) : (w >> 8);
    return true;
  }
  return false;
}

bool DspInterface::Write(uint32_t off, unsigned size, uint32_t value) {
  if (size == 2) { Write16(off & ~1u, static_cast<uint16_t>(value)); return true; }
  if (size == 4) {
    const uint32_t base = off & ~3u;
    Write16(base, static_cast<uint16_t>(value >> 16));
    Write16(base + 2, static_cast<uint16_t>(value));
    return true;
  }
  return false;  // escritas de 1 byte nao existem nesses registradores
}

}  // namespace dps3
