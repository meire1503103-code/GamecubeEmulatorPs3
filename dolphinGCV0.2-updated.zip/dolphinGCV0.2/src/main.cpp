#include <cstdio>
#include <cstdlib>

int main(int argc, char* argv[]) {
    printf("====================================================\n");
    printf("        DOLPHIN GC - PLAYSTATION 3 PORT             \n");
    printf("====================================================\n");
    printf("[PS3] Inicializando ambiente Homebrew no Cell PPU...\n");

#ifdef DSP_OFFLOAD_SPU
    printf("[DSP] Modo assincrono ativo: Audio descarregado para SPU\n");
    printf("[DSP] Taxa de amostragem configurada para: %d Hz\n", SAMPLE_RATE);
#else
    printf("[DSP] Modo de audio executando na PPU principal.\n");
#endif

    printf("[SYS] Sistema pronto. A aguardar carregamento de jogos...\n");
    return 0;
}
