#include "memory.h"

#include <cstring>
#include <new>

// Leitura/escrita rapida de 16/32 bits: no host little-endian faz bswap; no PS3 (PPU big-endian) copia direto.
#if defined(__BYTE_ORDER__) && defined(__ORDER_LITTLE_ENDIAN__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
#define DPS3_BSWAP16(x) __builtin_bswap16(x)
#define DPS3_BSWAP32(x) __builtin_bswap32(x)
#else
#define DPS3_BSWAP16(x) (x)
#define DPS3_BSWAP32(x) (x)
#endif

namespace dps3 {

bool Memory::Init(std::string& err) {
  try {
    ram_.assign(kMem1Size, 0);
  } catch (const std::bad_alloc&) {
    err = "memoria insuficiente para MEM1 (24 MiB)";
    return false;
  }
  for (int i = 0; i < 4; ++i) {
    ibat_[i] = BatPair{};
    dbat_[i] = BatPair{};
  }
  return true;
}

void Memory::SetIbat(unsigned idx, bool upper, uint32_t val) {
  if (idx >= 4) return;
  if (upper) ibat_[idx].u = val;
  else ibat_[idx].l = val;
}

void Memory::SetDbat(unsigned idx, bool upper, uint32_t val) {
  if (idx >= 4) return;
  if (upper) dbat_[idx].u = val;
  else dbat_[idx].l = val;
}

uint32_t Memory::GetIbat(unsigned idx, bool upper) const {
  if (idx >= 4) return 0;
  return upper ? ibat_[idx].u : ibat_[idx].l;
}

uint32_t Memory::GetDbat(unsigned idx, bool upper) const {
  if (idx >= 4) return 0;
  return upper ? dbat_[idx].u : dbat_[idx].l;
}

bool Memory::TranslateBat(uint32_t ea, const BatPair bats[4], uint32_t& phys) const {
  for (int i = 0; i < 4; ++i) {
    const uint32_t u = bats[i].u;
    const uint32_t l = bats[i].l;
    // Vs (bit 1) ou Vp (bit 0) habilitado
    if ((u & 0x3u) == 0) continue;

    // BL ocupa bits 2..14 (em Big-Endian IBM: bits 17..29 -> mask (u >> 2) & 0x7FF)
    const uint32_t bl = (u >> 2) & 0x7FFu;
    const uint32_t block_mask = ~(bl << 17) & 0xFFFE0000u;
    const uint32_t bepi = u & block_mask;

    if ((ea & block_mask) == bepi) {
      const uint32_t brpn = l & block_mask;
      phys = brpn | (ea & ~block_mask);
      return true;
    }
  }
  return false;
}

bool Memory::Translate(uint32_t addr, uint32_t& phys, bool is_instruction, bool translation_enabled) const {
  if (translation_enabled) {
    uint32_t bat_phys = 0;
    if (TranslateBat(addr, is_instruction ? ibat_ : dbat_, bat_phys)) {
      if (bat_phys < kMem1Size || (bat_phys >= kMmioBase && bat_phys < kMmioBase + kMmioSize)) {
        phys = bat_phys;
        return true;
      }
      return false;
    }
  }

  // Fallback / Real mode mapping padrao do Gekko
  const uint32_t seg = addr >> 28;
  if (seg != 0x0 && seg != 0x8 && seg != 0xC) return false;
  const uint32_t p = addr & 0x0FFFFFFFu;
  if (p >= kMem1Size && !(p >= kMmioBase && p < kMmioBase + kMmioSize)) return false;
  phys = p;
  return true;
}

bool Memory::Range(uint32_t addr, size_t len, uint32_t& phys, bool is_instruction, bool translation_enabled) const {
  if (ram_.empty()) return false;
  if (!Translate(addr, phys, is_instruction, translation_enabled)) return false;
  return static_cast<uint64_t>(phys) + len <= kMem1Size;
}

bool Memory::Read(uint32_t addr, unsigned size, uint32_t& value, bool is_instruction, bool translation_enabled) const {
  if (size != 1 && size != 2 && size != 4) return false;
  uint32_t p;
  if (!Translate(addr, p, is_instruction, translation_enabled)) return false;
  if (p < kMem1Size) {
    if (static_cast<uint64_t>(p) + size > kMem1Size || ram_.empty()) return false;
    const uint8_t* src = ram_.data() + p;
    if (size == 4) { uint32_t t; std::memcpy(&t, src, 4); value = DPS3_BSWAP32(t); }
    else if (size == 2) { uint16_t t; std::memcpy(&t, src, 2); value = DPS3_BSWAP16(t); }
    else value = *src;
    return true;
  }
  if (mmio_ && !is_instruction && p >= kMmioBase && static_cast<uint64_t>(p) + size <= kMmioBase + kMmioSize)
    return mmio_->MmioRead(p, size, value);
  return false;
}

bool Memory::Write(uint32_t addr, unsigned size, uint32_t value, bool translation_enabled) {
  if (size != 1 && size != 2 && size != 4) return false;
  uint32_t p;
  if (!Translate(addr, p, false, translation_enabled)) return false;
  if (p < kMem1Size) {
    if (static_cast<uint64_t>(p) + size > kMem1Size || ram_.empty()) return false;
    uint8_t* dst = ram_.data() + p;
    if (size == 4) { const uint32_t t = DPS3_BSWAP32(value); std::memcpy(dst, &t, 4); }
    else if (size == 2) { const uint16_t t = DPS3_BSWAP16(static_cast<uint16_t>(value)); std::memcpy(dst, &t, 2); }
    else *dst = static_cast<uint8_t>(value);
    return true;
  }
  if (mmio_ && p >= kMmioBase && static_cast<uint64_t>(p) + size <= kMmioBase + kMmioSize)
    return mmio_->MmioWrite(p, size, value);
  return false;
}

bool Memory::ReadBlock(uint32_t addr, void* dst, size_t len, bool translation_enabled) const {
  uint32_t p;
  if (!Range(addr, len, p, false, translation_enabled)) return false;
  if (len == 0) return true;
  if (!dst) return false;
  std::memcpy(dst, ram_.data() + p, len);
  return true;
}

bool Memory::WriteBlock(uint32_t addr, const void* src, size_t len, bool translation_enabled) {
  uint32_t p;
  if (!Range(addr, len, p, false, translation_enabled)) return false;
  if (len == 0) return true;
  if (!src) return false;
  std::memcpy(ram_.data() + p, src, len);
  return true;
}

bool Memory::Fill(uint32_t addr, uint8_t byte, size_t len, bool translation_enabled) {
  uint32_t p;
  if (!Range(addr, len, p, false, translation_enabled)) return false;
  if (len) std::memset(ram_.data() + p, byte, len);
  return true;
}

}  // namespace dps3
