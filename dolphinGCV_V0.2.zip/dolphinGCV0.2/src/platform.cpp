// Plataforma PC (testes): sem video nem sysutil; a "tela" e o terminal.
#ifndef DOLPHINPS3_PLATFORM_PS3
#include "platform.h"

#include <chrono>
#include <thread>

namespace dps3 {

bool PlatformInit(TextScreen&) { return true; }
void PlatformShutdown() {}
bool PlatformPump() { return true; }

void PlatformPresent(TextScreen& screen) {
  if (screen.TakeDirty()) screen.DumpText(stdout);
}

void PlatformSleepMs(unsigned ms) { std::this_thread::sleep_for(std::chrono::milliseconds(ms)); }

}  // namespace dps3
#endif
