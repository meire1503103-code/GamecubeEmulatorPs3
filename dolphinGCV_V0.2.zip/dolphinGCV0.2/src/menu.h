// DolphinGC V0.2 - menu principal (texto) navegavel pelo controle PS3 ou por numero (teclado/host).
#pragma once
#include <cstdio>
#include <string>
#include <vector>

#include "input.h"
#include "screen.h"

namespace dps3 {

enum MenuAction {
  MENU_ACTION_EXIT = 0,
  MENU_ACTION_LOAD_ISO = 1,
  MENU_ACTION_LIST_FST = 2,
  MENU_ACTION_CONTROLS = 3,
  MENU_ACTION_INFO = 4,
  MENU_ACTION_LOAD_MKDD = 5,
  MENU_ACTION_HELLO = 6,
  MENU_ACTION_CALC = 7
};

struct MenuItem {
  std::string label;
  int action_id;
  std::string info;  // texto do painel de detalhes (menu "praia"); vazio = so o nome do item
};

// Evento de navegacao (independente de a origem ser o pad ou o teclado).
enum class MenuInput { None, Up, Down, Confirm, Back, Left, Right };

class MenuSystem {
public:
  bool Init();
  // Troca o conjunto de itens (cursor volta ao primeiro).
  void SetItems(const std::vector<MenuItem>& items, const std::string& title);
  void AddItem(const std::string& label, int action_id, const std::string& info = std::string());

  // Imprime o menu em `out` (stdout / log.txt). O item selecionado leva o marcador "> ".
  void RenderConsole(std::FILE* out = stdout) const;
  // Desenha o menu na tela (TV do PS3 ou terminal do PC): titulo, itens com o selecionado em
  // destaque e uma linha de ajuda no rodape. Com muitos itens, rola para manter o cursor visivel.
  void RenderScreen(TextScreen& screen, const std::string& footer = DefaultFooter()) const;
  static std::string DefaultFooter();
  // Menu sem enfeites (PC/testes): titulo, linha e itens numerados. RenderScreen usa o layout
  // "praia" quando o TextScreen esta em modo praia, e este aqui nos outros casos.
  void RenderScreenPlain(TextScreen& screen, const std::string& footer = DefaultFooter()) const;

  // Navegacao: o cursor da a volta nas pontas. Confirm devolve o action_id do item
  // selecionado; Back devolve `back_action` (-1 = sem acao); outros devolvem -1.
  int Handle(MenuInput in);
  // Selecao direta pelo numero mostrado na tela (0-based); -1 se invalido.
  int SelectOption(int choice) const;

  int selected() const { return selected_; }
  void set_back_action(int action_id, bool enabled) { back_action_ = action_id; has_back_ = enabled; }
  const std::string& title() const { return title_; }
  const std::vector<MenuItem>& items() const { return items_; }

private:
  std::vector<MenuItem> items_;
  std::string title_ = "DOLPHINGC V0.2 - MENU PRINCIPAL";
  int selected_ = 0;
  int back_action_ = -1;
  bool has_back_ = false;
};

// Converte o estado do pad em um evento de menu, so na BORDA (apertou agora e nao estava
// apertado no quadro anterior), para nao pular varios itens por quadro. Cruz/Start = confirma,
// Bolinha = volta, D-Pad ou analogico esquerdo = cima/baixo.
MenuInput MenuInputFromPad(const Ps3PadState& prev, const Ps3PadState& cur);

// Repete direcional segurado (como teclado): 1o evento imediato, depois de `delay_ms` repete a cada
// `rate_ms`. Confirmar/Voltar nunca repetem. `now_ms` e um relogio monotono qualquer.
class PadRepeater {
 public:
  explicit PadRepeater(uint32_t delay_ms = 400, uint32_t rate_ms = 90)
      : delay_(delay_ms), rate_(rate_ms) {}
  MenuInput Update(const Ps3PadState& cur, uint32_t now_ms);
  void Reset(const Ps3PadState& cur) { prev_ = cur; held_ = MenuInput::None; }
  const Ps3PadState& last() const { return prev_; }

 private:
  uint32_t delay_, rate_, next_ms_ = 0;
  Ps3PadState prev_;
  MenuInput held_ = MenuInput::None;
};

// Tela de "Configurar controles": ciclo entre os perfis e mostra o mapeamento ativo.
ControllerProfile NextProfile(ControllerProfile p);
ControllerProfile PrevProfile(ControllerProfile p);
void RenderControlsScreen(ControllerProfile p, std::FILE* out = stdout);
// Mesma tela, na grade de texto (linhas = texto de DescribeMapping).
void RenderControlsScreen(ControllerProfile p, TextScreen& screen);

} // namespace dps3
