// DolphinGC V0.2 - interface: junta tela (TextScreen), plataforma (RSX/terminal) e entrada
// (controle PS3 no console, teclado no PC) e traz as telas prontas: lista rolavel de texto,
// Hello World e Calculadora.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

#include "menu.h"
#include "platform.h"
#include "screen.h"

namespace dps3 {

struct UiEvent {
  MenuInput nav = MenuInput::None;
  int direct = -1;      // PC: numero digitado (selecao direta de item); -1 = nenhum
  std::string text;     // PC: linha digitada (a calculadora usa as teclas daqui)
};

class Ui {
 public:
  // Sobe video/eventos/controle. Mesmo sem video (PC ou falha da RSX) devolve true: o app segue,
  // so que a saida fica no log/terminal.
  bool Init();
  void Shutdown();

  TextScreen& screen() { return screen_; }

  // Mostra a grade (so se mudou) e espera um evento. Devolve false quando o app deve fechar
  // (usuario pediu sair pelo botao PS, ou fim da entrada no PC). Um evento com nav == None e
  // normal (ex.: o controle foi ligado/desligado): quem chama redesenha e espera de novo.
  bool Wait(UiEvent& ev);

  // Para tarefas longas (boot): trata eventos do sistema; true se o usuario cancelou
  // (Bolinha) ou pediu para fechar o app.
  bool CancelRequested();
  bool exit_requested() const { return exit_; }

  // Lista de texto rolavel: Cima/Baixo rolam, Esq/Dir pulam uma pagina, Bolinha/X fecham.
  void ShowLines(const std::string& title, const std::vector<std::string>& lines,
                 const std::string& footer = "Cima/Baixo: rolar   Esq/Dir: pagina   Bolinha: voltar");

  void RunHelloScreen();
  void RunCalculatorScreen();
  void RunControlsScreen(ControllerProfile& profile);

 private:
  TextScreen screen_;
  PadRepeater rep_;
  Ps3PadState last_pad_;
  uint32_t clock_ms_ = 0;
  bool pad_connected_ = true, exit_ = false, video_ok_ = false;
};

}  // namespace dps3
