// DolphinGC V0.2 - leitura de imagens de disco GameCube (ISO/GCM cru).
// Discos Wii e containers RVZ/WIA/GCZ sao detectados e recusados com erro claro.
#pragma once
#include <cstdint>
#include <cstdio>
#include <string>

namespace dps3 {

enum class DiscKind { Unknown, GameCube };
enum class DiscContainer { RawIso, Rvz, Wia, Gcz };

class DiscReader {
 public:
  DiscReader() = default;
  ~DiscReader();
  DiscReader(const DiscReader&) = delete;
  DiscReader& operator=(const DiscReader&) = delete;

  bool Open(const std::string& path, std::string& err);
  void Close();
  // Le `len` bytes no offset absoluto da imagem. true somente se leu tudo.
  bool Read(uint64_t offset, void* dst, size_t len);

  DiscKind kind() const { return kind_; }
  uint64_t size() const { return size_; }
  const std::string& game_id() const { return game_id_; }  // 6 chars
  const std::string& title() const { return title_; }
  uint8_t disc_number() const { return disc_number_; }
  uint8_t version() const { return version_; }

 private:
  std::FILE* f_ = nullptr;
  uint64_t size_ = 0;
  DiscKind kind_ = DiscKind::Unknown;
  std::string game_id_, title_;
  uint8_t disc_number_ = 0, version_ = 0;
};

const char* KindName(DiscKind k);

// true para Mario Kart: Double Dash!! (GM4E / GM4P / GM4J).
bool IsMarioKartDoubleDash(const std::string& game_id);

}  // namespace dps3
