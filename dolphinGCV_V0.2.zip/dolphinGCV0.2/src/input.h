// DolphinGC V0.2 - entrada: conversao do controle PS3 (DualShock 3 / SIXAXIS) para o
// controle de GameCube (somente GameCube; o suporte a Wii foi removido).
//
// Convencoes do PS3 (libpad): eixos 0..255, centro ~128, Y: 0 = CIMA, 255 = BAIXO.
// Convencoes dos consoles Nintendo: Y: valor ALTO = CIMA. Por isso o eixo Y e invertido
// na conversao (sem isso o personagem anda para tras / a camera fica invertida).
#pragma once
#include <cstdint>
#include <string>

namespace dps3 {

// ---------------------------------------------------------------- PS3 (entrada)
struct Ps3PadState {
  // Todos os campos comecam NEUTROS (nada pressionado, sticks no centro).
  bool square = false, circle = false, cross = false, triangle = false;
  bool start = false, select = false;
  bool l1 = false, r1 = false;
  bool l3 = false, r3 = false;
  uint8_t l2_analog = 0, r2_analog = 0;  // 0..255 (pressao)
  bool dpad_up = false, dpad_down = false, dpad_left = false, dpad_right = false;
  uint8_t left_stick_x = 128, left_stick_y = 128;    // 0..255, Y: 0 = cima
  uint8_t right_stick_x = 128, right_stick_y = 128;
};

// Zona morta e limiar do clique digital dos gatilhos. Valores padrao sao seguros para um
// DualShock 3 gasto (o centro dele oscila ~120..136).
struct InputConfig {
  int stick_deadzone = 14;          // 0..100, em unidades brutas (de 128)
  uint8_t trigger_click = 240;      // analogico >= isto  => botao digital L/R "clicado"
  uint8_t trigger_deadzone = 8;     // analogico <= isto  => 0 (ruido)
};

// Converte um eixo bruto do PS3 (0..255, centro 128) em um eixo com centro em 128, zona
// morta aplicada e a faixa restante reescalada para usar o curso completo.
// `invert` = true inverte o sentido (usado nos eixos Y). Resultado sempre em 0..255.
uint8_t ConvertAxis(uint8_t raw, int deadzone, bool invert);

// Gatilho analogico com zona morta (0..255).
uint8_t ConvertTrigger(uint8_t raw, uint8_t deadzone);

// ---------------------------------------------------------------- GameCube
enum GameCubeButton : uint16_t {
  GC_BTN_LEFT   = 0x0001,
  GC_BTN_RIGHT  = 0x0002,
  GC_BTN_DOWN   = 0x0004,
  GC_BTN_UP     = 0x0008,
  GC_BTN_Z      = 0x0010,
  GC_BTN_R      = 0x0020,
  GC_BTN_L      = 0x0040,
  GC_BTN_A      = 0x0100,
  GC_BTN_B      = 0x0200,
  GC_BTN_X      = 0x0400,
  GC_BTN_Y      = 0x0800,
  GC_BTN_START  = 0x1000
};

struct GameCubePadState {
  uint16_t buttons = 0;
  uint8_t main_stick_x = 128, main_stick_y = 128;  // Y: 255 = cima
  uint8_t c_stick_x = 128, c_stick_y = 128;
  uint8_t trigger_l = 0, trigger_r = 0;
};

// Mapeamento: Quadrado=A  Bolinha=B  X=X  Triangulo=Y  Start=Start  R1=Z
//             L2/R2 = L/R analogicos  L1 = L (clique completo)  D-Pad=D-Pad
//             Analogico esq. = Stick principal  Analogico dir. = C-Stick
GameCubePadState MapPs3ToGameCube(const Ps3PadState& ps3, const InputConfig& cfg = InputConfig());

// ---------------------------------------------------------------- Perfis / menu
enum class ControllerProfile : uint8_t { GameCube };  // DolphinGC: so GameCube

const char* ProfileName(ControllerProfile p);
// Texto multi-linha (uma linha por botao) com o mapeamento do perfil, para o menu e docs.
std::string DescribeMapping(ControllerProfile p);

// ---------------------------------------------------------------- Leitura do pad
// Host (PC): PadInit() devolve false e PadPoll() nunca preenche nada.
// PS3 (-DDOLPHINPS3_PLATFORM_PS3): implementado em src/pad_ps3.cpp com libpad.
bool PadInit();
bool PadPoll(Ps3PadState& out);  // true = pad 0 conectado e `out` preenchido
void PadShutdown();

} // namespace dps3
