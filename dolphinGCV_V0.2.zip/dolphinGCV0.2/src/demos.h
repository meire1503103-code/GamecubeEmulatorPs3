// DolphinGC V0.2 - programas de demonstracao que rodam NA CPU EMULADA (codigo PowerPC de verdade).
//
//  - Hello World : le uma string da RAM do guest e escreve byte a byte na porta de console.
//  - Calculadora : cada conta (+ - * /) e feita por uma rotina PowerPC (add/subf/mullw/divw);
//                  o host so cuida de teclas e de mostrar o resultado.
//
// Servem de prova visivel de que o interpretador (cpu.cpp), a memoria e o MMIO funcionam, mesmo
// sem nenhum jogo na pasta DolphinGC.
#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "cpu.h"
#include "memory.h"
#include "mmio.h"

namespace dps3 {

// Maquina virtual minima: RAM + hardware + CPU. Criada uma vez e reutilizada (a RAM do guest
// tem 24 MiB; alocar de novo a cada conta seria desperdicio).
class GuestVm {
 public:
  GuestVm() : cpu_(mem_) {}
  bool Init(std::string& err);
  bool LoadWords(uint32_t addr, const std::vector<uint32_t>& words);
  bool LoadBytes(uint32_t addr, const void* data, size_t len);
  // Reinicia a CPU em `entry` e roda ate o guest executar `sc` (ou o limite de passos).
  StopReason RunFrom(uint32_t entry, uint64_t max_steps);

  Memory& mem() { return mem_; }
  MmioHandler& hw() { return hw_; }
  Cpu& cpu() { return cpu_; }

 private:
  Memory mem_;
  MmioHandler hw_;
  Cpu cpu_;
  bool ready_ = false;
};

// Roda o Hello World. Devolve o texto que o guest escreveu na porta de console.
// `steps` (opcional) recebe quantas instrucoes PowerPC foram executadas.
bool RunHelloWorld(std::string& output, uint64_t* steps, std::string& err);

enum class CalcOp : char { Add = '+', Sub = '-', Mul = '*', Div = '/' };

// Calculadora de 4 operacoes com inteiros de 32 bits. Teclas: '0'..'9', '+', '-', '*', '/',
// '=' (ou Enter), 'C' (limpa), 'B' (apaga o ultimo digito).
class Calculator {
 public:
  Calculator();
  bool ok() const { return init_err_.empty(); }
  const std::string& init_error() const { return init_err_; }

  void Press(char key);
  std::string Display() const;      // numero mostrado (ou "ERRO")
  std::string Expression() const;   // ex.: "12 +" enquanto digita o 2o numero
  const std::string& error() const { return error_; }
  uint64_t guest_steps() const { return guest_steps_; }   // instrucoes PowerPC executadas no total
  uint32_t guest_ops() const { return guest_ops_; }       // quantas contas foram para a CPU

 private:
  // Executa a conta no guest. Devolve false (e preenche error_) em divisao por zero / estouro.
  bool Evaluate(int32_t a, CalcOp op, int32_t b, int32_t& result);
  void Fail(const std::string& why);

  std::unique_ptr<GuestVm> vm_;
  std::string init_err_, error_;
  int32_t acc_ = 0, cur_ = 0;
  CalcOp pending_ = CalcOp::Add;
  bool has_pending_ = false, entering_ = false;
  int digits_ = 0;
  uint64_t guest_steps_ = 0;
  uint32_t guest_ops_ = 0;
};

}  // namespace dps3
