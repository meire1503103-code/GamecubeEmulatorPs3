// DolphinGC V0.2 - fase 13: External Interface (EXI) & Cartões de Memória
#pragma once
#include <cstddef>
#include <cstdint>
#include <vector>
#include <string>

namespace dps3 {

class ExternalInterface {
public:
  bool Init();
  // Seleciona um canal EXI (0 a 2) e um dispositivo (ex: Cartão de Memória no Slot A/B)
  void SelectDevice(int channel, int device, bool select);
  // Transfere dados via DMA/Imediato pelo EXI
  bool Transfer(int channel, const uint8_t* src, uint8_t* dst, size_t size, uint32_t mode);
  // Controlo e estado dos registadores EXI
  void WriteReg(uint32_t addr, uint32_t value);
  uint32_t ReadReg(uint32_t addr) const;

private:
  struct MemoryCard {
    bool inserted = true;
    std::vector<uint8_t> data; // 8MB padrão GameCube
    std::string filename = "card_slot_a.raw";
    bool modified = false;
  };

  MemoryCard cards_[2]; // Slot A (0) e Slot B (1)
  int selected_channel_ = -1;
  int selected_device_ = -1;
  uint32_t exi_regs_[5] = {0};
};

} // namespace dps3
