// DolphinGC V0.2 - fase 12: Processador de Áudio (DSP / Digital Signal Processor)
#pragma once
#include <cstdint>
#include <vector>

namespace dps3 {

class Memory;

class AudioProcessor {
public:
  bool Init();
  // Processa o microcódigo ou comandos enviados para o DSP
  bool ProcessMailbox(uint32_t cpu_to_dsp, uint32_t& dsp_to_cpu);
  // Registo de controlo e estado do DSP
  void WriteReg(uint32_t addr, uint32_t value);
  uint32_t ReadReg(uint32_t addr) const;

private:
  uint32_t dsp_cr_ = 0;
  uint32_t dsp_control_ = 0;
  uint32_t mail_cpu_ = 0;
  uint32_t mail_dsp_ = 0;
};

} // namespace dps3
