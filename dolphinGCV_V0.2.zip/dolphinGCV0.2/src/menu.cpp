#include "menu.h"

#include <algorithm>
#include <cstdio>
#include <string>
#include <vector>

namespace dps3 {

bool MenuSystem::Init() {
  items_.clear();
  selected_ = 0;
  has_back_ = false;
  title_ = "DOLPHINGC V0.2 - MENU PRINCIPAL";
  // Os programas de demonstracao vem primeiro: funcionam sem nenhum jogo na pasta DolphinGC.
  AddItem("Hello World (programa PowerPC na CPU emulada)", MENU_ACTION_HELLO,
          "Tipo|Demonstracao\nExecuta|CPU emulada\nDisco|Nao precisa\n\nUm programa PowerPC de poucas instrucoes escreve a mensagem na porta de console.");
  AddItem("Calculadora (contas feitas pela CPU emulada)", MENU_ACTION_CALC,
          "Tipo|Demonstracao\nExecuta|CPU emulada\nDisco|Nao precisa\n\nCada conta (+ - * /) e feita por uma rotina PowerPC.");
  AddItem("Mario Kart Double Dash (pasta DolphinGC)", MENU_ACTION_LOAD_MKDD,
          "Jogo|Mario Kart: Double Dash!!\nIDs|GM4E / GM4P / GM4J\nLocal|pasta DolphinGC\n\nProcura o disco sozinho e mostra o relatorio do boot.");
  AddItem("Outro jogo / ISO (GameCube)", MENU_ACTION_LOAD_ISO,
          "Formatos|ISO / GCM\nLocal|pasta DolphinGC\n\nEscolha qualquer disco de GameCube da pasta.");
  AddItem("Listar FST do Disco (File System)", MENU_ACTION_LIST_FST,
          "Mostra os arquivos do disco\n(pastas, tamanhos e posicoes).");
  AddItem("Ver controles (PS3 -> GameCube)", MENU_ACTION_CONTROLS,
          "Mostra como os botoes do\ncontrole PS3 viram botoes\ndo controle de GameCube.");
  AddItem("Informacoes (versao do sistema)", MENU_ACTION_INFO,
          "Versao do DolphinGC, pasta dos\njogos e estado atual do projeto.");
  AddItem("Sair", MENU_ACTION_EXIT, "Fecha o DolphinGC e volta\npara o XMB.");
  return true;
}

void MenuSystem::SetItems(const std::vector<MenuItem>& items, const std::string& title) {
  items_ = items;
  title_ = title;
  selected_ = 0;
  has_back_ = false;
}

void MenuSystem::AddItem(const std::string& label, int action_id, const std::string& info) {
  items_.push_back(MenuItem{label, action_id, info});
}

void MenuSystem::RenderConsole(std::FILE* out) const {
  std::fprintf(out, "\n========================================\n");
  std::fprintf(out, "  %s\n", title_.c_str());
  std::fprintf(out, "========================================\n");
  for (size_t i = 0; i < items_.size(); ++i) {
    std::fprintf(out, " %s[%d] %s\n", static_cast<int>(i) == selected_ ? "> " : "  ",
                 static_cast<int>(i), items_[i].label.c_str());
  }
  std::fprintf(out, "========================================\n");
  std::fflush(out);
}

std::string MenuSystem::DefaultFooter() {
  return "D-Pad/Analogico: mover   X ou Start: confirmar   Bolinha: voltar";
}

void MenuSystem::RenderScreenPlain(TextScreen& screen, const std::string& footer) const {
  screen.Clear();
  screen.PutCentered(0, title_, kCyan);
  screen.HLine(1);
  const int n = static_cast<int>(items_.size());
  const int top = 3, bottom = screen.rows() - 3;           // area dos itens (inclusive)
  const int visible = bottom - top + 1 > 1 ? bottom - top + 1 : 1;
  int first = 0;                                           // rolagem: mantem o cursor a vista
  if (n > visible) {
    first = selected_ - visible / 2;
    if (first < 0) first = 0;
    if (first > n - visible) first = n - visible;
  }
  for (int row = 0; row < visible && first + row < n; ++row) {
    const int i = first + row, y = top + row;
    const bool sel = i == selected_;
    if (sel) screen.FillRow(y, kBlue);
    char head[32];
    std::snprintf(head, sizeof head, " %s[%d] ", sel ? "> " : "  ", i);
    screen.Put(1, y, std::string(head) + items_[i].label, sel ? kYellow : kWhite, sel ? kBlue : kBlack);
  }
  if (first > 0) screen.Put(screen.cols() - 3, top, "^", kGray);
  if (first + visible < n) screen.Put(screen.cols() - 3, bottom, "v", kGray);
  screen.HLine(screen.rows() - 2);
  screen.PutCentered(screen.rows() - 1, footer, kGray);
}

namespace {

// Corta com ".." se o texto nao couber em `w` colunas.
std::string Fit(const std::string& s, int w) {
  if (w <= 0) return std::string();
  if (static_cast<int>(s.size()) <= w) return s;
  if (w <= 2) return s.substr(0, static_cast<size_t>(w));
  return s.substr(0, static_cast<size_t>(w - 2)) + "..";
}

// Quebra `text` em linhas de ate `w` colunas (por palavras); respeita '\n'.
void Wrap(const std::string& text, int w, std::vector<std::string>& out) {
  size_t i = 0;
  while (i <= text.size()) {
    size_t nl = text.find('\n', i);
    if (nl == std::string::npos) nl = text.size();
    const std::string para = text.substr(i, nl - i);
    std::string cur, word;
    for (size_t k = 0; k <= para.size(); ++k) {
      if (k == para.size() || para[k] == ' ') {
        if (!word.empty()) {
          if (!cur.empty() && static_cast<int>(cur.size() + 1 + word.size()) > w) { out.push_back(cur); cur.clear(); }
          cur += (cur.empty() ? "" : " ") + word;
          word.clear();
        }
      } else {
        word.push_back(para[k]);
      }
    }
    out.push_back(cur);
    i = nl + 1;
  }
}

}  // namespace

void MenuSystem::RenderScreen(TextScreen& screen, const std::string& footer) const {
  if (!screen.beach()) { RenderScreenPlain(screen, footer); return; }

  // ---- Menu "praia": cabecalho, lista a esquerda, painel de detalhes a direita, dicas embaixo ----
  screen.Clear();
  screen.set_scenic(true);
  const int cols = screen.cols(), rows = screen.rows();
  screen.FillRow(0, kShade);
  screen.FillRow(1, kShade);
  screen.Put(2, 0, "DolphinGC", kWhite, kShade);
  screen.Put(cols - 7, 0, "V0.2", kCyan, kShade);
  screen.Put(2, 1, Fit(title_, cols - 4), kYellow, kShade);

  const int top = 3, bottom = rows - 3;                    // area das duas colunas (inclusive)
  const int list_w = std::max(20, cols * 45 / 100);        // largura da lista (colunas)
  const int px0 = list_w + 2;                              // painel de detalhes: de px0 ate cols-2
  const int n = static_cast<int>(items_.size());
  const int visible = bottom - top + 1 > 1 ? bottom - top + 1 : 1;
  int first = 0;
  if (n > visible) {
    first = selected_ - visible / 2;
    if (first < 0) first = 0;
    if (first > n - visible) first = n - visible;
  }

  // Os paineis tem so a altura necessaria (o resto da praia aparece embaixo).
  const int list_bottom = std::min(bottom, top + std::min(n, visible));
  const int info_bottom = std::min(bottom, top + 9);

  // Lista (vidro escuro; o item selecionado ganha a barra clara, como no Salsa64).
  for (int y = top; y <= list_bottom; ++y)
    for (int x = 1; x < list_w; ++x) screen.Put(x, y, " ", kWhite, kPanel);
  for (int row = 0; row < visible && first + row < n; ++row) {
    const int i = first + row, y = top + row;
    const bool sel = i == selected_;
    const Color bg = sel ? kBar : kPanel;
    if (sel) for (int x = 1; x < list_w; ++x) screen.Put(x, y, " ", kWhite, kBar);
    // So o nome curto (antes do primeiro " (") vai na lista; o resto fica no painel.
    std::string name = items_[i].label;
    const size_t par = name.find(" (");
    if (par != std::string::npos && par > 0) name = name.substr(0, par);
    screen.Put(2, y, sel ? ">" : " ", kYellow, bg);
    screen.Put(4, y, "[#]", sel ? kYellow : kCyan, bg);
    screen.Put(8, y, Fit(name, list_w - 9), sel ? kYellow : kWhite, bg);
  }
  if (first > 0) screen.Put(list_w - 2, top, "^", kWhite, kPanel);
  if (first + visible < n) screen.Put(list_w - 2, bottom, "v", kWhite, kPanel);

  // Painel de detalhes do item selecionado.
  if (px0 < cols - 2) {
    for (int y = top; y <= info_bottom; ++y)
      for (int x = px0; x < cols - 1; ++x) screen.Put(x, y, " ", kWhite, kPanel);
    if (selected_ >= 0 && selected_ < n) {
      const int w = cols - 1 - px0 - 2;
      screen.Put(px0 + 1, top, Fit(items_[selected_].label.substr(0, items_[selected_].label.find(" (")), w),
                 kYellow, kPanel);
      std::vector<std::string> lines;
      const std::string& info = items_[selected_].info;
      if (info.empty()) {
        char buf[48];
        std::snprintf(buf, sizeof buf, "Item %d de %d", selected_ + 1, n);
        lines.push_back(buf);
      }
      else Wrap(info, w, lines);
      int fw = 0;  // largura da coluna "campo" = maior campo + 2
      for (const std::string& ln : lines) {
        const size_t b = ln.find('|');
        if (b != std::string::npos && static_cast<int>(b) > fw) fw = static_cast<int>(b);
      }
      fw += 2;
      int y = top + 2;
      for (const std::string& ln : lines) {
        if (y > info_bottom) break;
        const size_t bar = ln.find('|');            // "Campo|valor": campo em cinza, valor em branco
        if (bar != std::string::npos) {
          screen.Put(px0 + 1, y, Fit(ln.substr(0, bar), fw - 1), kCyan, kPanel);
          screen.Put(px0 + 1 + fw, y, Fit(ln.substr(bar + 1), w - fw), kWhite, kPanel);
        } else {
          screen.Put(px0 + 1, y, Fit(ln, w), kWhite, kPanel);
        }
        ++y;
      }
    }
  }

  // Dicas de botoes no rodape.
  screen.FillRow(rows - 2, kShade);
  screen.FillRow(rows - 1, kShade);
  screen.PutCentered(rows - 2, footer, kWhite, kShade);
}

int MenuSystem::Handle(MenuInput in) {
  const int n = static_cast<int>(items_.size());
  switch (in) {
    case MenuInput::Up:
      if (n) selected_ = (selected_ + n - 1) % n;
      return -1;
    case MenuInput::Down:
      if (n) selected_ = (selected_ + 1) % n;
      return -1;
    case MenuInput::Confirm:
      return SelectOption(selected_);
    case MenuInput::Back:
      return has_back_ ? back_action_ : -1;
    case MenuInput::Left:
    case MenuInput::Right:
    case MenuInput::None:
      break;
  }
  return -1;
}

int MenuSystem::SelectOption(int choice) const {
  if (choice < 0 || choice >= static_cast<int>(items_.size())) return -1;
  return items_[choice].action_id;
}

MenuInput MenuInputFromPad(const Ps3PadState& prev, const Ps3PadState& cur) {
  // Analogico esquerdo conta como direcional, com histerese simples (>= 64 do centro).
  const bool prev_up = prev.dpad_up || prev.left_stick_y <= 64;
  const bool prev_down = prev.dpad_down || prev.left_stick_y >= 192;
  const bool cur_up = cur.dpad_up || cur.left_stick_y <= 64;
  const bool cur_down = cur.dpad_down || cur.left_stick_y >= 192;

  const bool prev_left = prev.dpad_left || prev.left_stick_x <= 64;
  const bool prev_right = prev.dpad_right || prev.left_stick_x >= 192;
  const bool cur_left = cur.dpad_left || cur.left_stick_x <= 64;
  const bool cur_right = cur.dpad_right || cur.left_stick_x >= 192;

  if (cur_up && !prev_up) return MenuInput::Up;
  if (cur_down && !prev_down) return MenuInput::Down;
  if (cur_left && !prev_left) return MenuInput::Left;
  if (cur_right && !prev_right) return MenuInput::Right;
  if ((cur.cross && !prev.cross) || (cur.start && !prev.start)) return MenuInput::Confirm;
  if (cur.circle && !prev.circle) return MenuInput::Back;
  return MenuInput::None;
}

MenuInput PadRepeater::Update(const Ps3PadState& cur, uint32_t now_ms) {
  const Ps3PadState prev = prev_;
  prev_ = cur;
  const MenuInput edge = MenuInputFromPad(prev, cur);
  const bool directional = edge == MenuInput::Up || edge == MenuInput::Down ||
                           edge == MenuInput::Left || edge == MenuInput::Right;
  if (edge != MenuInput::None) {
    held_ = directional ? edge : MenuInput::None;
    next_ms_ = now_ms + delay_;
    return edge;
  }
  if (held_ == MenuInput::None) return MenuInput::None;
  // Ainda segurando o mesmo sentido? (compara contra um pad neutro: so o sentido importa)
  const Ps3PadState neutral;
  Ps3PadState probe = cur;
  if (MenuInputFromPad(neutral, probe) != held_) { held_ = MenuInput::None; return MenuInput::None; }
  if (now_ms >= next_ms_) { next_ms_ = now_ms + rate_; return held_; }
  return MenuInput::None;
}

// Existe um unico perfil (GameCube); as funcoes ficam para o menu continuar igual.
ControllerProfile NextProfile(ControllerProfile) { return ControllerProfile::GameCube; }
ControllerProfile PrevProfile(ControllerProfile) { return ControllerProfile::GameCube; }

void RenderControlsScreen(ControllerProfile p, std::FILE* out) {
  std::fprintf(out, "\n========================================\n");
  std::fprintf(out, "  CONTROLES - perfil: %s\n", ProfileName(p));
  std::fprintf(out, "========================================\n");
  std::fputs(DescribeMapping(p).c_str(), out);
  std::fprintf(out, "========================================\n");
  std::fprintf(out, "  Bolinha: voltar\n");
  std::fflush(out);
}

void RenderControlsScreen(ControllerProfile p, TextScreen& screen) {
  screen.Clear();
  screen.PutCentered(0, std::string("CONTROLES - perfil: ") + ProfileName(p), kCyan);
  screen.HLine(1);
  const std::string text = DescribeMapping(p);
  int y = 3;
  size_t pos = 0;
  while (pos < text.size() && y < screen.rows() - 3) {
    size_t nl = text.find('\n', pos);
    if (nl == std::string::npos) nl = text.size();
    screen.Put(2, y++, text.substr(pos, nl - pos));
    pos = nl + 1;
  }
  screen.HLine(screen.rows() - 2);
  screen.PutCentered(screen.rows() - 1, "Bolinha: voltar", kGray);
}

} // namespace dps3
