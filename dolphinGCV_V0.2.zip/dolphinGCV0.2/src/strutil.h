// Pequenos auxiliares de texto. std::to_string nao existe em todo toolchain newlib (o do PS3
// inclusive), entao usamos snprintf.
#pragma once
#include <cstdio>
#include <string>

namespace dps3 {

inline std::string NumStr(long long v) {
  char b[32];
  std::snprintf(b, sizeof b, "%lld", v);
  return b;
}

inline std::string NumStrU(unsigned long long v) {
  char b[32];
  std::snprintf(b, sizeof b, "%llu", v);
  return b;
}

}  // namespace dps3
