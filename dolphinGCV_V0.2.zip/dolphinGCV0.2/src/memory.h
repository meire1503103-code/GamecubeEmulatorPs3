// DolphinGC V0.2 - fase 7: memoria do guest (MEM1 24 MiB) + BATs / MMU basica.
#pragma once
#include <cstddef>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>

namespace dps3 {

constexpr uint32_t kMem1Size = 24u * 1024u * 1024u;

// Registradores de hardware do Flipper: fisico 0x0C000000..0x0C00FFFF (CPU ve 0xCC000000).
constexpr uint32_t kMmioBase = 0x0C000000u;
constexpr uint32_t kMmioSize = 0x00010000u;

// Barramento de hardware: recebe leituras/escritas dos enderecos fisicos da janela MMIO.
class MmioBus {
 public:
  virtual ~MmioBus() {}
  virtual bool MmioRead(uint32_t phys, unsigned size, uint32_t& value) = 0;
  virtual bool MmioWrite(uint32_t phys, unsigned size, uint32_t value) = 0;
};

struct BatPair {
  uint32_t u = 0;  // Upper BAT (BEPI, BL, Vs, Vp)
  uint32_t l = 0;  // Lower BAT (BRPN, WIMG, PP)
};

class Memory {
 public:
  bool Init(std::string& err);
  // Liga o barramento de hardware (opcional). Sem ele, acessos a 0xCC00xxxx falham como antes.
  void SetMmio(MmioBus* bus) { mmio_ = bus; }

  // Atualiza registradores BAT (SPRs 528..543)
  void SetIbat(unsigned idx, bool upper, uint32_t val);
  void SetDbat(unsigned idx, bool upper, uint32_t val);
  uint32_t GetIbat(unsigned idx, bool upper) const;
  uint32_t GetDbat(unsigned idx, bool upper) const;

  // Traduz endereco efetivo (EA) para endereco fisico usando BATs (se translation_enabled)
  // ou mapeamento direto padrão do Gekko.
  bool Translate(uint32_t addr, uint32_t& phys, bool is_instruction = false, bool translation_enabled = false) const;

  // Caminho rapido (inline) para o modo real: sem BAT, so RAM. Devolve false se NAO conseguiu
  // (o chamador deve usar Read/Write, que tratam BAT, MMIO e erros).
  bool FastRead(uint32_t addr, unsigned size, uint32_t& value) const {
    const uint32_t seg = addr >> 28;
    const uint32_t p = addr & 0x0FFFFFFFu;
    if ((seg != 0x0 && seg != 0x8 && seg != 0xC) || p + size > kMem1Size || ram_.empty()) return false;
    const uint8_t* s = ram_.data() + p;
    if (size == 4) {
      uint32_t t; std::memcpy(&t, s, 4);
#if defined(__BYTE_ORDER__) && defined(__ORDER_LITTLE_ENDIAN__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
      t = __builtin_bswap32(t);
#endif
      value = t;
    } else if (size == 2) {
      uint16_t t; std::memcpy(&t, s, 2);
#if defined(__BYTE_ORDER__) && defined(__ORDER_LITTLE_ENDIAN__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
      t = __builtin_bswap16(t);
#endif
      value = t;
    } else value = *s;
    return true;
  }
  bool FastWrite(uint32_t addr, unsigned size, uint32_t value) {
    const uint32_t seg = addr >> 28;
    const uint32_t p = addr & 0x0FFFFFFFu;
    if ((seg != 0x0 && seg != 0x8 && seg != 0xC) || p + size > kMem1Size || ram_.empty()) return false;
    uint8_t* d = ram_.data() + p;
    if (size == 4) {
#if defined(__BYTE_ORDER__) && defined(__ORDER_LITTLE_ENDIAN__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
      value = __builtin_bswap32(value);
#endif
      std::memcpy(d, &value, 4);
    } else if (size == 2) {
      uint16_t t = static_cast<uint16_t>(value);
#if defined(__BYTE_ORDER__) && defined(__ORDER_LITTLE_ENDIAN__) && __BYTE_ORDER__ == __ORDER_LITTLE_ENDIAN__
      t = __builtin_bswap16(t);
#endif
      std::memcpy(d, &t, 2);
    } else *d = static_cast<uint8_t>(value);
    return true;
  }

  // size = 1, 2 ou 4. Big-endian (como o guest enxerga), independente do host.
  bool Read(uint32_t addr, unsigned size, uint32_t& value, bool is_instruction = false, bool translation_enabled = false) const;
  bool Write(uint32_t addr, unsigned size, uint32_t value, bool translation_enabled = false);

  bool ReadBlock(uint32_t addr, void* dst, size_t len, bool translation_enabled = false) const;
  bool WriteBlock(uint32_t addr, const void* src, size_t len, bool translation_enabled = false);
  bool Fill(uint32_t addr, uint8_t byte, size_t len, bool translation_enabled = false);

 private:
  bool TranslateBat(uint32_t ea, const BatPair bats[4], uint32_t& phys) const;
  bool Range(uint32_t addr, size_t len, uint32_t& phys, bool is_instruction = false, bool translation_enabled = false) const;
  std::vector<uint8_t> ram_;
  MmioBus* mmio_ = nullptr;
  BatPair ibat_[4];
  BatPair dbat_[4];
};

}  // namespace dps3
