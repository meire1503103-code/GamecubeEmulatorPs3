#include "hle.h"
#include "cpu.h"
#include "memory.h"
#include <cstdio>

namespace dps3 {

bool HleManager::CheckAndExecute(uint32_t pc, Cpu& cpu, Memory& mem) {
  // OSInit = 0x80003000
  if (pc == 0x80003000u) {
    std::printf("[HLE] OSInit() chamado. A inicializar subsistemas do OS...\n");
    cpu.gpr[3] = 0;
    cpu.pc = cpu.lr;
    return true;
  }
  // OSAlloc = 0x80003100 (Alocação de memória simulada)
  if (pc == 0x80003100u) {
    uint32_t size = cpu.gpr[3];
    std::printf("[HLE] OSAlloc(size=%u) chamado.\n", size);
    // Retorna um endereço de HEAP simulado em 0x81300000
    cpu.gpr[3] = 0x81300000u;
    cpu.pc = cpu.lr;
    return true;
  }
  // OSCreateThread = 0x80003200
  if (pc == 0x80003200u) {
    std::printf("[HLE] OSCreateThread() chamado.\n");
    cpu.gpr[3] = 1; // Sucesso
    cpu.pc = cpu.lr;
    return true;
  }
  // OSResumeThread = 0x80003300
  if (pc == 0x80003300u) {
    std::printf("[HLE] OSResumeThread() chamado.\n");
    cpu.gpr[3] = 1;
    cpu.pc = cpu.lr;
    return true;
  }
  // OSPanic = 0x80003020
  if (pc == 0x80003020u) {
    std::printf("[HLE] OSPanic() chamado pelo jogo!\n");
    cpu.pc = cpu.lr;
    return true;
  }
  return false;
}

void HleManager::RegisterStubs() {
  std::printf("[HLE] Stubs avançados do OS do GameCube (OSInit, OSAlloc, OSCreateThread) registados.\n");
}

} // namespace dps3
