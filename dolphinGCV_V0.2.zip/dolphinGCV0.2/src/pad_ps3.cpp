// Leitura do controle no PS3 via libpad (PSL1GHT). NAO TESTADO em hardware nem com o
// PSL1GHT real: os nomes dos campos de `padData` (BTN_*, ANA_*, PRE_*) seguem o io/pad.h
// do PSL1GHT conforme a documentacao/exemplos, mas podem precisar de ajuste no 1o build.
#ifdef DOLPHINPS3_PLATFORM_PS3

#include <io/pad.h>

#include "input.h"

namespace dps3 {

namespace {
bool g_pad_ready = false;
}

bool PadInit() {
  if (g_pad_ready) return true;
  g_pad_ready = (ioPadInit(7) == 0);
  return g_pad_ready;
}

bool PadPoll(Ps3PadState& out) {
  if (!g_pad_ready) return false;
  padInfo info;
  if (ioPadGetInfo(&info) != 0 || !info.status[0]) return false;
  padData d;
  if (ioPadGetData(0, &d) != 0 || d.len == 0) return false;

  out = Ps3PadState();  // volta ao estado neutro antes de preencher
  out.square = d.BTN_SQUARE;
  out.circle = d.BTN_CIRCLE;
  out.cross = d.BTN_CROSS;
  out.triangle = d.BTN_TRIANGLE;
  out.start = d.BTN_START;
  out.select = d.BTN_SELECT;
  out.l1 = d.BTN_L1;
  out.r1 = d.BTN_R1;
  out.l3 = d.BTN_L3;
  out.r3 = d.BTN_R3;
  // L2/R2: pressao analogica (PRE_*) quando o pad reporta; senao, digital = fundo de curso.
  out.l2_analog = (d.BTN_L2 && d.PRE_L2 == 0) ? 255 : static_cast<uint8_t>(d.PRE_L2);
  out.r2_analog = (d.BTN_R2 && d.PRE_R2 == 0) ? 255 : static_cast<uint8_t>(d.PRE_R2);
  out.dpad_up = d.BTN_UP;
  out.dpad_down = d.BTN_DOWN;
  out.dpad_left = d.BTN_LEFT;
  out.dpad_right = d.BTN_RIGHT;
  out.left_stick_x = static_cast<uint8_t>(d.ANA_L_H);
  out.left_stick_y = static_cast<uint8_t>(d.ANA_L_V);
  out.right_stick_x = static_cast<uint8_t>(d.ANA_R_H);
  out.right_stick_y = static_cast<uint8_t>(d.ANA_R_V);
  return true;
}

void PadShutdown() {
  if (g_pad_ready) ioPadEnd();
  g_pad_ready = false;
}

} // namespace dps3

#endif  // DOLPHINPS3_PLATFORM_PS3
