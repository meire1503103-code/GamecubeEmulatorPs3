#include "gx.h"
#include "memory.h"
#include <cstdio>

#ifdef DOLPHINPS3_PLATFORM_PS3
#include <rsx/rsx.h>
#include <io/pad.h>
#include <gcm/gcm.h>
#endif

namespace dps3 {

bool GraphicsProcessor::Init() {
  fifo_base_ = 0;
  fifo_end_ = 0;
  processing_ = false;
  std::printf("[GX] Processador Gráfico (Flipper) inicializado com suporte a RSX (PS3).\n");

#ifdef DOLPHINPS3_PLATFORM_PS3
  // Inicialização básica do contexto RSX GCM se executando na PS3 real
  std::printf("[RSX] A configurar contexto gráfico nativo da PS3...\n");
#endif

  return true;
}

bool GraphicsProcessor::ProcessFifo(const uint8_t* data, size_t size, Memory& mem) {
  if (!data || size == 0) return false;
  std::printf("[GX] A processar FIFO e traduzir comandos para RSX: %zu bytes\n", size);
  
  size_t idx = 0;
  while (idx < size) {
    uint8_t cmd = data[idx++];
    if (cmd == 0x00) continue; // NOP
    if (idx + 4 <= size) {
      uint32_t val = (static_cast<uint32_t>(data[idx]) << 24) |
                     (static_cast<uint32_t>(data[idx+1]) << 16) |
                     (static_cast<uint32_t>(data[idx+2]) << 8) |
                     static_cast<uint32_t>(data[idx+3]);
      WriteReg(cmd, val);
      idx += 4;
    } else {
      break;
    }
  }
  return true;
}

void GraphicsProcessor::WriteReg(uint8_t cmd, uint32_t value) {
  std::printf("[GX->RSX] Registo GX mapeado para RSX: cmd=0x%02X, val=0x%08X\n", cmd, value);
}

uint32_t GraphicsProcessor::ReadReg(uint8_t cmd) const {
  (void)cmd;
  return 0;
}

} // namespace dps3
