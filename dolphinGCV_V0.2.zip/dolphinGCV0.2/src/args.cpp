#include "args.h"

#include <cctype>

namespace dps3 {
namespace {

enum class Id { Version, Help, User, Movie, Exec, NandTitle, Config, SaveState,
                Debugger, Logger, Batch, Confirm, Video, Audio, ListFiles };

struct OptDef { char s; const char* l; bool takes_arg; Id id; };

// Nomes conforme o --help do Dolphin. O help mostra "nand_title" e
// "nand-title"; aceitamos ambos normalizando '-' para '_'.
const OptDef kOpts[] = {
    {0, "version", false, Id::Version},
    {'h', "help", false, Id::Help},
    {'u', "user", true, Id::User},
    {'m', "movie", true, Id::Movie},
    {'e', "exec", true, Id::Exec},
    {'n', "nand_title", true, Id::NandTitle},
    {'C', "config", true, Id::Config},
    {'s', "save_state", true, Id::SaveState},
    {'d', "debugger", false, Id::Debugger},
    {'l', "logger", false, Id::Logger},
    {'b', "batch", false, Id::Batch},
    {'c', "confirm", false, Id::Confirm},
    {'v', "video_backend", true, Id::Video},
    {'a', "audio_emulation", true, Id::Audio},
    {0, "list_files", false, Id::ListFiles},
};

const OptDef* FindShort(char c) {
  for (const OptDef& o : kOpts) if (o.s && o.s == c) return &o;
  return nullptr;
}
const OptDef* FindLong(const std::string& name) {
  std::string n = name;
  for (char& ch : n) if (ch == '-') ch = '_';
  for (const OptDef& o : kOpts) if (n == o.l) return &o;
  return nullptr;
}

bool ParseConfig(const std::string& v, ConfigOverride& c, std::string& err) {
  const size_t eq = v.find('=');
  const size_t d1 = v.find('.');
  const size_t d2 = (d1 == std::string::npos) ? d1 : v.find('.', d1 + 1);
  if (eq == std::string::npos || d1 == std::string::npos || d2 == std::string::npos ||
      d1 > eq || d2 > eq) {
    err = "formato invalido em -C/--config (esperado <System>.<Section>.<Key>=<Value>): " + v;
    return false;
  }
  c.system = v.substr(0, d1);
  c.section = v.substr(d1 + 1, d2 - d1 - 1);
  c.key = v.substr(d2 + 1, eq - d2 - 1);
  c.value = v.substr(eq + 1);
  if (c.system.empty() || c.section.empty() || c.key.empty()) {
    err = "-C/--config com campo vazio: " + v;
    return false;
  }
  return true;
}

bool Apply(LaunchOptions& o, const OptDef& d, const std::string& val, std::string& err) {
  switch (d.id) {
    case Id::Version: o.show_version = true; break;
    case Id::Help: o.show_help = true; break;
    case Id::User: o.user_dir = val; break;
    case Id::Movie: o.movie = val; break;
    case Id::Exec: o.exec_file = val; break;
    case Id::NandTitle: o.nand_title = val; break;
    case Id::SaveState: o.save_state = val; break;
    case Id::Debugger: o.debugger = true; break;
    case Id::Logger: o.logger = true; break;
    case Id::Batch: o.batch = true; break;
    case Id::Confirm: o.confirm_stop = true; break;
    case Id::Video: o.video_backend = val; break;
    case Id::Audio: o.audio_emulation = val; break;
    case Id::ListFiles: o.list_files = true; break;
    case Id::Config: {
      ConfigOverride c;
      if (!ParseConfig(val, c, err)) return false;
      o.configs.push_back(c);
      break;
    }
  }
  return true;
}

}  // namespace

bool ParseArgs(const std::vector<std::string>& args, LaunchOptions& out, std::string& err) {
  out = LaunchOptions();
  bool only_positional = false;
  for (size_t i = 0; i < args.size(); ++i) {
    const std::string& a = args[i];
    if (only_positional || a.size() < 2 || a[0] != '-') {
      out.files.push_back(a);
      continue;
    }
    if (a == "--") { only_positional = true; continue; }

    if (a[1] == '-') {  // opcao longa
      const size_t eq = a.find('=');
      const std::string name = a.substr(2, eq == std::string::npos ? eq : eq - 2);
      const OptDef* d = FindLong(name);
      if (!d) { err = "opcao desconhecida: " + a; return false; }
      std::string val;
      if (d->takes_arg) {
        if (eq != std::string::npos) val = a.substr(eq + 1);
        else if (i + 1 < args.size()) val = args[++i];
        else { err = "opcao exige valor: " + a; return false; }
      } else if (eq != std::string::npos) {
        err = "opcao nao aceita valor: " + a;
        return false;
      }
      if (!Apply(out, *d, val, err)) return false;
    } else {  // opcao(oes) curta(s), ex.: -d -l -ufolder -u folder -dl
      for (size_t j = 1; j < a.size(); ++j) {
        const OptDef* d = FindShort(a[j]);
        if (!d) { err = std::string("opcao desconhecida: -") + a[j]; return false; }
        std::string val;
        if (d->takes_arg) {
          if (j + 1 < a.size()) val = a.substr(j + 1);
          else if (i + 1 < args.size()) val = args[++i];
          else { err = std::string("opcao exige valor: -") + a[j]; return false; }
          if (!Apply(out, *d, val, err)) return false;
          break;
        }
        if (!Apply(out, *d, val, err)) return false;
      }
    }
  }

  if (out.batch && out.exec_file.empty() && out.nand_title.empty()) {
    err = "--batch exige --exec ou --nand_title";
    return false;
  }
  if (!out.nand_title.empty() && out.nand_title.size() != 16) {
    err = "--nand_title exige exatamente 16 caracteres ASCII";
    return false;
  }
  if (!out.audio_emulation.empty()) {
    std::string u = out.audio_emulation;
    for (char& ch : u) ch = static_cast<char>(std::toupper(static_cast<unsigned char>(ch)));
    if (u != "HLE" && u != "LLE") {
      err = "--audio_emulation deve ser HLE ou LLE";
      return false;
    }
    out.audio_emulation = u;
  }
  return true;
}

std::vector<std::string> TokenizeArgsText(const std::string& text) {
  std::vector<std::string> out;
  std::string cur;
  bool in_tok = false;
  char quote = 0;
  for (char c : text) {
    if (quote) {
      if (c == quote) quote = 0; else cur += c;
    } else if (c == '"' || c == '\'') {
      quote = c; in_tok = true;
    } else if (std::isspace(static_cast<unsigned char>(c))) {
      if (in_tok) { out.push_back(cur); cur.clear(); in_tok = false; }
    } else {
      cur += c; in_tok = true;
    }
  }
  if (in_tok) out.push_back(cur);
  return out;
}

const char* UsageText() {
  return
      "Usage: DolphinGC [options]... [FILE]...\n\n"
      "Options:\n"
      "  --version             show version and exit\n"
      "  -h, --help            show this help and exit\n"
      "  -u, --user=USER       User folder path\n"
      "  -m, --movie=MOVIE     Play a movie file (parsed only)\n"
      "  -e, --exec=<file>     Load the specified file\n"
      "  -n, --nand_title=ID   Launch a NAND title (16-char ID; parsed only)\n"
      "  -C, --config=<System>.<Section>.<Key>=<Value>\n"
      "  -s, --save_state=<file>\n"
      "  -d, --debugger        (parsed only)\n"
      "  -l, --logger          (parsed only)\n"
      "  -b, --batch           (requires --exec or --nand_title)\n"
      "  -c, --confirm         Set Confirm on Stop\n"
      "  -v, --video_backend=NAME\n"
      "  -a, --audio_emulation=HLE|LLE\n"
      "  --list_files          list the disc file system (FST) and exit\n";
}

}  // namespace dps3
