// DolphinGC V0.2 - fase 2: leitor da FST (File System Table) de discos GameCube.
#pragma once

#include "disc.h"

#include <cstddef>
#include <cstdint>
#include <string>
#include <vector>

namespace dps3 {

enum class FstEntryType {
    File,
    Directory
};

struct FstEntry {
    uint32_t index = 0;
    uint32_t parent_index = 0;
    uint32_t next_index = 0;  // diretorio: primeiro indice FORA dele; arquivo: index + 1

    FstEntryType type = FstEntryType::File;

    std::string name;
    std::string path;  // relativo a raiz, separado por '/', raiz = ""

    uint64_t offset = 0;
    uint64_t size = 0;
};

class GameCubeFst {
public:
    bool Load(DiscReader& disc, std::string& err);

    void Clear();

    const std::vector<FstEntry>& entries() const {
        return entries_;
    }

    const FstEntry* Get(uint32_t index) const;

    bool ReadFileChunk(
        DiscReader& disc,
        uint32_t index,
        uint64_t file_offset,
        void* dst,
        size_t length,
        std::string& err
    ) const;

    bool ReadFile(
        DiscReader& disc,
        uint32_t index,
        std::vector<uint8_t>& output,
        std::string& err
    ) const;

private:
    std::vector<FstEntry> entries_;
};

} // namespace dps3
