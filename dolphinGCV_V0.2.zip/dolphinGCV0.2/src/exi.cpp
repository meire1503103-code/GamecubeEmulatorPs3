#include "exi.h"
#include <cstdio>
#include <cstring>

namespace dps3 {

bool ExternalInterface::Init() {
  // Inicializa dois cartões de memória de 8MB simulados por defeito
  for (int i = 0; i < 2; ++i) {
    cards_[i].inserted = true;
    cards_[i].data.resize(8 * 1024 * 1024, 0xFF); // Cartão vazio preenchido com 0xFF (padrão Flash)
    cards_[i].filename = (i == 0) ? "card_slot_a.raw" : "card_slot_b.raw";
    cards_[i].modified = false;
  }
  selected_channel_ = -1;
  selected_device_ = -1;
  std::printf("[EXI] External Interface (EXI) e Cartões de Memória inicializados com sucesso.\n");
  return true;
}

void ExternalInterface::SelectDevice(int channel, int device, bool select) {
  if (select) {
    selected_channel_ = channel;
    selected_device_ = device;
    std::printf("[EXI] Canal EXI %d, Dispositivo %d selecionado.\n", channel, device);
  } else {
    if (selected_channel_ == channel && selected_device_ == device) {
      selected_channel_ = -1;
      selected_device_ = -1;
    }
  }
}

bool ExternalInterface::Transfer(int channel, const uint8_t* src, uint8_t* dst, size_t size, uint32_t mode) {
  if (channel < 0 || channel >= 2) return false;
  std::printf("[EXI] Transferência EXI no canal %d (tamanho: %zu bytes, modo: 0x%08X)\n", channel, size, mode);
  if (selected_channel_ == channel && cards_[channel].inserted) {
    if (src && dst == nullptr) {
      cards_[channel].modified = true;
    }
  }
  return true;
}

void ExternalInterface::WriteReg(uint32_t addr, uint32_t value) {
  std::printf("[EXI] Registo EXI escrito: addr=0x%08X, val=0x%08X\n", addr, value);
  uint32_t offset = (addr & 0xFF) / 4;
  if (offset < 5) {
    exi_regs_[offset] = value;
  }
}

uint32_t ExternalInterface::ReadReg(uint32_t addr) const {
  std::printf("[EXI] Registo EXI lido: addr=0x%08X\n", addr);
  uint32_t offset = (addr & 0xFF) / 4;
  if (offset < 5) {
    return exi_regs_[offset];
  }
  return 0;
}

} // namespace dps3
