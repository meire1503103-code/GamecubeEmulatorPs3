// DolphinGC V0.2 - fase 3: parser/carregador de executaveis .dol do GameCube/Wii.
//
// Header (0x100 bytes, big-endian): 7 secoes de texto + 11 de dados.
//   0x00 offsets no arquivo | 0x48 enderecos | 0x90 tamanhos (18 entradas cada)
//   0xD8 bss addr | 0xDC bss size | 0xE0 entry point
#pragma once
#include <cstdint>
#include <string>
#include <vector>

#include "disc.h"
#include "memory.h"

namespace dps3 {

constexpr uint32_t kDolHeaderSize = 0x100;
constexpr uint32_t kMaxDolSize = kMem1Size;  // um DOL nao cabe alem de MEM1

struct DolSection {
  uint32_t file_offset = 0, address = 0, size = 0;
  bool is_text = false;
};

struct DolImage {
  std::vector<DolSection> sections;  // somente as de tamanho > 0
  uint32_t bss_address = 0, bss_size = 0, entry = 0;
  uint32_t file_size = 0;  // bytes minimos que o arquivo precisa ter
};

// Valida e interpreta o header. `len` = bytes disponiveis em `data` (>= 0x100).
bool ParseDolHeader(const uint8_t* data, size_t len, DolImage& out, std::string& err);

// Copia as secoes para a memoria do guest e zera o bss. Verifica `file`.
bool LoadDol(const std::vector<uint8_t>& file, const DolImage& img, Memory& mem,
             std::string& err);

// GameCube: o offset do DOL principal fica em 0x420 do boot.bin (em bytes).
bool ReadDolFromDisc(DiscReader& disc, std::vector<uint8_t>& file, DolImage& img,
                     std::string& err);

}  // namespace dps3
