// DolphinPS3 - fase 1: parser de argumentos compativel com a CLI do Dolphin.exe.
#pragma once
#include <string>
#include <vector>

namespace dps3 {

struct ConfigOverride {
  std::string system, section, key, value;
};

struct LaunchOptions {
  bool show_help = false, show_version = false;
  bool debugger = false, logger = false, batch = false, confirm_stop = false;
  bool list_files = false;  // lista a FST do disco (extensao do DolphinGC)
  std::string user_dir, movie, exec_file, nand_title, save_state;
  std::string video_backend, audio_emulation;
  std::vector<ConfigOverride> configs;
  std::vector<std::string> files;  // argumentos posicionais [FILE]...
};

// Retorna false e preenche `err` em caso de erro. args NAO inclui argv[0].
bool ParseArgs(const std::vector<std::string>& args, LaunchOptions& out, std::string& err);

// Divide texto em tokens por espacos (aspas simples/duplas agrupam).
// Util no PS3, onde nao ha linha de comando: ler de um arquivo de texto.
std::vector<std::string> TokenizeArgsText(const std::string& text);

const char* UsageText();

}  // namespace dps3
