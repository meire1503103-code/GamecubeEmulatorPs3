#include "fst.h"

#include <cstring>
#include <limits>
#include <new>
#include <stdexcept>

namespace dps3 {
namespace {

constexpr uint32_t kFstNodeSize = 12;

// Heuristica de engenharia (NAO vem da especificacao): FSTs reais de GameCube
// sao pequenas, e cada FstEntry em memoria custa ~100 bytes (2 strings). Com
// apenas 256 MB de XDR no PS3, 4 MiB de FST ja pode virar dezenas de MB de
// entradas. Ajustar se algum disco real legitimo for recusado.
constexpr uint32_t kMaxFstSize = 4u * 1024u * 1024u;

uint32_t ReadBE32(const uint8_t* p) {
    return (uint32_t(p[0]) << 24) |
           (uint32_t(p[1]) << 16) |
           (uint32_t(p[2]) << 8) |
           uint32_t(p[3]);
}

bool ReadString(
    const uint8_t* table,
    size_t table_size,
    uint32_t offset,
    std::string& output
) {
    if (!table || offset >= table_size)
        return false;

    const uint8_t* begin = table + offset;

    const void* terminator =
        std::memchr(begin, 0, table_size - offset);

    if (!terminator)
        return false;

    const uint8_t* end =
        static_cast<const uint8_t*>(terminator);

    output.assign(
        reinterpret_cast<const char*>(begin),
        static_cast<size_t>(end - begin)
    );

    return true;
}

} // namespace

void GameCubeFst::Clear() {
    entries_.clear();
}

const FstEntry* GameCubeFst::Get(uint32_t index) const {
    if (static_cast<size_t>(index) >= entries_.size())
        return nullptr;

    return &entries_[index];
}

// Formato (campos big-endian), boot.bin do GameCube:
//   0x424 offset da FST, 0x428 tamanho da FST, 0x42C tamanho maximo da FST.
// Cada no tem 12 bytes:
//   byte 0      : 0 = arquivo, 1 = diretorio
//   bytes 1..3  : offset do nome na tabela de strings (logo apos os nos)
//   word 2      : diretorio = indice do pai ; arquivo = offset na ISO (bytes)
//   word 3      : diretorio = proximo indice (fim do diretorio) ; arquivo = tamanho
// No 0 e a raiz: pai 0, word 3 = numero total de nos.
bool GameCubeFst::Load(DiscReader& disc, std::string& err) {
    Clear();
    err.clear();

    if (disc.kind() != DiscKind::GameCube) {
        err = "O leitor FST aceita somente discos GameCube";
        return false;
    }

    uint8_t boot[0x430];

    if (!disc.Read(0, boot, sizeof(boot))) {
        err = "Falha ao ler boot header";
        return false;
    }

    const uint32_t fst_offset = ReadBE32(boot + 0x424);
    const uint32_t fst_size = ReadBE32(boot + 0x428);
    const uint32_t fst_max_size = ReadBE32(boot + 0x42C);

    if (fst_offset == 0 || fst_size < kFstNodeSize) {
        err = "Offset ou tamanho do FST invalido";
        return false;
    }

    if (fst_size > kMaxFstSize) {
        err = "FST ultrapassa o limite de memoria configurado";
        return false;
    }

    if (fst_offset > disc.size() ||
        static_cast<uint64_t>(fst_size) >
            disc.size() - fst_offset) {
        err = "FST ultrapassa os limites da ISO";
        return false;
    }

    if (fst_max_size != 0 && fst_size > fst_max_size) {
        err = "FST maior que o tamanho maximo declarado";
        return false;
    }

    std::vector<uint8_t> raw;

    try {
        raw.resize(static_cast<size_t>(fst_size));
    } catch (const std::bad_alloc&) {
        err = "Memoria insuficiente para carregar o FST";
        return false;
    } catch (const std::length_error&) {
        err = "Tamanho do FST nao suportado";
        return false;
    }

    if (!disc.Read(fst_offset, raw.data(), raw.size())) {
        err = "Falha ao ler dados do FST";
        return false;
    }

    const uint32_t root_type = ReadBE32(raw.data()) >> 24;
    const uint32_t root_parent = ReadBE32(raw.data() + 4);
    const uint32_t node_count = ReadBE32(raw.data() + 8);

    if (root_type != 1 || node_count == 0) {
        err = "Entrada raiz do FST invalida";
        return false;
    }

    if (root_parent != 0) {
        err = "Indice pai da raiz FST invalido";
        return false;
    }

    if (node_count > fst_size / kFstNodeSize) {
        err = "Quantidade de nos excede o tamanho do FST";
        return false;
    }

    const uint64_t node_bytes =
        static_cast<uint64_t>(node_count) * kFstNodeSize;

    // Nao pode falhar apos a checagem acima; mantida como defesa.
    if (node_bytes > fst_size) {
        err = "Tabela de nos ultrapassa o FST";
        return false;
    }

    const size_t string_table_size =
        static_cast<size_t>(fst_size - node_bytes);

    const uint8_t* string_table =
        raw.data() + static_cast<size_t>(node_bytes);

    std::vector<FstEntry> parsed_entries;
    std::vector<uint32_t> directory_stack;

    try {
        parsed_entries.reserve(node_count);
        directory_stack.reserve(64);
    } catch (const std::bad_alloc&) {
        err = "Memoria insuficiente para criar a arvore FST";
        return false;
    } catch (const std::length_error&) {
        err = "Quantidade de nos FST nao suportada";
        return false;
    }

    try {
        for (uint32_t i = 0; i < node_count; ++i) {
            const uint8_t* node =
                raw.data() + static_cast<size_t>(i) * kFstNodeSize;

            const uint32_t type_name = ReadBE32(node);
            const uint32_t type = type_name >> 24;
            const uint32_t name_offset = type_name & 0x00FFFFFF;

            const uint32_t second = ReadBE32(node + 4);
            const uint32_t third = ReadBE32(node + 8);

            if (type > 1) {
                err = "Tipo de entrada FST desconhecido";
                return false;
            }

            FstEntry entry;
            entry.index = i;

            if (i == 0) {
                // Raiz: o nome nao e usado (path vazio), entao nao e lido.
                entry.type = FstEntryType::Directory;
                entry.parent_index = 0;
                entry.next_index = third;  // == node_count

                parsed_entries.push_back(entry);
                directory_stack.push_back(0);
                continue;
            }

            if (!ReadString(
                    string_table,
                    string_table_size,
                    name_offset,
                    entry.name)) {
                err = "Nome invalido na tabela de strings do FST";
                return false;
            }

            // Fecha os diretorios cujo intervalo terminou antes de i.
            while (!directory_stack.empty()) {
                const uint32_t current = directory_stack.back();

                if (i < parsed_entries[current].next_index)
                    break;

                directory_stack.pop_back();
            }

            if (directory_stack.empty()) {
                err = "Arvore FST possui diretorio pai ausente";
                return false;
            }

            const uint32_t parent = directory_stack.back();

            // Copia por valor: push_back abaixo pode realocar o vetor.
            const std::string parent_path = parsed_entries[parent].path;
            const uint32_t parent_next = parsed_entries[parent].next_index;

            entry.parent_index = parent;

            if (parent_path.empty()) {
                entry.path = entry.name;
            } else {
                entry.path = parent_path + "/" + entry.name;
            }

            if (type == 1) {
                if (second != parent ||
                    third <= i ||
                    third > node_count ||
                    third > parent_next) {
                    err = "Limites ou indice pai do diretorio FST invalidos";
                    return false;
                }

                entry.type = FstEntryType::Directory;
                entry.next_index = third;

                parsed_entries.push_back(entry);
                directory_stack.push_back(i);
            } else {
                const uint64_t file_offset = second;
                const uint64_t file_size = third;

                if (file_offset > disc.size() ||
                    file_size > disc.size() - file_offset) {
                    err = "Arquivo FST ultrapassa os limites da ISO";
                    return false;
                }

                entry.type = FstEntryType::File;
                entry.offset = file_offset;
                entry.size = file_size;
                entry.next_index = i + 1;

                parsed_entries.push_back(entry);
            }
        }
    } catch (const std::bad_alloc&) {
        err = "Memoria insuficiente para criar a arvore FST";
        return false;
    } catch (const std::length_error&) {
        err = "Caminho FST grande demais";
        return false;
    }

    if (parsed_entries.size() != node_count) {
        err = "Quantidade final de entradas FST inconsistente";
        return false;
    }

    entries_.swap(parsed_entries);
    return true;
}

bool GameCubeFst::ReadFileChunk(
    DiscReader& disc,
    uint32_t index,
    uint64_t file_offset,
    void* dst,
    size_t length,
    std::string& err
) const {
    err.clear();

    const FstEntry* entry = Get(index);

    if (!entry) {
        err = "Indice FST inexistente";
        return false;
    }

    if (entry->type != FstEntryType::File) {
        err = "Entrada selecionada nao e arquivo";
        return false;
    }

    if (file_offset > entry->size ||
        static_cast<uint64_t>(length) >
            entry->size - file_offset) {
        err = "Leitura ultrapassa o tamanho do arquivo";
        return false;
    }

    if (length == 0)
        return true;

    if (!dst) {
        err = "Buffer de destino nulo";
        return false;
    }

    if (entry->offset >
        std::numeric_limits<uint64_t>::max() - file_offset) {
        err = "Overflow no offset do arquivo";
        return false;
    }

    const uint64_t absolute_offset =
        entry->offset + file_offset;

    if (!disc.Read(absolute_offset, dst, length)) {
        err = "Falha ao ler bloco do arquivo na ISO";
        return false;
    }

    return true;
}

bool GameCubeFst::ReadFile(
    DiscReader& disc,
    uint32_t index,
    std::vector<uint8_t>& output,
    std::string& err
) const {
    output.clear();
    err.clear();

    const FstEntry* entry = Get(index);

    if (!entry) {
        err = "Indice FST inexistente";
        return false;
    }

    if (entry->type != FstEntryType::File) {
        err = "Entrada selecionada nao e arquivo";
        return false;
    }

    if (entry->size >
        static_cast<uint64_t>(
            std::numeric_limits<size_t>::max())) {
        err = "Arquivo grande demais para este sistema";
        return false;
    }

    try {
        output.resize(static_cast<size_t>(entry->size));
    } catch (const std::bad_alloc&) {
        output.clear();
        err = "Memoria insuficiente para carregar o arquivo";
        return false;
    } catch (const std::length_error&) {
        output.clear();
        err = "Tamanho do arquivo nao suportado";
        return false;
    }

    if (!ReadFileChunk(
            disc,
            index,
            0,
            output.empty() ? nullptr : output.data(),
            output.size(),
            err)) {
        output.clear();
        return false;
    }

    return true;
}

} // namespace dps3
