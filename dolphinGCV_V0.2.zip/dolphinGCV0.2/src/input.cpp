#include "input.h"

#include <cstdlib>

namespace dps3 {

namespace {

int Clamp(int v, int lo, int hi) { return v < lo ? lo : (v > hi ? hi : v); }

// Eixo bruto -> valor assinado (-128..+128) ja com zona morta e reescala. `invert` troca o sinal.
// O curso bruto e assimetrico (0 = -128, 255 = +127), entao cada lado e reescalado ate o seu
// proprio fim de curso: assim 0 e 255 chegam aos extremos de verdade.
int SignedAxis(uint8_t raw, int deadzone, bool invert) {
  deadzone = Clamp(deadzone, 0, 100);
  const int v = static_cast<int>(raw) - 128;  // -128..127
  const int mag = std::abs(v);
  int out = 0;
  if (mag > deadzone) {
    const int limit = v < 0 ? 128 : 127;
    out = ((mag - deadzone) * limit) / (limit - deadzone);
    out = Clamp(out, 0, limit);
    if (v < 0) out = -out;
  }
  return invert ? -out : out;  // PS3: 0 = cima  ->  Nintendo: alto = cima
}

// D-Pad: direcoes opostas pressionadas juntas se anulam (o hardware Nintendo nao as reporta).
void DpadBits(const Ps3PadState& s, bool& up, bool& down, bool& left, bool& right) {
  up = s.dpad_up && !s.dpad_down;
  down = s.dpad_down && !s.dpad_up;
  left = s.dpad_left && !s.dpad_right;
  right = s.dpad_right && !s.dpad_left;
}

}  // namespace

uint8_t ConvertAxis(uint8_t raw, int deadzone, bool invert) {
  return static_cast<uint8_t>(Clamp(128 + SignedAxis(raw, deadzone, invert), 0, 255));
}

uint8_t ConvertTrigger(uint8_t raw, uint8_t deadzone) {
  if (raw <= deadzone) return 0;
  // Reescala (deadzone..255) -> (0..255).
  const int span = 255 - deadzone;
  return static_cast<uint8_t>(((raw - deadzone) * 255) / (span ? span : 1));
}

// ---------------------------------------------------------------- GameCube
GameCubePadState MapPs3ToGameCube(const Ps3PadState& ps3, const InputConfig& cfg) {
  GameCubePadState gc;

  if (ps3.square)   gc.buttons |= GC_BTN_A;
  if (ps3.circle)   gc.buttons |= GC_BTN_B;
  if (ps3.cross)    gc.buttons |= GC_BTN_X;
  if (ps3.triangle) gc.buttons |= GC_BTN_Y;
  if (ps3.start)    gc.buttons |= GC_BTN_START;
  if (ps3.r1)       gc.buttons |= GC_BTN_Z;

  bool up, down, left, right;
  DpadBits(ps3, up, down, left, right);
  if (up)    gc.buttons |= GC_BTN_UP;
  if (down)  gc.buttons |= GC_BTN_DOWN;
  if (left)  gc.buttons |= GC_BTN_LEFT;
  if (right) gc.buttons |= GC_BTN_RIGHT;

  gc.trigger_l = ConvertTrigger(ps3.l2_analog, cfg.trigger_deadzone);
  gc.trigger_r = ConvertTrigger(ps3.r2_analog, cfg.trigger_deadzone);

  // L2/R2 "clicam" o botao digital quando chegam ao fim do curso (antes so o R fazia isso).
  if (ps3.l2_analog >= cfg.trigger_click) gc.buttons |= GC_BTN_L;
  if (ps3.r2_analog >= cfg.trigger_click) gc.buttons |= GC_BTN_R;

  // L1 = L com clique completo (digital + analogico no maximo).
  if (ps3.l1) {
    gc.buttons |= GC_BTN_L;
    gc.trigger_l = 255;
  }

  gc.main_stick_x = ConvertAxis(ps3.left_stick_x, cfg.stick_deadzone, false);
  gc.main_stick_y = ConvertAxis(ps3.left_stick_y, cfg.stick_deadzone, true);
  gc.c_stick_x    = ConvertAxis(ps3.right_stick_x, cfg.stick_deadzone, false);
  gc.c_stick_y    = ConvertAxis(ps3.right_stick_y, cfg.stick_deadzone, true);
  return gc;
}

// ---------------------------------------------------------------- Perfis
const char* ProfileName(ControllerProfile) { return "GameCube"; }

std::string DescribeMapping(ControllerProfile) {
  return "Quadrado           = A\n"
         "Bolinha            = B\n"
         "X                  = X\n"
         "Triangulo          = Y\n"
         "Start              = Start\n"
         "R1                 = Z\n"
         "L1                 = L (clique completo)\n"
         "L2 / R2            = L / R analogicos (clique digital no fim do curso)\n"
         "D-Pad              = D-Pad\n"
         "Analogico esquerdo = Stick principal\n"
         "Analogico direito  = C-Stick\n";
}

// ---------------------------------------------------------------- Leitura do pad (host)
#ifndef DOLPHINPS3_PLATFORM_PS3
bool PadInit() { return false; }
bool PadPoll(Ps3PadState&) { return false; }
void PadShutdown() {}
#endif

} // namespace dps3
