#include "screen.h"

#include <algorithm>
#include <cmath>

#include "font8x16.h"

namespace dps3 {

void TextScreen::Resize(int cols, int rows) {
  cols_ = std::max(1, cols);
  rows_ = std::max(1, rows);
  cells_.assign(static_cast<size_t>(cols_) * rows_, Cell());
  shown_.clear();  // forca um redesenho completo
}

void TextScreen::Clear(Color bg) {
  scenic_ = false;  // cada tela comeca com a praia escurecida; so o menu bonito liga de novo
  Cell c;
  c.bg = bg;
  std::fill(cells_.begin(), cells_.end(), c);
}

void TextScreen::Put(int x, int y, const std::string& s, Color fg, Color bg) {
  if (y < 0 || y >= rows_) return;
  for (size_t i = 0; i < s.size(); ++i, ++x) {
    if (x < 0) continue;
    if (x >= cols_) break;
    char ch = s[i];
    if (ch < kFirstGlyph || ch > kLastGlyph) ch = '?';
    Cell& c = cells_[static_cast<size_t>(y) * cols_ + x];
    c.ch = ch; c.fg = fg; c.bg = bg;
  }
}

void TextScreen::PutCentered(int y, const std::string& s, Color fg, Color bg) {
  Put((cols_ - static_cast<int>(s.size())) / 2, y, s, fg, bg);
}

void TextScreen::FillRow(int y, Color bg) {
  if (y < 0 || y >= rows_) return;
  for (int x = 0; x < cols_; ++x) {
    Cell& c = cells_[static_cast<size_t>(y) * cols_ + x];
    c.ch = ' '; c.bg = bg;
  }
}

void TextScreen::HLine(int y, char ch, Color fg) {
  Put(0, y, std::string(static_cast<size_t>(cols_), ch), fg);
}

std::string TextScreen::RowText(int y) const {
  std::string s;
  if (y < 0 || y >= rows_) return s;
  for (int x = 0; x < cols_; ++x) s.push_back(cells_[static_cast<size_t>(y) * cols_ + x].ch);
  while (!s.empty() && s.back() == ' ') s.pop_back();
  return s;
}

bool TextScreen::TakeDirty() {
  if (shown_ == cells_ && shown_scenic_ == scenic_) return false;
  shown_ = cells_;
  shown_scenic_ = scenic_;
  return true;
}

uint32_t TextScreen::RgbOf(Color c) {
  static const uint32_t kPal[kColorCount] = {
    0x00101018, 0x00F0F0F0, 0x00FFD84A, 0x0050D8F0, 0x0060E070, 0x00FF5050, 0x00808890, 0x002A4A9A,
    0x000A1E50, 0x002F6FE0, 0x00061030};
  return kPal[c < kColorCount ? c : kWhite];
}

namespace {

inline int Clamp255(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }
inline uint32_t Rgb(int r, int g, int b) {
  return (static_cast<uint32_t>(Clamp255(r)) << 16) | (static_cast<uint32_t>(Clamp255(g)) << 8) |
         static_cast<uint32_t>(Clamp255(b));
}
inline int Lerp(int a, int b, int t256) { return a + (b - a) * t256 / 256; }
inline uint32_t Mix(uint32_t a, uint32_t b, int t256) {  // t256 0..256: quanto de `b`
  return Rgb(Lerp(static_cast<int>((a >> 16) & 255), static_cast<int>((b >> 16) & 255), t256),
             Lerp(static_cast<int>((a >> 8) & 255), static_cast<int>((b >> 8) & 255), t256),
             Lerp(static_cast<int>(a & 255), static_cast<int>(b & 255), t256));
}

// Fundo de praia desenhado por codigo (sem imagem): ceu, sol com brilho, mar turquesa com ondas e
// reflexo, espuma e areia. Calculado uma vez por resolucao e guardado na RAM comum.
void BuildBeach(std::vector<uint32_t>& bg, int w, int h) {
  bg.assign(static_cast<size_t>(w) * h, 0);
  const int horizon = h * 52 / 100, shore = h * 70 / 100;
  const int sunx = w * 74 / 100, suny = h * 26 / 100, sunr = std::max(6, h / 13);
  const int glow = sunr * 5;
  for (int y = 0; y < h; ++y) {
    uint32_t row;
    if (y < horizon) row = Mix(Rgb(24, 96, 200), Rgb(176, 226, 248), y * 256 / std::max(1, horizon));
    else if (y < shore) row = Mix(Rgb(18, 140, 190), Rgb(78, 214, 205), (y - horizon) * 256 / std::max(1, shore - horizon));
    else row = Mix(Rgb(246, 224, 172), Rgb(212, 176, 116), (y - shore) * 256 / std::max(1, h - shore));
    uint32_t* p = bg.data() + static_cast<size_t>(y) * w;
    for (int x = 0; x < w; ++x) {
      uint32_t c = row;
      if (y < horizon) {
        const int dx = x - sunx, dy = y - suny;
        const int d2 = dx * dx + dy * dy;
        if (d2 < sunr * sunr) {
          c = Rgb(255, 248, 205);
        } else if (d2 < glow * glow) {
          const float d = __builtin_sqrtf(static_cast<float>(d2));
          const float g = 1.0f - (d - sunr) / static_cast<float>(glow - sunr);
          c = Mix(c, Rgb(255, 240, 190), static_cast<int>(g * g * 200.0f));
        }
      } else if (y < shore) {
        const int k = y - horizon;
        if (((x + (y * y) / 7) % 130) < 4 && (k % 3) != 0) c = Mix(c, Rgb(235, 255, 250), 90);          // cristas
        const int half = 6 + k / 3;                                                                        // reflexo do sol
        if ((x > sunx ? x - sunx : sunx - x) < half && (y % 6) < 3) c = Mix(c, Rgb(255, 250, 215), 110);
      } else if (y < shore + 4) {
        c = Mix(c, Rgb(255, 255, 255), y < shore + 2 ? 220 : 120);                                          // espuma
      } else if (((static_cast<unsigned>(x) * 73856093u) ^ (static_cast<unsigned>(y) * 19349663u)) % 29u == 0u) {
        c = Mix(c, Rgb(150, 112, 70), 70);                                                                  // graos de areia
      }
      p[x] = c;
    }
  }
}

}  // namespace

void TextScreen::Rasterize(uint32_t* dst, int width, int height, int pitch_px, int scale) const {
  if (!dst || scale < 1) return;
  const int gw = kGlyphW * scale, gh = kGlyphH * scale;
  const int ox = std::max(0, (width - cols_ * gw) / 2);
  const int oy = std::max(0, (height - rows_ * gh) / 2);
  const uint32_t bg0 = RgbOf(kBlack);

  // Fundo de praia em cache (RAM comum): refeito so se a resolucao mudar.
  static std::vector<uint32_t> beach_cache;
  static int beach_w = 0, beach_h = 0;
  if (beach_) {
    if (beach_w != width || beach_h != height) { BuildBeach(beach_cache, width, height); beach_w = width; beach_h = height; }
  }

  // Uma linha de pixels de cada vez, sempre escrevendo em ordem crescente (memoria de video).
  std::vector<uint32_t> line(static_cast<size_t>(width));
  for (int y = 0; y < height; ++y) {
    std::vector<uint32_t>::iterator lb = line.begin();
    if (beach_) {
      const uint32_t* src = beach_cache.data() + static_cast<size_t>(y) * width;
      if (scenic_) std::copy(src, src + width, lb);
      else for (int x = 0; x < width; ++x) line[x] = Mix(src[x], bg0, 170);  // escurece p/ ler o texto
    } else {
      std::fill(line.begin(), line.end(), bg0);
    }
    const int ry = y - oy;
    if (ry >= 0 && ry < rows_ * gh) {
      const int row = ry / gh, gy = (ry % gh) / scale;
      for (int col = 0; col < cols_; ++col) {
        const Cell& c = cells_[static_cast<size_t>(row) * cols_ + col];
        if (ox + (col + 1) * gw > width) break;
        const uint32_t fg = RgbOf(static_cast<Color>(c.fg));
        const uint8_t bits = kFont8x16[(static_cast<unsigned char>(c.ch) - kFirstGlyph) * kGlyphH + gy];
        uint32_t* p = line.data() + ox + col * gw;
        if (!beach_) {
          const uint32_t bg = RgbOf(static_cast<Color>(c.bg));
          for (int gx = 0; gx < kGlyphW; ++gx) {
            const uint32_t px = (bits & (0x80 >> gx)) ? fg : bg;
            for (int s = 0; s < scale; ++s) *p++ = px;
          }
          continue;
        }
        // Modo praia: kBlack = transparente; kPanel/kBar/kShade = vidro translucido.
        int alpha = 256;                       // 256 = cor solida
        if (c.bg == kBlack) alpha = 0;
        else if (c.bg == kPanel) alpha = 170;
        else if (c.bg == kBar) alpha = 215;
        else if (c.bg == kShade) alpha = 190;
        const uint32_t bgc = RgbOf(static_cast<Color>(c.bg));
        for (int gx = 0; gx < kGlyphW; ++gx) {
          const bool on = (bits & (0x80 >> gx)) != 0;
          for (int s = 0; s < scale; ++s, ++p) {
            if (on) *p = fg;
            else if (alpha == 256) *p = bgc;
            else if (alpha > 0) *p = Mix(*p, bgc, alpha);
          }
        }
      }
    }
    std::copy(line.begin(), line.end(), dst + static_cast<size_t>(y) * pitch_px);
  }
}

void TextScreen::DumpText(std::FILE* out) const {
  int last = rows_ - 1;
  while (last > 0 && RowText(last).empty()) --last;
  std::fputc('\n', out);
  for (int y = 0; y <= last; ++y) std::fprintf(out, "%s\n", RowText(y).c_str());
  std::fflush(out);
}

}  // namespace dps3
