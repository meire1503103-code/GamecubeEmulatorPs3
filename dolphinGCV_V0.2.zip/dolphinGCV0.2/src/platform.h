// DolphinGC V0.2 - camada de plataforma: video (RSX), eventos do sistema (XMB) e tempo.
// PS3: platform_ps3.cpp (PSL1GHT).  PC: platform.cpp (so terminal; sem video).
#pragma once
#include "screen.h"

namespace dps3 {

// Liga o que a plataforma precisa. No PS3: callback do sistema (botao PS / "Sair do jogo") e
// video da RSX. Devolve false se o video nao subiu (o app continua, so que sem imagem).
bool PlatformInit(TextScreen& screen);
void PlatformShutdown();

// Processa eventos do sistema. Devolve false quando o usuario pediu para fechar o app (XMB).
// Precisa ser chamada com frequencia (varias vezes por segundo) ou o PS3 acha que o app travou.
bool PlatformPump();

// Mostra a grade na TV (PS3) ou no terminal (PC). So redesenha se a grade mudou.
void PlatformPresent(TextScreen& screen);

void PlatformSleepMs(unsigned ms);

}  // namespace dps3
