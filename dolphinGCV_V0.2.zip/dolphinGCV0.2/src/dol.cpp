#include "dol.h"

#include <new>

namespace dps3 {
namespace {

constexpr unsigned kTextSlots = 7, kDataSlots = 11, kSlots = kTextSlots + kDataSlots;

uint32_t BE32(const uint8_t* p) {
  return (uint32_t(p[0]) << 24) | (uint32_t(p[1]) << 16) | (uint32_t(p[2]) << 8) | p[3];
}

// [addr, addr+size) precisa caber inteiro em MEM1.
bool RangeMapped(uint32_t addr, uint32_t size) {
  const uint32_t seg = addr >> 28;
  if (seg != 0x0 && seg != 0x8 && seg != 0xC) return false;
  const uint32_t phys = addr & 0x0FFFFFFFu;
  return static_cast<uint64_t>(phys) + size <= kMem1Size;
}

}  // namespace

bool ParseDolHeader(const uint8_t* h, size_t len, DolImage& out, std::string& err) {
  out = DolImage();
  err.clear();
  if (!h || len < kDolHeaderSize) { err = "DOL menor que o header de 0x100 bytes"; return false; }

  uint64_t needed = kDolHeaderSize;
  for (unsigned i = 0; i < kSlots; ++i) {
    const uint32_t off = BE32(h + 4 * i);
    const uint32_t addr = BE32(h + 0x48 + 4 * i);
    const uint32_t size = BE32(h + 0x90 + 4 * i);
    if (size == 0) continue;

    if (off < kDolHeaderSize) { err = "secao do DOL com offset dentro do header"; return false; }
    if (static_cast<uint64_t>(off) + size > kMaxDolSize) {
      err = "secao do DOL excede o tamanho maximo aceito"; return false;
    }
    if (addr & 3) { err = "secao do DOL com endereco nao alinhado a 4 bytes"; return false; }
    if (!RangeMapped(addr, size)) {
      err = "secao do DOL fora da MEM1 (24 MiB)"; return false;
    }
    DolSection s;
    s.file_offset = off; s.address = addr; s.size = size; s.is_text = i < kTextSlots;
    out.sections.push_back(s);
    if (static_cast<uint64_t>(off) + size > needed) needed = static_cast<uint64_t>(off) + size;
  }
  if (out.sections.empty()) { err = "DOL sem nenhuma secao"; return false; }

  out.bss_address = BE32(h + 0xD8);
  out.bss_size = BE32(h + 0xDC);
  out.entry = BE32(h + 0xE0);
  if (out.bss_size && !RangeMapped(out.bss_address, out.bss_size)) {
    err = "bss do DOL fora da MEM1"; return false;
  }
  if ((out.entry & 3) || !RangeMapped(out.entry, 4)) {
    err = "entry point do DOL invalido"; return false;
  }
  out.file_size = static_cast<uint32_t>(needed);
  return true;
}

bool LoadDol(const std::vector<uint8_t>& file, const DolImage& img, Memory& mem,
             std::string& err) {
  err.clear();
  if (file.size() < img.file_size) { err = "arquivo DOL truncado"; return false; }
  for (const DolSection& s : img.sections) {
    if (static_cast<uint64_t>(s.file_offset) + s.size > file.size()) {
      err = "secao do DOL alem do fim do arquivo"; return false;
    }
    if (!mem.WriteBlock(s.address, file.data() + s.file_offset, s.size)) {
      err = "falha ao copiar secao do DOL para a memoria"; return false;
    }
  }
  if (img.bss_size && !mem.Fill(img.bss_address, 0, img.bss_size)) {
    err = "falha ao zerar o bss"; return false;
  }
  return true;
}

bool ReadDolFromDisc(DiscReader& disc, std::vector<uint8_t>& file, DolImage& img,
                     std::string& err) {
  file.clear();
  err.clear();
  if (disc.kind() != DiscKind::GameCube) {
    err = "carga de DOL do disco so implementada para GameCube"; return false;
  }
  uint8_t w[4];
  if (!disc.Read(0x420, w, sizeof w)) { err = "falha ao ler o offset do DOL (0x420)"; return false; }
  const uint64_t dol_off = BE32(w);
  if (dol_off < 0x440 || dol_off > disc.size()) { err = "offset do DOL invalido"; return false; }

  uint8_t hdr[kDolHeaderSize];
  if (!disc.Read(dol_off, hdr, sizeof hdr)) { err = "falha ao ler o header do DOL"; return false; }
  if (!ParseDolHeader(hdr, sizeof hdr, img, err)) return false;
  if (dol_off + img.file_size > disc.size()) { err = "DOL ultrapassa o fim da ISO"; return false; }

  try {
    file.resize(img.file_size);
  } catch (const std::bad_alloc&) {
    err = "memoria insuficiente para ler o DOL"; return false;
  }
  if (!disc.Read(dol_off, file.data(), file.size())) {
    file.clear(); err = "falha ao ler o DOL"; return false;
  }
  return true;
}

}  // namespace dps3
