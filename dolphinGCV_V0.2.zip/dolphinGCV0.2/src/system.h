// DolphinGC V0.2 - laco principal: CPU + relogio de hardware (retrace, interrupcoes, controle).
#pragma once
#include <cstdint>

#include "cpu.h"
#include "input.h"
#include "mmio.h"

namespace dps3 {

// Fonte do controle (PS3: libpad -> GameCube). Devolve false se nao ha controle conectado.
typedef bool (*PadSource)(GameCubePadState& out);

// Chamado de tempos em tempos durante RunSystem (a cada ~65 mil passos) com o total de passos ja
// executados. Serve para atualizar a tela, tratar o botao PS do XMB e cancelar: devolva false
// para parar (RunSystem devolve StopReason::Cancelled).
typedef bool (*ProgressFn)(uint64_t steps_done, void* user);

// Roda a CPU em blocos; entre blocos avanca o hardware (VI/retrace) e entrega interrupcoes
// externas (0x500). O controle e o callback de progresso rodam a cada kPollEveryChunks blocos
// (ler o pad a cada bloco de 4096 passos era ~16x mais frequente do que o necessario).
// Para na primeira condicao de parada da CPU.
StopReason RunSystem(Cpu& cpu, MmioHandler& hw, uint64_t max_steps, PadSource pad = nullptr,
                     ProgressFn progress = nullptr, void* progress_user = nullptr);

}  // namespace dps3
