#include "apploader.h"

#include <cstdio>
#include <vector>

#include "cpu.h"
#include "disc.h"
#include "memory.h"

namespace dps3 {
namespace {

// Area de trabalho no topo da MEM1 (24 MiB termina em 0x81800000).
constexpr uint32_t kReturnAddr = 0x817FFFE0u;   // "endereco de retorno": a chamada termina ao chegar aqui
constexpr uint32_t kOsReportStub = 0x817FFFD0u;  // OSReport falso: apenas 'blr'
constexpr uint32_t kScratch = 0x817FFF00u;       // 3 ponteiros (entry) ou 3 palavras (main)
constexpr uint32_t kStackTop = 0x817FFE00u;
constexpr uint32_t kBlr = 0x4E800020u;
constexpr uint64_t kCallStepLimit = 50000000ull;
constexpr unsigned kMaxChunks = 4096;

uint32_t BE32(const uint8_t* p) {
  return (uint32_t(p[0]) << 24) | (uint32_t(p[1]) << 16) | (uint32_t(p[2]) << 8) | p[3];
}

std::string Hex(uint32_t v) {
  char b[16];
  std::snprintf(b, sizeof b, "0x%08X", v);
  return b;
}

// Chama uma funcao do guest (convencao PowerPC EABI: args em r3..r5, retorno em r3) e roda ate ela voltar.
bool CallGuest(Cpu& cpu, uint32_t fn, uint32_t a0, uint32_t a1, uint32_t a2, const char* name,
               std::string& err) {
  cpu.pc = fn;
  cpu.lr = kReturnAddr;
  cpu.gpr[1] = kStackTop;
  cpu.gpr[3] = a0; cpu.gpr[4] = a1; cpu.gpr[5] = a2;
  for (uint64_t i = 0; i < kCallStepLimit; ++i) {
    if (cpu.pc == kReturnAddr) return true;
    const StopReason r = cpu.Step();
    if (r != StopReason::Running) {
      err = std::string("apploader parou em ") + name + ": " + StopReasonName(r) + " (pc=" + Hex(cpu.pc) +
            ", instr=" + Hex(cpu.last_instr) + ", endereco=" + Hex(cpu.fault_addr) + ")";
      return false;
    }
  }
  err = std::string("apploader em ") + name + ": limite de passos (laco infinito?)";
  return false;
}

}  // namespace

bool Apploader::LoadAndRun(DiscReader& disc, Memory& mem, Cpu& cpu, uint32_t& game_entry, std::string& err) {
  chunks_ = 0; bytes_ = 0;
  if (disc.kind() != DiscKind::GameCube) { err = "apploader: so discos GameCube"; return false; }

  uint8_t hdr[0x20];
  if (!disc.Read(kApploaderDiscOffset, hdr, sizeof hdr)) { err = "falha ao ler o header do apploader"; return false; }
  const uint32_t entry = BE32(hdr + 0x10), size = BE32(hdr + 0x14), trailer = BE32(hdr + 0x18);
  const uint64_t total = static_cast<uint64_t>(size) + trailer;
  if (size == 0 || total > 0x00400000u || entry < kApploaderLoadAddr || entry >= kApploaderLoadAddr + total) {
    err = "header do apploader invalido (entry=" + Hex(entry) + ", size=" + Hex(size) + ")";
    return false;
  }

  std::vector<uint8_t> body(static_cast<size_t>(total));
  if (!disc.Read(kApploaderDiscOffset + 0x20, body.data(), body.size()) ||
      !mem.WriteBlock(kApploaderLoadAddr, body.data(), body.size())) {
    err = "falha ao carregar a imagem do apploader em " + Hex(kApploaderLoadAddr);
    return false;
  }
  if (!mem.Write(kReturnAddr, 4, kBlr) || !mem.Write(kOsReportStub, 4, kBlr)) { err = "area de trabalho invalida"; return false; }

  cpu.Reset(entry);
  cpu.msr = 0x2000;  // MSR[FP] ligado, como o BS2 deixa

  // 1) entry(&init, &main, &close)
  if (!CallGuest(cpu, entry, kScratch, kScratch + 4, kScratch + 8, "entry", err)) return false;
  uint32_t init_fn = 0, main_fn = 0, close_fn = 0;
  if (!mem.Read(kScratch, 4, init_fn) || !mem.Read(kScratch + 4, 4, main_fn) || !mem.Read(kScratch + 8, 4, close_fn) ||
      !init_fn || !main_fn || !close_fn) {
    err = "apploader nao devolveu os ponteiros init/main/close";
    return false;
  }

  // 2) init(OSReport)
  if (!CallGuest(cpu, init_fn, kOsReportStub, 0, 0, "init", err)) return false;

  // 3) main(&dest, &size, &offset) ate devolver 0
  for (;; ) {
    if (chunks_ >= kMaxChunks) { err = "apploader pediu trechos demais (laco infinito?)"; return false; }
    if (!CallGuest(cpu, main_fn, kScratch, kScratch + 4, kScratch + 8, "main", err)) return false;
    if (cpu.gpr[3] == 0) break;
    uint32_t dest = 0, len = 0, off = 0;
    mem.Read(kScratch, 4, dest); mem.Read(kScratch + 4, 4, len); mem.Read(kScratch + 8, 4, off);
    if (len == 0) { ++chunks_; continue; }
    if (len > kMem1Size) { err = "trecho do apploader grande demais: " + Hex(len); return false; }
    std::vector<uint8_t> buf(len, 0);
    if (off < disc.size()) {  // alem do fim da imagem: zeros (ISOs cortadas)
      const uint64_t avail = disc.size() - off;
      if (!disc.Read(off, buf.data(), static_cast<size_t>(avail < len ? avail : len))) { err = "falha ao ler o disco em " + Hex(off); return false; }
    }
    if (!mem.WriteBlock(dest, buf.data(), len)) {
      err = "destino invalido do apploader: " + Hex(dest) + " (+" + Hex(len) + ")";
      return false;
    }
    ++chunks_; bytes_ += len;
  }

  // 4) close() -> entry point do jogo
  if (!CallGuest(cpu, close_fn, 0, 0, 0, "close", err)) return false;
  game_entry = cpu.gpr[3];
  if (game_entry < 0x80000000u || game_entry >= 0x80000000u + kMem1Size) {
    err = "entry do jogo invalido: " + Hex(game_entry);
    return false;
  }
  return true;
}

}  // namespace dps3
