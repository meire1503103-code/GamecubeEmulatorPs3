#include "dsp.h"
#include <cstdio>

namespace dps3 {

bool AudioProcessor::Init() {
  dsp_cr_ = 0;
  dsp_control_ = 0;
  mail_cpu_ = 0;
  mail_dsp_ = 0;
  std::printf("[DSP] Processador de Áudio (DSP) inicializado com sucesso.\n");
  return true;
}

bool AudioProcessor::ProcessMailbox(uint32_t cpu_to_dsp, uint32_t& dsp_to_cpu) {
  mail_cpu_ = cpu_to_dsp;
  std::printf("[DSP] Mailbox CPU -> DSP recebido: 0x%08X\n", cpu_to_dsp);
  // Resposta padrão simulada do microcódigo do DSP
  dsp_to_cpu = 0x80000000u;
  mail_dsp_ = dsp_to_cpu;
  return true;
}

void AudioProcessor::WriteReg(uint32_t addr, uint32_t value) {
  std::printf("[DSP] Registo DSP escrito: addr=0x%08X, val=0x%08X\n", addr, value);
  if (addr == 0) {
    dsp_control_ = value;
  }
}

uint32_t AudioProcessor::ReadReg(uint32_t addr) const {
  std::printf("[DSP] Registo DSP lido: addr=0x%08X\n", addr);
  if (addr == 0) {
    return dsp_control_;
  }
  return 0;
}

} // namespace dps3
