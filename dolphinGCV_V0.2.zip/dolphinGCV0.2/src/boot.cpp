#include "boot.h"

#include <vector>

#include "apploader.h"

namespace dps3 {

namespace {

// Memoria baixa: o IPL copia o inicio do header do disco (game ID etc.) e preenche as globais do OS.
bool PrepareLowMemory(DiscReader& disc, Memory& mem, std::string& err) {
  uint8_t hdr[0x20];
  if (!disc.Read(0, hdr, sizeof hdr) || !mem.WriteBlock(0x80000000u, hdr, sizeof hdr)) {
    err = "falha ao preparar a memoria baixa"; return false;
  }
  bool ok = true;
  ok = ok && mem.Write(0x80000020u, 4, 0x0D15EA5Eu);  // "boot normal"
  ok = ok && mem.Write(0x80000024u, 4, 1);            // versao
  ok = ok && mem.Write(0x80000028u, 4, kMem1Size);    // tamanho da memoria fisica
  ok = ok && mem.Write(0x800000ECu, 4, 0x80000000u + kMem1Size);  // topo da MEM1 (0x81800000)
  ok = ok && mem.Write(0x800000F0u, 4, kMem1Size);    // tamanho simulado da memoria
  ok = ok && mem.Write(0x800000F8u, 4, 162000000u);   // clock do barramento (162 MHz)
  ok = ok && mem.Write(0x800000FCu, 4, 486000000u);   // clock da CPU (486 MHz)
  if (!ok) { err = "falha ao escrever globais da memoria baixa"; return false; }
  return true;
}

}  // namespace

bool BootGameCubeDol(DiscReader& disc, Memory& mem, Cpu& cpu, DolImage& info,
                     std::string& err) {
  std::vector<uint8_t> dol;
  if (!ReadDolFromDisc(disc, dol, info, err)) return false;
  if (!LoadDol(dol, info, mem, err)) return false;
  if (!PrepareLowMemory(disc, mem, err)) return false;

  cpu.Reset(info.entry);
  cpu.msr = 0x2000;          // MSR[FP]: sem isso a 1a instrucao de ponto flutuante gera excecao 0x800
  cpu.gpr[1] = 0x816FFFF0u;  // pilha inicial (valor usado pelo boot HLE do Dolphin; conferir no fonte)
  return true;
}

bool BootGameCubeApploader(DiscReader& disc, Memory& mem, Cpu& cpu, uint32_t& entry, std::string& err) {
  if (!PrepareLowMemory(disc, mem, err)) return false;
  Apploader app;
  if (!app.LoadAndRun(disc, mem, cpu, entry, err)) return false;
  cpu.Reset(entry);
  cpu.msr = 0x2000;
  cpu.gpr[1] = 0x816FFFF0u;
  return true;
}

}  // namespace dps3
