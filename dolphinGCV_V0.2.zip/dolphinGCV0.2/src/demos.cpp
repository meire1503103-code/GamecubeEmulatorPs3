#include "demos.h"

#include <cstdio>
#include <cstring>
#include <map>

#include "strutil.h"

namespace dps3 {
namespace {

// ------------------------------------------------------------------ mini montador PowerPC
// So as instrucoes que as demos usam. Rotulos podem ser usados antes de definidos.
class Asm {
 public:
  explicit Asm(uint32_t base) : base_(base) {}

  void li(unsigned rt, int16_t v) { D(14, rt, 0, static_cast<uint16_t>(v)); }
  void lis(unsigned rt, uint16_t v) { D(15, rt, 0, v); }
  void ori(unsigned ra, unsigned rs, uint16_t v) { D(24, rs, ra, v); }
  void addi(unsigned rt, unsigned ra, int16_t v) { D(14, rt, ra, static_cast<uint16_t>(v)); }
  void lbz(unsigned rt, int16_t d, unsigned ra) { D(34, rt, ra, static_cast<uint16_t>(d)); }
  void stb(unsigned rs, int16_t d, unsigned ra) { D(38, rs, ra, static_cast<uint16_t>(d)); }
  void cmpwi(unsigned ra, int16_t v) { D(11, 0, ra, static_cast<uint16_t>(v)); }  // cr0
  void add(unsigned rt, unsigned ra, unsigned rb) { X(31, rt, ra, rb, 266); }
  void subf(unsigned rt, unsigned ra, unsigned rb) { X(31, rt, ra, rb, 40); }   // rt = rb - ra
  void mullw(unsigned rt, unsigned ra, unsigned rb) { X(31, rt, ra, rb, 235); }
  void divw(unsigned rt, unsigned ra, unsigned rb) { X(31, rt, ra, rb, 491); }
  void sc() { w_.push_back(0x44000002u); }

  void label(const std::string& n) { labels_[n] = static_cast<uint32_t>(w_.size()); }
  void b(const std::string& n) { Fix(n, 18u << 26); }
  void beq(const std::string& n) { Fix(n, (16u << 26) | (12u << 21) | (2u << 16)); }  // bc 12,eq
  void bne(const std::string& n) { Fix(n, (16u << 26) | (4u << 21) | (2u << 16)); }   // bc 4,eq

  uint32_t base() const { return base_; }
  uint32_t here() const { return base_ + 4u * static_cast<uint32_t>(w_.size()); }

  // Resolve os desvios (todos relativos). Rotulo inexistente: desvia para si mesmo (aparece nos testes).
  std::vector<uint32_t> Finish() {
    for (size_t i = 0; i < fix_.size(); ++i) {
      const auto it = labels_.find(fix_[i].name);
      const int32_t off = it == labels_.end() ? 0 : static_cast<int32_t>((it->second - fix_[i].at) * 4);
      uint32_t& wd = w_[fix_[i].at];
      if ((wd >> 26) == 18) wd |= static_cast<uint32_t>(off) & 0x03FFFFFCu;
      else wd |= static_cast<uint32_t>(off) & 0xFFFCu;
    }
    return w_;
  }

 private:
  struct Fixup { uint32_t at; std::string name; };
  void D(unsigned op, unsigned rt, unsigned ra, uint16_t imm) {
    w_.push_back((op << 26) | (rt << 21) | (ra << 16) | imm);
  }
  void X(unsigned op, unsigned rt, unsigned ra, unsigned rb, unsigned xo) {
    w_.push_back((op << 26) | (rt << 21) | (ra << 16) | (rb << 11) | (xo << 1));
  }
  void Fix(const std::string& n, uint32_t opcode) {
    fix_.push_back({static_cast<uint32_t>(w_.size()), n});
    w_.push_back(opcode);
  }
  uint32_t base_;
  std::vector<uint32_t> w_;
  std::map<std::string, uint32_t> labels_;
  std::vector<Fixup> fix_;
};

constexpr uint32_t kCodeAddr = 0x80003100u;
constexpr uint32_t kDataAddr = 0x80003400u;
constexpr uint32_t kConsoleAddr = 0xCC000000u | kConsolePortOffset;
constexpr uint64_t kDemoMaxSteps = 1000000ull;

// Hello World: r3 = ponteiro da string, r4 = endereco da porta de console.
std::vector<uint32_t> BuildHello() {
  Asm a(kCodeAddr);
  a.lis(3, kDataAddr >> 16);
  a.ori(3, 3, kDataAddr & 0xFFFF);
  a.lis(4, kConsoleAddr >> 16);
  a.ori(4, 4, kConsoleAddr & 0xFFFF);
  a.label("loop");
  a.lbz(5, 0, 3);
  a.cmpwi(5, 0);
  a.beq("done");
  a.stb(5, 0, 4);
  a.addi(3, 3, 1);
  a.b("loop");
  a.label("done");
  a.sc();
  return a.Finish();
}

// Calculadora: entrada r3 = a, r4 = b, r5 = operacao (0 + , 1 - , 2 * , 3 /).
// Saida r3 = resultado, r6 = 0 ok / 1 divisao por zero / 2 operacao invalida.
std::vector<uint32_t> BuildCalc() {
  Asm a(kCodeAddr);
  a.li(6, 0);
  a.cmpwi(5, 0); a.beq("add");
  a.cmpwi(5, 1); a.beq("sub");
  a.cmpwi(5, 2); a.beq("mul");
  a.cmpwi(5, 3); a.beq("div");
  a.li(6, 2); a.b("end");
  a.label("add"); a.add(3, 3, 4); a.b("end");
  a.label("sub"); a.subf(3, 4, 3); a.b("end");   // r3 = r3 - r4
  a.label("mul"); a.mullw(3, 3, 4); a.b("end");
  a.label("div");
  a.cmpwi(4, 0); a.beq("div0");
  a.divw(3, 3, 4); a.b("end");
  a.label("div0"); a.li(6, 1); a.li(3, 0);
  a.label("end");
  a.sc();
  return a.Finish();
}

}  // namespace

// ------------------------------------------------------------------ GuestVm
bool GuestVm::Init(std::string& err) {
  if (!mem_.Init(err)) return false;
  mem_.SetMmio(&hw_);
  hw_.Attach(&mem_, nullptr);
  ready_ = true;
  return true;
}

bool GuestVm::LoadWords(uint32_t addr, const std::vector<uint32_t>& words) {
  for (size_t i = 0; i < words.size(); ++i)
    if (!mem_.Write(addr + 4u * static_cast<uint32_t>(i), 4, words[i])) return false;
  return true;
}

bool GuestVm::LoadBytes(uint32_t addr, const void* data, size_t len) {
  return mem_.WriteBlock(addr, data, len);
}

StopReason GuestVm::RunFrom(uint32_t entry, uint64_t max_steps) {
  if (!ready_) return StopReason::MemFault;
  cpu_.Reset(entry);
  return cpu_.Run(max_steps);
}

// ------------------------------------------------------------------ Hello World
bool RunHelloWorld(std::string& output, uint64_t* steps, std::string& err) {
  GuestVm vm;
  if (!vm.Init(err)) return false;
  static const char kText[] =
      "Hello, World!\n"
      "Ola do PowerPC emulado (Gekko) rodando no DolphinGC V0.2!\n";
  if (!vm.LoadWords(kCodeAddr, BuildHello()) || !vm.LoadBytes(kDataAddr, kText, sizeof kText)) {
    err = "falha ao copiar o programa para a RAM do guest";
    return false;
  }
  const StopReason why = vm.RunFrom(kCodeAddr, kDemoMaxSteps);
  if (why != StopReason::Syscall) {
    err = std::string("o programa nao terminou: ") + StopReasonName(why);
    return false;
  }
  output = vm.hw().console();
  if (steps) *steps = vm.cpu().steps();
  return true;
}

// ------------------------------------------------------------------ Calculadora
Calculator::Calculator() : vm_(new GuestVm) {
  if (!vm_->Init(init_err_)) return;
  if (!vm_->LoadWords(kCodeAddr, BuildCalc())) init_err_ = "falha ao copiar a rotina para a RAM do guest";
}

void Calculator::Fail(const std::string& why) {
  error_ = why;
  acc_ = cur_ = 0;
  has_pending_ = entering_ = false;
  digits_ = 0;
}

bool Calculator::Evaluate(int32_t a, CalcOp op, int32_t b, int32_t& result) {
  // Estouro de 32 bits: o PowerPC apenas "da a volta"; a calculadora prefere avisar.
  int64_t exact = 0;
  switch (op) {
    case CalcOp::Add: exact = static_cast<int64_t>(a) + b; break;
    case CalcOp::Sub: exact = static_cast<int64_t>(a) - b; break;
    case CalcOp::Mul: exact = static_cast<int64_t>(a) * b; break;
    case CalcOp::Div: exact = b ? static_cast<int64_t>(a) / b : 0; break;
  }
  if (op != CalcOp::Div || b != 0) {
    if (exact > INT32_MAX || exact < INT32_MIN) { Fail("ESTOURO (maior que 32 bits)"); return false; }
  }
  unsigned code = 0;
  switch (op) { case CalcOp::Add: code = 0; break; case CalcOp::Sub: code = 1; break;
                case CalcOp::Mul: code = 2; break; case CalcOp::Div: code = 3; break; }
  Cpu& cpu = vm_->cpu();
  cpu.Reset(kCodeAddr);
  cpu.gpr[3] = static_cast<uint32_t>(a);
  cpu.gpr[4] = static_cast<uint32_t>(b);
  cpu.gpr[5] = code;
  const StopReason why = cpu.Run(kDemoMaxSteps);
  guest_steps_ += cpu.steps();
  ++guest_ops_;
  if (why != StopReason::Syscall) { Fail(std::string("CPU parou: ") + StopReasonName(why)); return false; }
  if (cpu.gpr[6] == 1) { Fail("DIVISAO POR ZERO"); return false; }
  if (cpu.gpr[6] != 0) { Fail("OPERACAO INVALIDA"); return false; }
  result = static_cast<int32_t>(cpu.gpr[3]);
  return true;
}

void Calculator::Press(char key) {
  if (!ok()) return;
  if (key == '\n' || key == '\r') key = '=';
  if (key == 'c') key = 'C';
  if (key == 'b') key = 'B';
  if (!error_.empty() && key != 'C') { if (key >= '0' && key <= '9') error_.clear(); else return; }

  if (key == 'C') {
    error_.clear(); acc_ = cur_ = 0; has_pending_ = entering_ = false; digits_ = 0;
  } else if (key >= '0' && key <= '9') {
    if (!entering_) { cur_ = 0; digits_ = 0; entering_ = true; }
    if (digits_ < 9) { cur_ = cur_ * 10 + (key - '0'); if (cur_ != 0) ++digits_; }
  } else if (key == 'B') {
    if (entering_) { cur_ /= 10; if (digits_ > 0) --digits_; }
  } else if (key == '+' || key == '-' || key == '*' || key == '/') {
    if (has_pending_ && entering_) {
      int32_t r;
      if (!Evaluate(acc_, pending_, cur_, r)) return;
      acc_ = r;
    } else if (!has_pending_) {
      acc_ = cur_;
    }
    pending_ = static_cast<CalcOp>(key);
    has_pending_ = true;
    entering_ = false;
    cur_ = acc_;
  } else if (key == '=') {
    if (has_pending_) {
      int32_t r;
      if (!Evaluate(acc_, pending_, entering_ ? cur_ : acc_, r)) return;
      acc_ = cur_ = r;
      has_pending_ = false;
      entering_ = false;
    }
  }
}

std::string Calculator::Display() const {
  if (!error_.empty()) return "ERRO";
  return NumStr(cur_);
}

std::string Calculator::Expression() const {
  if (!error_.empty()) return error_;
  if (has_pending_) return NumStr(acc_) + " " + static_cast<char>(pending_);
  return "";
}

}  // namespace dps3
