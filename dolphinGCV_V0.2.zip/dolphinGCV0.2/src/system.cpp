#include "system.h"

#include <algorithm>

namespace dps3 {

StopReason RunSystem(Cpu& cpu, MmioHandler& hw, uint64_t max_steps, PadSource pad,
                     ProgressFn progress, void* progress_user) {
  constexpr uint64_t kChunk = 4096;
  constexpr unsigned kPollEveryChunks = 16;  // ~65 mil passos
  uint64_t done = 0;
  unsigned until_poll = 0;                    // 0 => consulta ja no primeiro bloco
  while (done < max_steps) {
    if (until_poll == 0) {
      until_poll = kPollEveryChunks;
      if (pad) { GameCubePadState p; if (pad(p)) hw.SetPad(p); }
      if (progress && !progress(done, progress_user)) return StopReason::Cancelled;
    }
    --until_poll;
    const uint64_t n = std::min<uint64_t>(kChunk, max_steps - done);
    const StopReason r = cpu.Run(n);
    done += n;
    hw.Tick(n);
    if (hw.InterruptPending()) cpu.RequestExternalInterrupt(); else cpu.ClearExternalInterrupt();
    if (r != StopReason::StepLimit) return r;
  }
  return StopReason::StepLimit;
}

}  // namespace dps3
