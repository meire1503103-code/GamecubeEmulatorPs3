// DolphinGC V0.2 - fase 3: boot "direto" de um DOL do disco (sem IPL/apploader).
#pragma once
#include <string>

#include "cpu.h"
#include "disc.h"
#include "dol.h"
#include "memory.h"

namespace dps3 {

// Carrega o DOL principal do disco GameCube na MEM1, preenche as globais da
// memoria baixa (0x80000000..) que o OS espera e posiciona a CPU no entry point.
// LIMITACAO: pula o apploader e o BS2 reais. Jogos que dependem de valores
// que o BS2 deixa na memoria baixa (arena, tipo de console...) podem falhar
// cedo; rodar o apploader e o caminho mais robusto (fase futura).
bool BootGameCubeDol(DiscReader& disc, Memory& mem, Cpu& cpu, DolImage& info,
                     std::string& err);

// Boot pelo caminho real: carrega o apploader do disco e o executa na CPU emulada (ele mesmo
// copia o DOL do jogo para a RAM). Mais fiel que BootGameCubeDol, mas depende de a CPU
// executar todas as instrucoes do apploader. Em caso de erro, `err` diz onde parou.
bool BootGameCubeApploader(DiscReader& disc, Memory& mem, Cpu& cpu, uint32_t& entry, std::string& err);

}  // namespace dps3
