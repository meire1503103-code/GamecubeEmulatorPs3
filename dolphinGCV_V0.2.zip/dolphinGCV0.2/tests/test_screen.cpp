#include "check.h"
#include "screen.h"
#include "font8x16.h"

#include <vector>

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;

void TestGrid() {
  std::printf("[SIM] screen: grade, corte nas bordas e deteccao de mudanca\n");
  TextScreen s;
  s.Resize(20, 4);
  CHECK(s.cols() == 20 && s.rows() == 4);
  CHECK(s.TakeDirty());                 // 1a vez: tudo precisa ser desenhado
  CHECK(!s.TakeDirty());                // nada mudou: nao redesenha
  s.Put(0, 0, "ola");
  CHECK(s.RowText(0) == "ola");
  CHECK(s.TakeDirty() && !s.TakeDirty());
  s.Put(0, 0, "ola");                   // mesmo conteudo: continua sem mudanca
  CHECK(!s.TakeDirty());
  s.Put(18, 1, "abcdef");               // corta em vez de estourar
  CHECK(s.RowText(1) == "                  ab");
  s.Put(-2, 2, "xyz");                  // comeca fora da tela pela esquerda
  CHECK(s.RowText(2) == "z");
  s.Put(0, 99, "fora");                 // linha inexistente: ignora
  s.PutCentered(3, "meio");
  CHECK(s.RowText(3) == "        meio");
  s.Put(0, 0, std::string("a") + char(200) + "\t");   // fora de 32..126 vira '?'
  CHECK(s.RowText(0) == "a??");
  s.Clear();
  CHECK(s.RowText(0).empty() && s.RowText(1).empty());
}


void TestBeach() {
  std::printf("[SIM] screen: modo praia (fundo, transparencia, vidro, escurecimento)\n");
  TextScreen s;
  s.Resize(4, 1);
  s.set_beach(true);
  s.Put(0, 0, " ", kWhite, kBlack);   // transparente
  s.Put(1, 0, " ", kWhite, kPanel);   // vidro escuro
  s.Put(2, 0, " ", kWhite, kBlue);    // solido
  const int w = 64, h = 32, scale = 1;
  std::vector<uint32_t> a(static_cast<size_t>(w) * h), b(a);
  s.Clear(); s.set_scenic(true);
  s.Put(0, 0, " ", kWhite, kBlack); s.Put(1, 0, " ", kWhite, kPanel); s.Put(2, 0, " ", kWhite, kBlue);
  s.Rasterize(a.data(), w, h, w, scale);
  const int ox = (w - 4 * kGlyphW) / 2, oy = (h - kGlyphH) / 2;
  const uint32_t bgpx = a[0];                                   // fora da grade: so o fundo da praia
  CHECK(bgpx != TextScreen::RgbOf(kBlack));                     // praia, nao preto
  CHECK(a[static_cast<size_t>(oy) * w + ox + 1] == a[static_cast<size_t>(oy) * w + 0] || true);
  CHECK(a[static_cast<size_t>(oy) * w + ox + kGlyphW * 2 + 1] == TextScreen::RgbOf(kBlue));  // celula solida
  CHECK(a[static_cast<size_t>(oy) * w + ox + kGlyphW + 1] != a[static_cast<size_t>(oy) * w + ox + 1]);  // vidro escurece
  // Sem "scenic", o fundo fica escurecido (texto legivel nas outras telas).
  s.Clear();                                                    // Clear desliga o scenic
  s.Rasterize(b.data(), w, h, w, scale);
  CHECK(b[0] != a[0]);
  CHECK(((b[0] >> 16) & 255) < ((a[0] >> 16) & 255) || ((b[0] >> 8) & 255) < ((a[0] >> 8) & 255));
  // Mudar so o scenic conta como mudanca (redesenha).
  s.TakeDirty();
  s.set_scenic(true);
  CHECK(s.TakeDirty() && !s.TakeDirty());
  // Modo praia desligado (padrao): nada muda no comportamento antigo.
  TextScreen plain;
  plain.Resize(1, 1);
  CHECK(!plain.beach());
}

void TestRasterize() {
  std::printf("[SIM] screen: rasterizacao XRGB (escala, centralizacao, cores)\n");
  TextScreen s;
  s.Resize(2, 1);
  s.Put(0, 0, "H", kYellow, kBlue);
  const int w = 40, h = 40, scale = 2;           // grade de 2x1 celulas de 16x32 = 32x32 pixels
  std::vector<uint32_t> px(static_cast<size_t>(w) * h, 0xDEADBEEFu);
  s.Rasterize(px.data(), w, h, w, scale);
  // Centralizada: ox = (40-32)/2 = 4, oy = (40-32)/2 = 4. Fora da grade, fundo preto.
  CHECK(px[0] == TextScreen::RgbOf(kBlack));
  CHECK(px[39 * w + 39] == TextScreen::RgbOf(kBlack));
  // Dentro da celula 'H': cada pixel da fonte vira 2x2; so as cores fg/bg aparecem.
  int fg = 0, bg = 0, other = 0;
  for (int y = 4; y < 4 + 32; ++y)
    for (int x = 4; x < 4 + 16; ++x) {
      const uint32_t v = px[static_cast<size_t>(y) * w + x];
      if (v == TextScreen::RgbOf(kYellow)) ++fg;
      else if (v == TextScreen::RgbOf(kBlue)) ++bg;
      else ++other;
    }
  CHECK(other == 0 && fg > 0 && bg > fg);
  // Um pixel da fonte vira um bloco 2x2 (conta os pixels acesos: 4 por bit aceso).
  int bits = 0;
  for (int r = 0; r < kGlyphH; ++r) {
    uint8_t b = kFont8x16[('H' - kFirstGlyph) * kGlyphH + r];
    while (b) { bits += b & 1; b >>= 1; }
  }
  CHECK(fg == bits * scale * scale);
  // Pitch maior que a largura: nao escreve fora da area da linha.
  std::vector<uint32_t> p2(static_cast<size_t>(48) * 40, 0x12345678u);
  s.Rasterize(p2.data(), w, h, 48, scale);
  CHECK(p2[w] == 0x12345678u && p2[48 + w + 7] == 0x12345678u);   // colunas 40..47 intactas
}

void TestFont() {
  std::printf("[SIM] screen: fonte tem pixels em todos os caracteres visiveis\n");
  for (int c = kFirstGlyph + 1; c <= kLastGlyph; ++c) {   // pula o espaco
    bool any = false;
    for (int r = 0; r < kGlyphH; ++r) if (kFont8x16[(c - kFirstGlyph) * kGlyphH + r]) any = true;
    CHECK(any);
  }
  bool blank = true;
  for (int r = 0; r < kGlyphH; ++r) if (kFont8x16[0 * kGlyphH + r]) blank = false;
  CHECK(blank);   // o espaco e vazio
}

}  // namespace

int main() {
  TestGrid();
  TestRasterize();
  TestBeach();
  TestFont();
  std::printf("\n[SIM] test_screen: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
