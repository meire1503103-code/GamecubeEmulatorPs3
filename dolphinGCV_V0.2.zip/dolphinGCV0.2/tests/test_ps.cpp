#include "check.h"
#include "cpu.h"
#include "memory.h"

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;

const uint32_t kCode = 0x80003000u;
const uint32_t kData = 0x80001000u;

uint32_t PS(uint32_t fd, uint32_t fa, uint32_t fb, uint32_t fc, uint32_t xo, bool rc = false) {
  return (4u << 26) | (fd << 21) | (fa << 16) | (fb << 11) | (fc << 6) | (xo << 1) | (rc ? 1u : 0u);
}

uint32_t PSX(uint32_t fd, uint32_t fa, uint32_t fb, uint32_t xo, bool rc = false) {
  return (4u << 26) | (fd << 21) | (fa << 16) | (fb << 11) | (xo << 1) | (rc ? 1u : 0u);
}

uint32_t PSQ(uint32_t op, uint32_t frt, uint32_t ra, bool w, uint32_t i, int32_t disp) {
  return (op << 26) | (frt << 21) | (ra << 16) | ((w ? 1u : 0u) << 15) | ((i & 7u) << 12) | (uint32_t(disp) & 0xFFFu);
}

uint32_t MTSPR(uint32_t spr, uint32_t rs) {
  const uint32_t sprf = ((spr & 31u) << 16) | ((spr >> 5) << 11);
  return (31u << 26) | (rs << 21) | sprf | (467u << 1);
}

uint32_t Bits(float f) { uint32_t v; std::memcpy(&v, &f, 4); return v; }
void Put(Memory& m, uint32_t addr, uint32_t inst) { m.Write(addr, 4, inst); }
bool Near(float a, float b, float eps = 1e-4f) { return std::fabs(a - b) <= eps; }

void TestPairedSinglesArith() {
  std::printf("[SIM] Paired Singles aritmetica e merges\n");
  Memory mem; std::string err; CHECK(mem.Init(err));
  Cpu cpu(mem); cpu.Reset(kCode); cpu.msr = 1u << 13;

  cpu.set_ps(1, 2.0f, 3.0f);
  cpu.set_ps(2, 4.0f, 5.0f);
  Put(mem, kCode, PS(3, 1, 2, 0, 21)); // ps_add f3, f1, f2 -> (6.0, 8.0)
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.ps0(3) == 6.0f && cpu.ps1(3) == 8.0f);

  cpu.pc = kCode + 4;
  Put(mem, kCode + 4, PS(4, 1, 0, 2, 25)); // ps_mul f4, f1, f2 -> (8.0, 15.0)
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.ps0(4) == 8.0f && cpu.ps1(4) == 15.0f);

  // ps_madds0: fd = fa * fc.ps0 + fb -> (2*4 + 4, 3*4 + 5) = (12.0, 17.0)
  cpu.pc = kCode + 8;
  Put(mem, kCode + 8, PS(5, 1, 2, 2, 14));
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.ps0(5) == 12.0f && cpu.ps1(5) == 17.0f);

  // ps_merge01: (fa.ps0, fb.ps1) -> (2.0, 5.0)
  cpu.pc = kCode + 12;
  Put(mem, kCode + 12, PSX(6, 1, 2, 560));
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.ps0(6) == 2.0f && cpu.ps1(6) == 5.0f);

  // ps_merge10: (fa.ps1, fb.ps0) -> (3.0, 4.0)
  cpu.pc = kCode + 16;
  Put(mem, kCode + 16, PSX(7, 1, 2, 592));
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.ps0(7) == 3.0f && cpu.ps1(7) == 4.0f);

  // ps_cmpu0 cr3, f1, f2 (2.0 < 4.0 -> LT = 8)
  cpu.pc = kCode + 20;
  Put(mem, kCode + 20, (4u << 26) | (3u << 23) | (1u << 16) | (2u << 11) | (0u << 1));
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(((cpu.cr >> 16) & 0xFu) == 8u);
}

void TestQuantizedLoadStore() {
  std::printf("[SIM] Quantized Loads/Stores (psq_l / psq_st)\n");
  Memory mem; std::string err; CHECK(mem.Init(err));
  Cpu cpu(mem); cpu.Reset(kCode); cpu.msr = 1u << 13;
  cpu.gpr[4] = kData;

  // Caso 1: GQR0 = 0 (float32, scale 0)
  mem.Write(kData, 4, Bits(1.5f));
  mem.Write(kData + 4, 4, Bits(-2.25f));
  Put(mem, kCode, PSQ(56, 1, 4, false, 0, 0)); // psq_l f1, 0(r4), 0, 0
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.ps0(1) == 1.5f && cpu.ps1(1) == -2.25f);

  // W = 1 carrega apenas ps0 e define ps1 = 1.0f
  cpu.pc = kCode + 4;
  Put(mem, kCode + 4, PSQ(56, 2, 4, true, 0, 0)); // psq_l f2, 0(r4), 1, 0
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.ps0(2) == 1.5f && cpu.ps1(2) == 1.0f);

  // Caso 2: GQR1 (SPR 913) com U8 (type=4) e scale=4 (fator 2^-4 = 1/16 = 0.0625)
  // LD_TYPE = 4 (bits 16..18), LD_SCALE = 4 (bits 24..29)
  // ST_TYPE = 4 (bits 0..2),   ST_SCALE = 4 (bits 8..13)
  const uint32_t gqr1 = (4u << 24) | (4u << 16) | (4u << 8) | 4u;
  cpu.gpr[5] = gqr1;
  cpu.pc = kCode + 8;
  Put(mem, kCode + 8, MTSPR(913, 5));
  CHECK(cpu.Step() == StopReason::Running);

  // Escreve bytes 16 (16 * 0.0625 = 1.0f) e 32 (32 * 0.0625 = 2.0f) em kData + 16
  mem.Write(kData + 16, 1, 16u);
  mem.Write(kData + 17, 1, 32u);
  cpu.pc = kCode + 12;
  Put(mem, kCode + 12, PSQ(56, 3, 4, false, 1, 16)); // psq_l f3, 16(r4), 0, 1
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(Near(cpu.ps0(3), 1.0f) && Near(cpu.ps1(3), 2.0f));

  // psq_stu f3, 32(r4), 0, 1 -> quantiza (1.0f, 2.0f) de volta para (16, 32) e atualiza r4
  cpu.pc = kCode + 16;
  Put(mem, kCode + 16, PSQ(61, 3, 4, false, 1, 32));
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.gpr[4] == kData + 32);
  uint32_t b0 = 0, b1 = 0;
  mem.Read(kData + 32, 1, b0);
  mem.Read(kData + 33, 1, b1);
  CHECK(b0 == 16u && b1 == 32u);
}

}  // namespace

int main() {
  TestPairedSinglesArith();
  TestQuantizedLoadStore();
  std::printf("\n[SIM] test_ps: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
