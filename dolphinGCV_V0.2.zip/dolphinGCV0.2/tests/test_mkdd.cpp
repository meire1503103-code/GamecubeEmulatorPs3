#include "check.h"
#include "disc.h"

#include <cstdio>

int g_pass = 0, g_fail = 0;

int main() {
  std::printf("[SIM] Mario Kart Double Dash: deteccao pelo Game ID\n");
  CHECK(dps3::IsMarioKartDoubleDash("GM4E01"));   // EUA
  CHECK(dps3::IsMarioKartDoubleDash("GM4P01"));   // Europa
  CHECK(dps3::IsMarioKartDoubleDash("GM4J01"));   // Japao
  CHECK(!dps3::IsMarioKartDoubleDash("GM4X01"));  // regiao desconhecida
  CHECK(!dps3::IsMarioKartDoubleDash("GALE01"));  // outro jogo
  CHECK(!dps3::IsMarioKartDoubleDash("GM4"));     // curto demais
  CHECK(!dps3::IsMarioKartDoubleDash(""));
  std::printf("\n[SIM] test_mkdd: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
