#include "check.h"
#include "cpu.h"
#include "memory.h"

#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;

const uint32_t kCode = 0x80003000u;

uint32_t FP(uint32_t op, uint32_t fd, uint32_t fa, uint32_t fb, uint32_t fc, uint32_t xo) {
  return (op << 26) | (fd << 21) | (fa << 16) | (fb << 11) | (fc << 6) | (xo << 1);
}

uint32_t MTSPR(uint32_t spr, uint32_t rs) {
  const uint32_t sprf = ((spr & 31u) << 16) | ((spr >> 5) << 11);
  return (31u << 26) | (rs << 21) | sprf | (467u << 1);
}

uint64_t DoubleBits(double d) { uint64_t v; std::memcpy(&v, &d, 8); return v; }
void Put(Memory& m, uint32_t addr, uint32_t inst) { m.Write(addr, 4, inst); }

void TestBatTranslation() {
  std::printf("[SIM] MMU / BAT (DBAT0 mapeando 0x90000000 -> 0x00100000)\n");
  Memory mem; std::string err; CHECK(mem.Init(err));
  Cpu cpu(mem); cpu.Reset(kCode);

  // Grava valor na RAM fisica 0x00100004 (via alias 0x80100004)
  mem.Write(0x80100004u, 4, 0xCAFEBABEu);

  // Configura DBAT0: BEPI = 0x90000000, BL = 0 (128 KiB), Vs=1, Vp=1 -> DBAT0U = 0x90000003
  // BRPN = 0x00100000, WIMG=0, PP=2 (R/W) -> DBAT0L = 0x00100002
  cpu.gpr[3] = 0x90000003u;
  cpu.gpr[4] = 0x00100002u;
  Put(mem, kCode, MTSPR(536, 3));     // mtspr DBAT0U, r3
  Put(mem, kCode + 4, MTSPR(537, 4)); // mtspr DBAT0L, r4
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.Step() == StopReason::Running);

  // Habilita MSR[DR] (bit 4)
  cpu.msr |= (1u << 4);
  cpu.gpr[5] = 0x90000000u;
  // lwz r6, 4(r5)
  Put(mem, kCode + 8, (32u << 26) | (6u << 21) | (5u << 16) | 4u);
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.gpr[6] == 0xCAFEBABEu);
}

void TestFctiwAndRounding() {
  std::printf("[SIM] FPU conversoes inteiras (fctiw/fctiwz) e arredondamento FPSCR\n");
  Memory mem; std::string err; CHECK(mem.Init(err));
  Cpu cpu(mem); cpu.Reset(kCode); cpu.msr = 1u << 13;

  // fctiwz f2, f1 com -3.9 -> -3 (0xFFFFFFFD no low word)
  cpu.fpr[1] = -3.9;
  Put(mem, kCode, FP(63, 2, 0, 1, 0, 15));
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(static_cast<uint32_t>(DoubleBits(cpu.fpr[2]) & 0xFFFFFFFFull) == static_cast<uint32_t>(-3));

  // fctiw f3, f1 com FPSCR[RN] = 3 (toward -Inf) -> -4
  cpu.fpscr = 3u;
  cpu.pc = kCode + 4;
  Put(mem, kCode + 4, FP(63, 3, 0, 1, 0, 14));
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(static_cast<uint32_t>(DoubleBits(cpu.fpr[3]) & 0xFFFFFFFFull) == static_cast<uint32_t>(-4));

  // fres e frsqrte aproximados
  cpu.fpscr = 0u;
  cpu.fpr[4] = 4.0;
  cpu.pc = kCode + 8;
  Put(mem, kCode + 8, FP(59, 5, 0, 4, 0, 24)); // fres f5, f4 (~0.25)
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(std::fabs(cpu.fpr[5] - 0.25) < 1e-3);

  cpu.pc = kCode + 12;
  Put(mem, kCode + 12, FP(63, 6, 0, 4, 0, 26)); // frsqrte f6, f4 (~0.5)
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(std::fabs(cpu.fpr[6] - 0.5) < 1e-3);
}

}  // namespace

int main() {
  TestBatTranslation();
  TestFctiwAndRounding();
  std::printf("\n[SIM] test_mmu_fp_adv: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
