// Testes do parser/carregador de DOL e do boot direto, com imagens SINTETICAS.
// Validam a logica; NAO provam compatibilidade com DOLs/discos reais.
#include "check.h"
#include "boot.h"
#include "cpu.h"
#include "disc.h"
#include "dol.h"
#include "memory.h"

#include <algorithm>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <string>
#include <vector>

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;

void Put32(std::vector<uint8_t>& v, size_t off, uint32_t x) {
  if (off + 4 > v.size()) return;
  v[off] = uint8_t(x >> 24); v[off + 1] = uint8_t(x >> 16);
  v[off + 2] = uint8_t(x >> 8); v[off + 3] = uint8_t(x);
}

struct Sec { uint32_t slot, off, addr, size; };

// DOL: texto em slot 0, dados em slot 7 (primeiro slot de dados).
std::vector<uint8_t> MakeDol(const std::vector<Sec>& secs, uint32_t bss_addr, uint32_t bss_size,
                             uint32_t entry, size_t total) {
  std::vector<uint8_t> d(total, 0);
  for (const Sec& s : secs) {
    Put32(d, 4 * s.slot, s.off);
    Put32(d, 0x48 + 4 * s.slot, s.addr);
    Put32(d, 0x90 + 4 * s.slot, s.size);
  }
  Put32(d, 0xD8, bss_addr); Put32(d, 0xDC, bss_size); Put32(d, 0xE0, entry);
  return d;
}

// Programa: r3 = 7 ; r4 = 6 ; r5 = r3*r4 ; stw r5, 0(bss) ; sc
const uint32_t kProg[] = {
  0x38600007u,  // li r3,7
  0x38800006u,  // li r4,6
  0x7CA321D6u,  // mullw r5,r3,r4
  0x3D408010u,  // lis r10,0x8010
  0x90AA0000u,  // stw r5,0(r10)
  0x44000002u,  // sc
};

void TestParse() {
  std::printf("[SIM] ParseDolHeader\n");
  DolImage img; std::string e;
  auto good = MakeDol({{0, 0x100, 0x80003100u, 24}, {7, 0x118, 0x80100000u, 16}},
                      0x80200000u, 0x1000, 0x80003100u, 0x128);
  CHECK(ParseDolHeader(good.data(), good.size(), img, e));
  CHECK(img.sections.size() == 2 && img.sections[0].is_text && !img.sections[1].is_text);
  CHECK(img.entry == 0x80003100u && img.bss_size == 0x1000 && img.file_size == 0x128);

  auto expect_fail = [&](const char* name, std::vector<uint8_t> d, size_t len) {
    DolImage i; std::string err;
    const bool ok = ParseDolHeader(d.data(), len, i, err);
    std::printf("  [SIM] %-38s -> %s\n", name, ok ? "(ACEITO!)" : err.c_str());
    CHECK(!ok); CHECK(!err.empty());
  };
  expect_fail("header truncado", good, 0x80);
  expect_fail("sem secoes", MakeDol({}, 0, 0, 0x80003100u, 0x100), 0x100);
  expect_fail("secao com offset no header", MakeDol({{0, 0x80, 0x80003100u, 16}}, 0, 0, 0x80003100u, 0x100), 0x100);
  expect_fail("secao nao alinhada", MakeDol({{0, 0x100, 0x80003102u, 16}}, 0, 0, 0x80003100u, 0x110), 0x100);
  expect_fail("secao fora da MEM1", MakeDol({{0, 0x100, 0x81800000u, 16}}, 0, 0, 0x80003100u, 0x110), 0x100);
  expect_fail("secao passa do fim da MEM1", MakeDol({{0, 0x100, 0x817FFFF0u, 32}}, 0, 0, 0x80003100u, 0x120), 0x100);
  expect_fail("endereco fora de qualquer segmento", MakeDol({{0, 0x100, 0x20000000u, 16}}, 0, 0, 0x80003100u, 0x110), 0x100);
  expect_fail("tamanho gigante", MakeDol({{0, 0x100, 0x80003100u, 0xFFFFFFF0u}}, 0, 0, 0x80003100u, 0x110), 0x100);
  expect_fail("bss fora da MEM1", MakeDol({{0, 0x100, 0x80003100u, 16}}, 0x817FFF00u, 0x1000, 0x80003100u, 0x110), 0x100);
  expect_fail("entry nao alinhado", MakeDol({{0, 0x100, 0x80003100u, 16}}, 0, 0, 0x80003102u, 0x110), 0x100);
  expect_fail("entry fora da MEM1", MakeDol({{0, 0x100, 0x80003100u, 16}}, 0, 0, 0x90000000u, 0x110), 0x100);
}

void TestLoad() {
  std::printf("[SIM] LoadDol\n");
  Memory mem; std::string e;
  CHECK(mem.Init(e));
  auto dol = MakeDol({{0, 0x100, 0x80003100u, sizeof kProg}, {7, 0x120, 0x80100000u, 8}},
                     0x80100100u, 0x40, 0x80003100u, 0x128);
  for (unsigned i = 0; i < 6; ++i) Put32(dol, 0x100 + 4 * i, kProg[i]);
  Put32(dol, 0x120, 0xDEADBEEFu); Put32(dol, 0x124, 0x0BADF00Du);

  DolImage img;
  CHECK(ParseDolHeader(dol.data(), dol.size(), img, e));
  mem.Fill(0x80100100u, 0xFF, 0x40);   // sujeira no bss: precisa ser zerada
  CHECK(LoadDol(dol, img, mem, e));
  uint32_t v = 0;
  CHECK(mem.Read(0x80003100u, 4, v) && v == 0x38600007u);
  CHECK(mem.Read(0x80100000u, 4, v) && v == 0xDEADBEEFu);
  CHECK(mem.Read(0x80100004u, 4, v) && v == 0x0BADF00Du);
  CHECK(mem.Read(0x80100100u, 4, v) && v == 0);
  CHECK(mem.Read(0x8010013Cu, 4, v) && v == 0);

  std::vector<uint8_t> shortf(dol.begin(), dol.begin() + 0x110);
  CHECK(!LoadDol(shortf, img, mem, e) && !e.empty());   // arquivo truncado
}

// ISO sintetica GameCube com um DOL em dol_off.
std::vector<uint8_t> MakeIso(const std::vector<uint8_t>& dol, uint32_t dol_off, size_t total) {
  std::vector<uint8_t> v(total, 0);
  std::memcpy(v.data(), "GTEST0", 6);
  Put32(v, 0x1C, 0xC2339F3Du);
  std::memcpy(v.data() + 0x20, "Teste de boot", 13);
  Put32(v, 0x420, dol_off);
  if (dol_off >= 0x440 && dol_off < total)   // nunca sobrescreve o header do disco
    std::memcpy(v.data() + dol_off, dol.data(), std::min<size_t>(dol.size(), total - dol_off));
  return v;
}

bool WriteIso(const std::vector<uint8_t>& v, const char* path) {
  std::FILE* f = std::fopen(path, "wb");
  if (!f) return false;
  const bool ok = std::fwrite(v.data(), 1, v.size(), f) == v.size();
  std::fclose(f);
  return ok;
}

void TestBoot() {
  std::printf("[SIM] boot de DOL a partir de ISO sintetica + execucao\n");
  const char* path = "/tmp/dps3_boot_test.iso";
  auto dol = MakeDol({{0, 0x100, 0x80003100u, sizeof kProg}}, 0, 0, 0x80003100u, 0x100 + sizeof kProg);
  for (unsigned i = 0; i < 6; ++i) Put32(dol, 0x100 + 4 * i, kProg[i]);
  CHECK(WriteIso(MakeIso(dol, 0x2440, 0x4000), path));

  DiscReader disc; std::string e;
  CHECK(disc.Open(path, e));
  Memory mem; Cpu cpu(mem);
  CHECK(mem.Init(e));
  DolImage info;
  CHECK(BootGameCubeDol(disc, mem, cpu, info, e));
  CHECK(cpu.pc == 0x80003100u && cpu.gpr[1] == 0x816FFFF0u);

  uint32_t v = 0;
  CHECK(mem.Read(0x80000000u, 4, v) && v == 0x47544553u);   // "GTES" (game ID copiado)
  CHECK(mem.Read(0x80000028u, 4, v) && v == 0x01800000u);   // 24 MiB
  CHECK(mem.Read(0x800000F8u, 4, v) && v == 162000000u);
  CHECK(mem.Read(0x800000FCu, 4, v) && v == 486000000u);

  CHECK(cpu.Run(1000) == StopReason::Syscall);
  CHECK(cpu.gpr[5] == 42);
  CHECK(mem.Read(0x80100000u, 4, v) && v == 42);             // o programa gravou o resultado
  disc.Close();

  auto bad = [&](const char* name, const std::vector<uint8_t>& iso) {
    CHECK(WriteIso(iso, path));
    DiscReader d; std::string err;
    CHECK(d.Open(path, err));
    Memory m2; Cpu c2(m2); DolImage i2;
    CHECK(m2.Init(err));
    const bool ok = BootGameCubeDol(d, m2, c2, i2, err);
    std::printf("  [SIM] %-38s -> %s\n", name, ok ? "(ACEITO!)" : err.c_str());
    CHECK(!ok); CHECK(!err.empty());
  };
  bad("offset do DOL = 0", MakeIso(dol, 0, 0x4000));
  bad("offset do DOL alem da ISO", MakeIso(dol, 0x10000, 0x4000));
  bad("DOL ultrapassa o fim da ISO", MakeIso(dol, 0x3F00, 0x4000));
  auto garbage = dol; garbage[0xE3] = 0x02;     // entry desalinhado
  bad("DOL com entry invalido", MakeIso(garbage, 0x2440, 0x4000));
}

}  // namespace

int main() {
  TestParse();
  TestLoad();
  TestBoot();
  std::printf("\n[SIM] test_dol: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
