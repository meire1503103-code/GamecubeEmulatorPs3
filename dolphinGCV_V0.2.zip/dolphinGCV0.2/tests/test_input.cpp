#include "check.h"
#include "input.h"

#include <cstdio>

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;

void TestAxis() {
  std::printf("[SIM] ConvertAxis: centro, zona morta, extremos, inversao do Y\n");
  CHECK(ConvertAxis(128, 14, false) == 128);
  CHECK(ConvertAxis(127, 14, false) == 128);   // centro "sujo" do DS3
  CHECK(ConvertAxis(120, 14, false) == 128);   // dentro da zona morta
  CHECK(ConvertAxis(136, 14, false) == 128);
  CHECK(ConvertAxis(255, 14, false) == 255);   // curso completo preservado
  CHECK(ConvertAxis(0, 14, false) == 0);
  CHECK(ConvertAxis(0, 14, true) == 255);      // PS3 cima (0) -> Nintendo cima (255)
  CHECK(ConvertAxis(255, 14, true) <= 1);      // PS3 baixo (255) -> Nintendo baixo (~0)
  CHECK(ConvertAxis(128, 14, true) == 128);
  CHECK(ConvertAxis(200, 14, false) > 128 && ConvertAxis(200, 14, false) < 255);  // monotonico
  CHECK(ConvertAxis(60, 14, false) < 128);
  CHECK(ConvertAxis(255, 0, false) == 255);
  CHECK(ConvertAxis(255, 200, false) == 255);  // deadzone absurda e limitada a 100
}

void TestTrigger() {
  std::printf("[SIM] ConvertTrigger\n");
  CHECK(ConvertTrigger(0, 8) == 0);
  CHECK(ConvertTrigger(8, 8) == 0);
  CHECK(ConvertTrigger(255, 8) == 255);
  CHECK(ConvertTrigger(131, 8) > 100 && ConvertTrigger(131, 8) < 140);
  CHECK(ConvertTrigger(255, 255) == 0);  // sem divisao por zero
}

void TestGameCube() {
  std::printf("[SIM] PS3 -> GameCube\n");
  Ps3PadState neutral;
  GameCubePadState g = MapPs3ToGameCube(neutral);
  CHECK(g.buttons == 0);
  CHECK(g.main_stick_x == 128 && g.main_stick_y == 128 && g.c_stick_x == 128 && g.c_stick_y == 128);
  CHECK(g.trigger_l == 0 && g.trigger_r == 0);

  Ps3PadState s;
  s.square = true; s.circle = true; s.cross = true; s.triangle = true; s.start = true; s.r1 = true;
  g = MapPs3ToGameCube(s);
  CHECK(g.buttons == (GC_BTN_A | GC_BTN_B | GC_BTN_X | GC_BTN_Y | GC_BTN_START | GC_BTN_Z));

  s = Ps3PadState(); s.square = true;
  CHECK(MapPs3ToGameCube(s).buttons == GC_BTN_A);
  s = Ps3PadState(); s.cross = true;
  CHECK(MapPs3ToGameCube(s).buttons == GC_BTN_X);

  // Y: analogico PARA CIMA (0) tem que virar 255 no GameCube.
  s = Ps3PadState(); s.left_stick_y = 0; s.right_stick_y = 0;
  g = MapPs3ToGameCube(s);
  CHECK(g.main_stick_y == 255 && g.c_stick_y == 255);
  s = Ps3PadState(); s.left_stick_x = 255;
  CHECK(MapPs3ToGameCube(s).main_stick_x == 255);  // X nao inverte

  // L1 = clique completo.
  s = Ps3PadState(); s.l1 = true;
  g = MapPs3ToGameCube(s);
  CHECK((g.buttons & GC_BTN_L) && g.trigger_l == 255 && g.trigger_r == 0);

  // L2/R2 analogicos: meio curso = analogico sem clique; fim de curso = clique digital (L e R).
  s = Ps3PadState(); s.l2_analog = 128; s.r2_analog = 128;
  g = MapPs3ToGameCube(s);
  CHECK(g.trigger_l > 100 && g.trigger_r > 100);
  CHECK((g.buttons & (GC_BTN_L | GC_BTN_R)) == 0);
  s.l2_analog = 255; s.r2_analog = 255;
  g = MapPs3ToGameCube(s);
  CHECK((g.buttons & GC_BTN_L) && (g.buttons & GC_BTN_R));
  CHECK(g.trigger_l == 255 && g.trigger_r == 255);

  // D-Pad e oposicoes se anulam.
  s = Ps3PadState(); s.dpad_up = true; s.dpad_left = true;
  CHECK(MapPs3ToGameCube(s).buttons == (GC_BTN_UP | GC_BTN_LEFT));
  s = Ps3PadState(); s.dpad_up = true; s.dpad_down = true;
  CHECK(MapPs3ToGameCube(s).buttons == 0);

  // Bits do hardware (conferidos contra o protocolo SI do GameCube).
  CHECK(GC_BTN_A == 0x0100 && GC_BTN_START == 0x1000 && GC_BTN_Z == 0x0010 && GC_BTN_L == 0x0040);
}

void TestDescriptions() {
  std::printf("[SIM] nomes e descricoes dos perfis\n");
  CHECK(!DescribeMapping(ControllerProfile::GameCube).empty());
  CHECK(std::string(ProfileName(ControllerProfile::GameCube)) == "GameCube");
  CHECK(!PadInit());  // host: sem pad
  Ps3PadState x;
  CHECK(!PadPoll(x));
}

}  // namespace

int main() {
  TestAxis();
  TestTrigger();
  TestGameCube();
  TestDescriptions();
  std::printf("\n[SIM] test_input: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
