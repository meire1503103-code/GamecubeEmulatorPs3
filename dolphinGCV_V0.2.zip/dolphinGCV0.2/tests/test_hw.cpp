// Testes do hardware simplificado (PI/DI/SI/VI) ligado a memoria do guest.
#include "check.h"
#include "disc.h"
#include "memory.h"
#include "mmio.h"

#include <cstdio>
#include <string>
#include <vector>

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;

const char* kIso = "/tmp/dolphingc_test_hw.iso";

// Disco GC minimo (header valido) com um padrao conhecido em 0x1000.
bool MakeIso(size_t total) {
  std::vector<uint8_t> v(total, 0);
  const char id[] = "GM4E01";
  for (int i = 0; i < 6; ++i) v[i] = id[i];
  v[0x1C] = 0xC2; v[0x1D] = 0x33; v[0x1E] = 0x9F; v[0x1F] = 0x3D;
  for (int i = 0; i < 0x40; ++i) v[0x1000 + i] = static_cast<uint8_t>(0xA0 + i);
  FILE* f = std::fopen(kIso, "wb");
  if (!f) return false;
  const bool ok = std::fwrite(v.data(), 1, v.size(), f) == v.size();
  std::fclose(f);
  return ok;
}

struct Rig {
  Memory mem; MmioHandler hw; DiscReader disc;
  bool Init(size_t iso_size = 0x4000) {
    std::string e;
    if (!mem.Init(e) || !MakeIso(iso_size) || !disc.Open(kIso, e)) return false;
    mem.SetMmio(&hw);
    hw.Attach(&mem, &disc);
    return true;
  }
  uint32_t R(uint32_t off) { uint32_t v = 0xDEADBEEF; mem.Read(0xCC000000u + off, 4, v); return v; }
  bool W(uint32_t off, uint32_t v) { return mem.Write(0xCC000000u + off, 4, v); }
};

void TestRouting() {
  std::printf("[SIM] MMIO: roteamento pela memoria (0xCC00xxxx), PI e limites\n");
  Rig r; CHECK(r.Init());
  CHECK(r.R(0x302C) == 0x246500B1u);                    // revisao do chip
  CHECK(r.W(0x3004, 0x104)); CHECK(r.R(0x3004) == 0x104u);
  CHECK(r.R(0x5004) == 0x8071FEEDu);                   // mailbox DSP->CPU inicial
  CHECK(r.W(0x1234, 0xCAFEBABEu)); CHECK(r.R(0x1234) == 0xCAFEBABEu);  // area generica guarda o valor
  uint32_t v;
  CHECK(!r.mem.Read(0xCC010000u, 4, v));               // fora da janela
  CHECK(!r.mem.Read(0xCC000000u, 4, v, true));         // busca de instrucao em MMIO e proibida
  CHECK(r.mem.Read(0x0C00302Cu, 4, v) && v == 0x246500B1u);   // mesmo registrador pelo endereco fisico
  Memory solo; std::string e; solo.Init(e);
  CHECK(!solo.Read(0xCC00302Cu, 4, v));                // sem barramento ligado continua falhando
  CHECK(r.mem.Write(0x80000100u, 4, 0x11223344u) && r.mem.Read(0x80000100u, 4, v) && v == 0x11223344u);
  CHECK(r.mem.Read(0x80000100u, 2, v) && v == 0x1122u && r.mem.Read(0x80000103u, 1, v) && v == 0x44u);
}

void TestDvdDma() {
  std::printf("[SIM] DI: leitura de disco por DMA + interrupcao\n");
  Rig r; CHECK(r.Init());
  CHECK(r.W(0x6008, 0xA8000000u));      // DICMDBUF0: ler
  CHECK(r.W(0x600C, 0x1000u >> 2));     // DICMDBUF1: offset em palavras
  CHECK(r.W(0x6010, 0x20));             // DICMDBUF2: tamanho
  CHECK(r.W(0x6014, 0x00100000u));      // DIMAR: destino fisico
  CHECK(r.W(0x6018, 0x20));             // DILENGTH
  CHECK(r.W(0x6000, 0x8));              // habilita a interrupcao de fim de transferencia
  CHECK(r.W(0x3004, PI_INT_DI));        // mascara do PI
  CHECK(!r.hw.InterruptPending());
  CHECK(r.W(0x601C, 3));                // TSTART | DMA
  uint8_t b[0x20] = {0};
  CHECK(r.mem.ReadBlock(0x80100000u, b, sizeof b));
  bool same = true;
  for (int i = 0; i < 0x20; ++i) same = same && b[i] == (0xA0 + i);
  CHECK(same);
  CHECK((r.R(0x601C) & 1) == 0);        // TSTART voltou a 0
  CHECK(r.R(0x6000) & 0x10);            // TCINT
  CHECK(r.hw.InterruptPending() && (r.hw.pi_cause() & PI_INT_DI));
  CHECK(r.hw.dvd_reads() == 1 && r.hw.dvd_bytes() == 0x20 && r.hw.dvd_errors() == 0);
  CHECK(r.W(0x6000, 0x10 | 0x8));       // escrever 1 em TCINT limpa
  CHECK(!r.hw.InterruptPending());

  // leitura alem do fim da imagem: preenche com zeros em vez de falhar
  r.mem.Fill(0x80100000u, 0xFF, 0x20);
  CHECK(r.W(0x600C, 0x10000u >> 2)); CHECK(r.W(0x6018, 0x20)); CHECK(r.W(0x601C, 3));
  CHECK(r.mem.ReadBlock(0x80100000u, b, sizeof b) && b[0] == 0 && b[0x1F] == 0);
  // destino invalido conta erro
  CHECK(r.W(0x6014, 0x01FFFFF0u)); CHECK(r.W(0x6018, 0x40)); CHECK(r.W(0x601C, 3));
  CHECK(r.hw.dvd_errors() == 1);
}

void TestPad() {
  std::printf("[SIM] SI: dados do controle (poll e transferencia)\n");
  Rig r; CHECK(r.Init());
  GameCubePadState p;
  p.buttons = GC_BTN_A | GC_BTN_START | GC_BTN_L;
  p.main_stick_x = 200; p.main_stick_y = 60; p.c_stick_x = 10; p.c_stick_y = 20;
  p.trigger_l = 255; p.trigger_r = 7;
  r.hw.SetPad(p);
  const uint32_t h = r.R(0x6404), l = r.R(0x6408);
  CHECK(h == ((uint32_t(GC_BTN_A | GC_BTN_START | GC_BTN_L | 0x80) << 16) | (200u << 8) | 60u));
  CHECK(l == ((10u << 24) | (20u << 16) | (255u << 8) | 7u));
  CHECK((h & 0xC0000000u) == 0);        // sem flags de erro

  CHECK(r.W(0x6400, 0x00000000u));      // comando 0x00: ID
  CHECK(r.W(0x6434, 0x40000000u | 1));  // TCINTMSK | TSTART
  CHECK(r.R(0x6480) == 0x09000000u);
  CHECK(r.R(0x6434) & 0x80000000u);     // TCINT
  CHECK(r.hw.pi_cause() & PI_INT_SI);
  CHECK(r.W(0x6434, 0x80000000u | 0x40000000u));
  CHECK(!(r.hw.pi_cause() & PI_INT_SI));
  CHECK(r.W(0x6400, 0x40000000u));      // comando 0x40: ler controle
  CHECK(r.W(0x6434, 1));
  CHECK(r.R(0x6480) == (h & 0x3FFFFFFFu) && r.R(0x6484) == l);
}

void TestRetrace() {
  std::printf("[SIM] VI: retrace por Tick() + interrupcao e mascara\n");
  Rig r; CHECK(r.Init());
  r.hw.Tick(kStepsPerFrame - 1);
  CHECK(r.hw.frames() == 0);
  r.hw.Tick(1);
  CHECK(r.hw.frames() == 1);
  CHECK(!(r.hw.pi_cause() & PI_INT_VI));          // display interrupt ainda desabilitada
  CHECK(r.W(0x2030, 0x10000000u));                // habilita DI0
  CHECK(r.W(0x3004, PI_INT_VI));
  r.hw.Tick(kStepsPerFrame);
  CHECK(r.hw.frames() == 2 && r.hw.InterruptPending());
  CHECK(r.R(0x2030) & 0x80000000u);
  CHECK(r.W(0x2030, 0x10000000u));                // escrever 0 no bit 31 limpa
  CHECK(!r.hw.InterruptPending());
  r.hw.Tick(kStepsPerFrame * 3);
  CHECK(r.hw.frames() == 5);                      // varios quadros de uma vez
  CHECK(r.W(0x3000, PI_INT_VI));                  // limpar pela causa do PI
  CHECK(!(r.hw.pi_cause() & PI_INT_VI));
}

}  // namespace

int main() {
  TestRouting();
  TestDvdDma();
  TestPad();
  TestRetrace();
  std::remove(kIso);
  std::printf("\n[SIM] test_hw: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
