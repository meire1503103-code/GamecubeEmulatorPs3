// Executa um apploader SINTETICO (montado a mao em PowerPC) na CPU emulada: nao e um apploader
// comercial, mas exercita o fluxo real entry -> init -> main (laco) -> close.
#include "check.h"
#include "apploader.h"
#include "boot.h"
#include "cpu.h"
#include "disc.h"
#include "memory.h"

#include <cstdio>
#include <string>
#include <vector>

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;

uint32_t D(uint32_t op, uint32_t rt, uint32_t ra, int32_t imm) { return (op << 26) | (rt << 21) | (ra << 16) | (uint32_t(imm) & 0xFFFF); }
uint32_t LI(uint32_t r, int32_t v) { return D(14, r, 0, v); }
uint32_t LIS(uint32_t r, int32_t v) { return D(15, r, 0, v); }
uint32_t ORI(uint32_t ra, uint32_t rs, uint32_t v) { return D(24, rs, ra, int32_t(v)); }
uint32_t STW(uint32_t rs, int32_t off, uint32_t ra) { return D(36, rs, ra, off); }
uint32_t LWZ(uint32_t rt, int32_t off, uint32_t ra) { return D(32, rt, ra, off); }
uint32_t CMPWI(uint32_t ra, int32_t v) { return D(11, 0, ra, v); }
uint32_t BNE(int32_t off) { return (16u << 26) | (4u << 21) | (2u << 16) | (uint32_t(off) & 0xFFFC); }  // bne cr0
const uint32_t BLR = 0x4E800020u;

const char* kIso = "/tmp/dolphingc_test_app.iso";
const uint32_t kBase = 0x81200000u;
const uint32_t kState = 0x400;  // palavra de estado do 'main' (offset dentro da imagem)

void Put32(std::vector<uint8_t>& v, size_t at, uint32_t x) {
  v[at] = x >> 24; v[at + 1] = x >> 16; v[at + 2] = x >> 8; v[at + 3] = x;
}

// Monta o disco: header GC, apploader sintetico em 0x2440 e dados em 0x3000.
// mode: 0 = normal, 1 = apploader com size 0, 2 = instrucao invalida no entry.
bool MakeDisc(int mode) {
  std::vector<uint8_t> v(0x8000, 0);
  const char id[] = "GM4E01";
  for (int i = 0; i < 6; ++i) v[i] = id[i];
  Put32(v, 0x1C, 0xC2339F3Du);
  for (int i = 0; i < 0x20; ++i) v[0x3000 + i] = static_cast<uint8_t>(0x40 + i);

  // ---- imagem do apploader (instrucoes) ----
  std::vector<uint32_t> entry = {
    LIS(6, 0x8120), ORI(6, 6, 0x0100), STW(6, 0, 3),   // *init  = 0x81200100
    LIS(7, 0x8120), ORI(7, 7, 0x0200), STW(7, 0, 4),   // *main  = 0x81200200
    LIS(8, 0x8120), ORI(8, 8, 0x0300), STW(8, 0, 5),   // *close = 0x81200300
    BLR };
  std::vector<uint32_t> init = { BLR };
  std::vector<uint32_t> mainf = {
    LIS(9, 0x8120), LWZ(10, kState, 9), CMPWI(10, 0), BNE(0),  // BNE patch abaixo
    LI(10, 1), STW(10, kState, 9),
    LIS(11, 0x8030), STW(11, 0, 3),     // dest = 0x80300000
    LI(11, 0x20), STW(11, 0, 4),        // tamanho
    LI(11, 0x3000), STW(11, 0, 5),      // offset no disco
    LI(3, 1), BLR,
    LI(3, 0), BLR };                    // "done"
  mainf[3] = BNE(int32_t(4 * (14 - 3)));  // pula ate o LI(3,0) (indice 14)
  std::vector<uint32_t> close = { LIS(3, 0x8030), BLR };  // entry do jogo = 0x80300000

  const size_t body_at = 0x2460;
  auto emit = [&](const std::vector<uint32_t>& code, size_t off) {
    for (size_t i = 0; i < code.size(); ++i) Put32(v, body_at + off + 4 * i, code[i]);
  };
  if (mode == 2) entry[0] = 0x00000000u;  // opcode 0: instrucao invalida
  emit(entry, 0); emit(init, 0x100); emit(mainf, 0x200); emit(close, 0x300);
  Put32(v, 0x2440 + 0x10, kBase);                       // entry do apploader
  Put32(v, 0x2440 + 0x14, mode == 1 ? 0 : 0x500);       // tamanho
  Put32(v, 0x2440 + 0x18, 0);

  FILE* f = std::fopen(kIso, "wb");
  if (!f) return false;
  const bool ok = std::fwrite(v.data(), 1, v.size(), f) == v.size();
  std::fclose(f);
  return ok;
}

void TestRun() {
  std::printf("[SIM] apploader sintetico: entry -> init -> main (laco) -> close\n");
  CHECK(MakeDisc(0));
  DiscReader disc; std::string e;
  CHECK(disc.Open(kIso, e));
  Memory mem; CHECK(mem.Init(e));
  Cpu cpu(mem);
  Apploader app;
  uint32_t entry = 0;
  const bool ok = app.LoadAndRun(disc, mem, cpu, entry, e);
  if (!ok) std::printf("    erro: %s\n", e.c_str());
  CHECK(ok);
  CHECK(entry == 0x80300000u);
  CHECK(app.chunks() == 1 && app.bytes() == 0x20);
  uint8_t b[0x20] = {0};
  CHECK(mem.ReadBlock(0x80300000u, b, sizeof b));
  bool same = true;
  for (int i = 0; i < 0x20; ++i) same = same && b[i] == 0x40 + i;
  CHECK(same);
}

void TestBootFull() {
  std::printf("[SIM] BootGameCubeApploader: memoria baixa, MSR[FP], pilha e entry\n");
  CHECK(MakeDisc(0));
  DiscReader disc; std::string e;
  CHECK(disc.Open(kIso, e));
  Memory mem; CHECK(mem.Init(e));
  Cpu cpu(mem);
  uint32_t entry = 0;
  CHECK(BootGameCubeApploader(disc, mem, cpu, entry, e));
  CHECK(cpu.pc == 0x80300000u && entry == cpu.pc);
  CHECK((cpu.msr & 0x2000) != 0);
  CHECK(cpu.gpr[1] == 0x816FFFF0u);
  uint32_t v = 0;
  CHECK(mem.Read(0x80000000u, 4, v) && v == 0x474D3445u);   // "GM4E" copiado do header do disco
  CHECK(mem.Read(0x80000020u, 4, v) && v == 0x0D15EA5Eu);
  CHECK(mem.Read(0x800000ECu, 4, v) && v == 0x81800000u);
}

void TestErrors() {
  std::printf("[SIM] apploader: erros claros (size 0, instrucao invalida)\n");
  for (int mode = 1; mode <= 2; ++mode) {
    CHECK(MakeDisc(mode));
    DiscReader disc; std::string e;
    CHECK(disc.Open(kIso, e));
    Memory mem; CHECK(mem.Init(e));
    Cpu cpu(mem);
    Apploader app; uint32_t entry = 0;
    CHECK(!app.LoadAndRun(disc, mem, cpu, entry, e));
    std::printf("  [SIM] modo %d -> %s\n", mode, e.c_str());
    CHECK(!e.empty());
    if (mode == 2) CHECK(e.find("entry") != std::string::npos && e.find("nao implementada") != std::string::npos);
  }
}

}  // namespace

int main() {
  TestRun();
  TestBootFull();
  TestErrors();
  std::remove(kIso);
  std::printf("\n[SIM] test_apploader: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
