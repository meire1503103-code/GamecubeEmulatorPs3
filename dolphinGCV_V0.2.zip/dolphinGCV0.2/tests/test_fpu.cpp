#include "check.h"
#include "cpu.h"
#include "memory.h"

#include <cmath>
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <string>

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;
const uint32_t kCode = 0x80003000u;
const uint32_t kData = 0x80001000u;
uint32_t FP(uint32_t op, uint32_t fd, uint32_t fa, uint32_t fb,
             uint32_t fc, uint32_t xo, bool rc = false) {
  return (op << 26) | (fd << 21) | (fa << 16) | (fb << 11) |
         (fc << 6) | (xo << 1) | (rc ? 1u : 0u);
}
uint32_t D(uint32_t op, uint32_t frt, uint32_t ra, int32_t disp) {
  return (op << 26) | (frt << 21) | (ra << 16) | (uint32_t(disp) & 0xFFFFu);
}
uint32_t Bits(float f) { uint32_t v; std::memcpy(&v, &f, 4); return v; }
uint64_t Bits(double f) { uint64_t v; std::memcpy(&v, &f, 8); return v; }
void Put(Memory& m, uint32_t address, uint32_t instruction) { m.Write(address, 4, instruction); }

void TestScalarArithmetic() {
  std::printf("[SIM] FPU escalar single/double\n");
  Memory mem; std::string err; CHECK(mem.Init(err));
  Cpu cpu(mem); cpu.Reset(kCode); cpu.msr = 1u << 13;
  cpu.fpr[1] = 1.5; cpu.fpr[2] = 2.25;
  Put(mem, kCode, FP(59, 3, 1, 2, 0, 21)); // fadds f3,f1,f2
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.pc == kCode + 4);
  CHECK(cpu.fpr[3] == 3.75);

  cpu.pc = kCode + 4; cpu.fpr[1] = 5.0; cpu.fpr[2] = 2.0;
  Put(mem, kCode + 4, FP(63, 4, 1, 2, 0, 20)); // fsub f4,f1,f2
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.fpr[4] == 3.0);

  cpu.pc = kCode + 8; cpu.fpr[1] = 3.0; cpu.fpr[2] = 4.0;
  Put(mem, kCode + 8, FP(63, 5, 1, 2, 0, 21)); // fadd f5,f1,f2
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.fpr[5] == 7.0);

  cpu.pc = kCode + 12; cpu.fpr[1] = 2.0; cpu.fpr[2] = 3.0; cpu.fpr[6] = 4.0;
  Put(mem, kCode + 12, FP(63, 7, 1, 2, 6, 29)); // fmadd f7,f1,f6,f2
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.fpr[7] == 11.0);

  // fsqrt f8,f2 usa FRB como operando (nao FRA).
  cpu.pc = kCode + 16; cpu.fpr[1] = 999.0; cpu.fpr[2] = 81.0;
  Put(mem, kCode + 16, FP(63, 8, 1, 2, 0, 22));
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.fpr[8] == 9.0);

  // FADD single arredonda para binary32 antes de armazenar no FPR.
  cpu.pc = kCode + 20; cpu.fpr[1] = 1.0; cpu.fpr[2] = std::ldexp(1.0, -24);
  Put(mem, kCode + 20, FP(59, 9, 1, 2, 0, 21));
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.fpr[9] == 1.0);
}

void TestCompareAndMoves() {
  std::printf("[SIM] FPU comparacao e moves\n");
  Memory mem; std::string err; CHECK(mem.Init(err));
  Cpu cpu(mem); cpu.Reset(kCode); cpu.msr = 1u << 13;
  cpu.fpr[1] = 1.0; cpu.fpr[2] = 2.0;
  // fcmpu cr2,f1,f2; BF occupies bits 23..25.
  Put(mem, kCode, (63u << 26) | (2u << 23) | (1u << 16) | (2u << 11));
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(((cpu.cr >> 20) & 0xFu) == 8u); // LT

  cpu.pc = kCode + 4;
  Put(mem, kCode + 4, FP(63, 3, 0, 1, 0, 72)); // fmr f3,f1
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.fpr[3] == 1.0);
  cpu.pc = kCode + 8;
  Put(mem, kCode + 8, FP(63, 4, 0, 1, 0, 264)); // fabs f4,f1
  cpu.fpr[1] = -9.0;
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.fpr[4] == 9.0);
}

void TestFloatingLoadsStores() {
  std::printf("[SIM] FPU loads/stores single/double\n");
  Memory mem; std::string err; CHECK(mem.Init(err));
  Cpu cpu(mem); cpu.Reset(kCode); cpu.msr = 1u << 13; cpu.gpr[4] = kData;
  CHECK(mem.Write(kData, 4, Bits(1.25f)));
  Put(mem, kCode, D(48, 2, 4, 0)); // lfs f2,0(r4)
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.fpr[2] == 1.25);

  cpu.pc = kCode + 4; cpu.fpr[3] = -2.5;
  Put(mem, kCode + 4, D(52, 3, 4, 4)); // stfs f3,4(r4)
  CHECK(cpu.Step() == StopReason::Running);
  uint32_t single = 0; CHECK(mem.Read(kData + 4, 4, single));
  CHECK(single == Bits(-2.5f));

  cpu.pc = kCode + 8; cpu.fpr[5] = 123.125;
  Put(mem, kCode + 8, D(54, 5, 4, 8)); // stfd f5,8(r4)
  CHECK(cpu.Step() == StopReason::Running);
  uint8_t bytes[8]; CHECK(mem.ReadBlock(kData + 8, bytes, 8));
  uint64_t raw = 0; for (unsigned i = 0; i < 8; ++i) raw = (raw << 8) | bytes[i];
  CHECK(raw == Bits(123.125));

  cpu.pc = kCode + 12;
  Put(mem, kCode + 12, D(50, 6, 4, 8)); // lfd f6,8(r4)
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.fpr[6] == 123.125);
}

void TestUnavailableException() {
  std::printf("[SIM] excecao FPU indisponivel\n");
  Memory mem; std::string err; CHECK(mem.Init(err));
  Cpu cpu(mem); cpu.Reset(kCode); cpu.fpr[1] = 1.0;
  Put(mem, kCode, FP(63, 2, 1, 1, 0, 21));
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.pc == 0x800);
  CHECK(cpu.last_exception == Exception::FloatingPointUnavailable);
  CHECK(cpu.srr0 == kCode);
}
}

int main() {
  TestScalarArithmetic();
  TestCompareAndMoves();
  TestFloatingLoadsStores();
  TestUnavailableException();
  std::printf("\n[SIM] test_fpu: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
