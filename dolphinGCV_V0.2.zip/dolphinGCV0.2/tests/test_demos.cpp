#include "check.h"
#include "demos.h"
#include "system.h"

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;

std::string Calc(Calculator& c, const char* keys) {
  c.Press('C');
  for (const char* p = keys; *p; ++p) c.Press(*p);
  return c.Display();
}

void TestHello() {
  std::printf("[SIM] demos: Hello World executado pela CPU emulada\n");
  std::string out, err;
  uint64_t steps = 0;
  CHECK(RunHelloWorld(out, &steps, err));
  CHECK(out.find("Hello, World!\n") == 0);
  CHECK(out.find("PowerPC emulado") != std::string::npos);
  CHECK(steps > 100 && steps < 2000);   // ~8 instrucoes por letra
  // Duas execucoes seguidas dao o mesmo resultado (VM nova a cada vez).
  std::string out2;
  CHECK(RunHelloWorld(out2, nullptr, err) && out2 == out);
}

void TestCalc() {
  std::printf("[SIM] demos: calculadora (contas feitas na CPU emulada)\n");
  Calculator c;
  CHECK(c.ok());
  CHECK(Calc(c, "12+30=") == "42");
  CHECK(Calc(c, "100-58=") == "42");
  CHECK(Calc(c, "6*7=") == "42");
  CHECK(Calc(c, "84/2=") == "42");
  CHECK(Calc(c, "7-9=") == "-2");
  CHECK(Calc(c, "-7/2=") == "-3");           // divisao inteira, trunca para zero
  CHECK(Calc(c, "2+3*4=") == "20");          // esquerda para direita, como calculadora de bolso
  CHECK(Calc(c, "5+") == "5");
  c.Press('3');
  CHECK(c.Display() == "3" && c.Expression() == "5 +");
  c.Press('=');
  CHECK(c.Display() == "8");
  c.Press('*'); c.Press('2'); c.Press('=');  // continua do resultado anterior
  CHECK(c.Display() == "16");
  CHECK(Calc(c, "9=") == "9");               // '=' sem operacao so mostra o numero
  CHECK(Calc(c, "5*=") == "25");             // "5 * =" usa o proprio numero (como calculadoras reais)
  CHECK(Calc(c, "123B=") == "12");           // backspace
  CHECK(Calc(c, "1234567890") == "123456789");  // limite de 9 digitos
  CHECK(c.guest_ops() > 0 && c.guest_steps() >= c.guest_ops() * 4);   // a CPU emulada fez as contas
}

void TestCalcErrors() {
  std::printf("[SIM] demos: calculadora - erros\n");
  Calculator c;
  CHECK(Calc(c, "5/0=") == "ERRO" && c.error() == "DIVISAO POR ZERO");
  c.Press('7');                               // digitar depois do erro recomeca
  CHECK(c.error().empty() && c.Display() == "7");
  CHECK(Calc(c, "999999999*9=") == "ERRO" && c.error().find("ESTOURO") != std::string::npos);
  c.Press('+');                               // operador apos erro e ignorado
  CHECK(c.Display() == "ERRO");
  CHECK(Calc(c, "999999999+999999999+999999999=") == "ERRO");   // 3 x 999999999 passa de 2^31
  CHECK(Calc(c, "0-999999999-999999999-999999999=") == "ERRO");
  CHECK(Calc(c, "C3+4=") == "7");             // 'C' limpa o erro
}

void TestGuestVm() {
  std::printf("[SIM] demos: GuestVm - RAM vazia nao termina em 'sc'\n");
  GuestVm vm;
  std::string err;
  CHECK(vm.Init(err));
  CHECK(vm.RunFrom(0x80003100u, 10) != StopReason::Syscall);
  CHECK(vm.hw().console().empty());
}

int g_pad_calls = 0, g_progress_calls = 0, g_cancel_after = 0;
bool CountPad(GameCubePadState&) { ++g_pad_calls; return false; }
bool CountProgress(uint64_t, void*) { return ++g_progress_calls < g_cancel_after || g_cancel_after == 0; }

void TestRunSystemPolling() {
  std::printf("[SIM] system: pad/progresso consultados raramente e cancelamento\n");
  GuestVm vm;
  std::string err;
  CHECK(vm.Init(err));
  CHECK(vm.LoadWords(0x80003100u, {0x48000000u}));       // b .  (laco infinito)
  vm.cpu().Reset(0x80003100u);
  g_pad_calls = g_progress_calls = 0; g_cancel_after = 0;
  const uint64_t steps = 1000000;
  CHECK(RunSystem(vm.cpu(), vm.hw(), steps, CountPad, CountProgress, nullptr) == StopReason::StepLimit);
  // 1 milhao de passos = ~244 blocos de 4096; consulta a cada 16 blocos => ~16 vezes (antes: ~244).
  CHECK(g_pad_calls >= 10 && g_pad_calls <= 20);
  CHECK(g_progress_calls == g_pad_calls);
  g_progress_calls = 0; g_cancel_after = 3;               // cancela na 3a chamada
  vm.cpu().Reset(0x80003100u);
  CHECK(RunSystem(vm.cpu(), vm.hw(), steps, nullptr, CountProgress, nullptr) == StopReason::Cancelled);
  CHECK(g_progress_calls == 3 && vm.cpu().steps() < steps / 4);
}

}  // namespace

int main() {
  TestHello();
  TestCalc();
  TestCalcErrors();
  TestGuestVm();
  TestRunSystemPolling();
  std::printf("\n[SIM] test_demos: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
