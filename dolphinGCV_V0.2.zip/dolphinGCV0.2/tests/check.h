// Mini-framework de testes compartilhado pelos testes novos.
#pragma once
#include <cstdio>

extern int g_pass, g_fail;

#define CHECK(c)                                                                  \
  do {                                                                            \
    if (c) { ++g_pass; }                                                          \
    else { ++g_fail; std::printf("    FAIL %s:%d: %s\n", __FILE__, __LINE__, #c); } \
  } while (0)
