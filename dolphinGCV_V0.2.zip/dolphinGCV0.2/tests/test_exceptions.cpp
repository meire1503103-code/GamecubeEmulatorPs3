#include "cpu.h"
#include "check.h"
#include <string>
using namespace dps3;
int g_pass = 0, g_fail = 0;
static bool Put(Memory& m, uint32_t a, uint32_t v) { return m.Write(a, 4, v); }
int main() {
  Memory mem; std::string err; CHECK(mem.Init(err));
  // twi TO=4, RA=3, SI=7: igualdade dispara Program Exception.
  CHECK(Put(mem, 0x1000, (3u<<26)|(4u<<21)|(3u<<16)|7u));
  Cpu cpu(mem); cpu.Reset(0x1000); cpu.gpr[3]=7;
  cpu.msr=(1u<<15)|(1u<<14)|(1u<<13);
  CHECK(cpu.Step()==StopReason::Running); CHECK(cpu.pc==0x700);
  CHECK(cpu.srr0==0x1000); CHECK(cpu.srr1==((1u<<15)|(1u<<14)|(1u<<13)));
  CHECK((cpu.msr&((1u<<15)|(1u<<14)|(1u<<13)))==0);
  CHECK(cpu.last_exception==Exception::Program);
  // RFI retorna para SRR0 e restaura MSR.
  CHECK(Put(mem,0x700,(19u<<26)|(50u<<1)));
  CHECK(cpu.Step()==StopReason::Running); CHECK(cpu.pc==0x1000);
  CHECK(cpu.msr==((1u<<15)|(1u<<14)|(1u<<13)));
  CHECK(cpu.last_exception==Exception::None);
  // Interrupcao externa fica pendente com EE=0 e e aceita com EE=1.
  cpu.Reset(0x1000); CHECK(Put(mem,0x1000,0x38600063u));
  cpu.RequestExternalInterrupt(); CHECK(cpu.Step()==StopReason::Running);
  CHECK(cpu.pc==0x1004);
  cpu.Reset(0x1000); cpu.msr=1u<<15; cpu.RequestExternalInterrupt();
  CHECK(cpu.Step()==StopReason::Running); CHECK(cpu.pc==0x500);
  CHECK(cpu.srr0==0x1000); CHECK(cpu.last_exception==Exception::ExternalInterrupt);
  CHECK(!cpu.external_interrupt_pending());
  // Load de palavra desalinhado gera Alignment Exception e atualiza DAR.
  cpu.Reset(0x2000); CHECK(Put(mem,0x2000,(32u<<26)|(4u<<21)|(3u<<16)));
  cpu.gpr[3]=0x1001; CHECK(cpu.Step()==StopReason::Running);
  CHECK(cpu.pc==0x600); CHECK(cpu.dar==0x1001);
  CHECK(cpu.last_exception==Exception::Alignment);
  std::printf("\n[SIM] test_exceptions: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
