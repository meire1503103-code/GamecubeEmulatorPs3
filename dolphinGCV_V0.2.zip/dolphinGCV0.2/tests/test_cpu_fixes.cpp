// Regressao dos bugs corrigidos na CPU (MSR[EE], MSR nas excecoes, lwarx/stwcx., mffs, arredondamento).
#include "check.h"
#include "cpu.h"
#include "memory.h"

#include <cfenv>
#include <cstdio>
#include <cstring>
#include <string>

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;
const uint32_t kCode = 0x80003000u, kData = 0x80001000u;

uint32_t X31(uint32_t d, uint32_t a, uint32_t b, uint32_t xo, bool rc) {
  return (31u << 26) | (d << 21) | (a << 16) | (b << 11) | (xo << 1) | (rc ? 1u : 0u);
}

void TestMsrEE() {
  std::printf("[SIM] MSR[EE] = 0x8000 e MSR limpo ao entrar na excecao\n");
  Memory mem; std::string err; CHECK(mem.Init(err));
  Cpu cpu(mem); cpu.Reset(kCode);
  mem.Write(kCode, 4, 0x60000000u);  // nop
  cpu.msr = 0x8000u; cpu.RequestExternalInterrupt();
  CHECK(cpu.Step() == StopReason::Running && cpu.pc == 0x500);
  // O antigo bit 16 (0x10000) NAO habilita interrupcao.
  cpu.Reset(kCode); cpu.msr = 0x10000u; cpu.RequestExternalInterrupt();
  CHECK(cpu.Step() == StopReason::Running && cpu.pc == kCode + 4);
  // IR/DR/FP/PR/EE sao desligados no tratador; ME/IP preservados.
  cpu.Reset(kCode); cpu.msr = 0x8000u | 0x4000u | 0x2000u | 0x30u | 0x1000u;
  cpu.RequestExternalInterrupt();
  cpu.Step();
  CHECK(cpu.msr == 0x1000u);
  CHECK(cpu.srr1 == (0x8000u | 0x4000u | 0x2000u | 0x30u | 0x1000u));
}

void TestReservation() {
  std::printf("[SIM] lwarx / stwcx.\n");
  Memory mem; std::string err; CHECK(mem.Init(err));
  Cpu cpu(mem); cpu.Reset(kCode);
  cpu.gpr[3] = kData; cpu.gpr[5] = 0xCAFEBABEu;
  mem.Write(kData, 4, 0x11223344u);
  mem.Write(kCode, 4, X31(4, 0, 3, 20, false));        // lwarx r4,0,r3
  mem.Write(kCode + 4, 4, X31(5, 0, 3, 150, true));    // stwcx. r5,0,r3
  mem.Write(kCode + 8, 4, X31(5, 0, 3, 150, true));    // stwcx. de novo (sem reserva) -> falha
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.gpr[4] == 0x11223344u);
  CHECK(cpu.Step() == StopReason::Running);
  uint32_t v = 0; mem.Read(kData, 4, v);
  CHECK(v == 0xCAFEBABEu);
  CHECK(((cpu.cr >> 28) & 2u) == 2u);                   // CR0[EQ] = sucesso
  mem.Write(kData, 4, 0x55u);
  CHECK(cpu.Step() == StopReason::Running);
  mem.Read(kData, 4, v);
  CHECK(v == 0x55u);                                    // nao gravou
  CHECK(((cpu.cr >> 28) & 2u) == 0u);                   // EQ = 0 = falhou
}

void TestFpscrAndRounding() {
  std::printf("[SIM] mffs na palavra baixa e restauracao do arredondamento\n");
  Memory mem; std::string err; CHECK(mem.Init(err));
  Cpu cpu(mem); cpu.Reset(kCode); cpu.msr = 1u << 13;
  cpu.fpscr = 0x00000003u;
  mem.Write(kCode, 4, (63u << 26) | (1u << 21) | (583u << 1));   // mffs f1
  CHECK(cpu.Step() == StopReason::Running);
  uint64_t bits; std::memcpy(&bits, &cpu.fpr[1], 8);
  CHECK((bits & 0xFFFFFFFFull) == 3u);                  // FPSCR na palavra baixa
  CHECK((bits >> 32) == 0xFFF80000u);

  // mtfsf 0xFF, f1 le a palavra baixa: FPSCR volta a ter RN = 3.
  cpu.fpscr = 0;
  mem.Write(kCode + 4, 4, (63u << 26) | (0xFFu << 17) | (1u << 11) | (711u << 1));
  CHECK(cpu.Step() == StopReason::Running);
  CHECK((cpu.fpscr & 3u) == 3u);

  // fadd com RN != nearest nao pode vazar o modo para o resto do programa.
  cpu.set_ps0(1, 1.0f); cpu.set_ps0(2, 2.0f);
  mem.Write(kCode + 8, 4, (63u << 26) | (3u << 21) | (1u << 16) | (2u << 11) | (21u << 1));
  CHECK(cpu.Step() == StopReason::Running);
  CHECK(cpu.fpr[3] == 3.0);
  CHECK(std::fegetround() == FE_TONEAREST);
}

}  // namespace

int main() {
  TestMsrEE();
  TestReservation();
  TestFpscrAndRounding();
  std::printf("\n[SIM] test_cpu_fixes: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
