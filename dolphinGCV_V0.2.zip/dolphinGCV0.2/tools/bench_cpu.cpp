// Benchmark simples do interpretador: laco com addi + lwz + stw + b (passos/segundo).
#include <chrono>
#include <cstdio>
#include "cpu.h"
#include "memory.h"
int main() {
  dps3::Memory mem; std::string err;
  if (!mem.Init(err)) return 1;
  const uint32_t prog[4] = {0x38630001u, 0x80850000u, 0x90850004u, 0x4BFFFFF4u};
  for (int i = 0; i < 4; ++i) mem.Write(0x80003000u + 4 * i, 4, prog[i]);
  dps3::Cpu cpu(mem);
  cpu.Reset(0x80003000u);
  cpu.gpr[5] = 0x80004000u;
  const uint64_t N = 40000000ull;
  auto t0 = std::chrono::steady_clock::now();
  cpu.Run(N);
  double s = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
  std::printf("%.1f Mpassos/s (%.2fs, r3=%u)\n", N / s / 1e6, s, cpu.gpr[3]);
  return 0;
}
