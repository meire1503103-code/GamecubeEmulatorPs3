// Plataforma PS3 (PSL1GHT): video via RSX/GCM (framebuffer XRGB com 2 buffers) + sysutil.
//
// NAO TESTADO em hardware nem com o PSL1GHT real: segue o padrao dos exemplos do PSL1GHT
// (rsxutil: rsxInit / videoConfigure / gcmSetDisplayBuffer / gcmSetFlip). Se o 1o build acusar
// nome de funcao ou header diferente, o ajuste fica concentrado neste arquivo.
#ifdef DOLPHINPS3_PLATFORM_PS3

#include "font8x16.h"
#include "platform.h"

#include <malloc.h>
#include <string.h>
#include <unistd.h>

#include <ppu-types.h>
#include <rsx/rsx.h>
#include <sysutil/sysutil.h>
#include <sysutil/video.h>

namespace dps3 {
namespace {

constexpr u32 kCmdSize = 0x100000;        // fila de comandos da RSX (1 MiB)
constexpr u32 kHostSize = 8 * 1024 * 1024;  // area de IO compartilhada (multiplo de 1 MiB)

struct Buffer {
  uint32_t* ptr = nullptr;
  u32 offset = 0;
};

gcmContextData* g_ctx = nullptr;
void* g_host = nullptr;
Buffer g_buf[2];
int g_cur = 0, g_w = 0, g_h = 0, g_scale = 1;
bool g_video = false, g_exit = false, g_first_flip = true;

void SysutilCallback(u64 status, u64 /*param*/, void* /*user*/) {
  if (status == SYSUTIL_EXIT_GAME) g_exit = true;  // "Sair do jogo" no menu do botao PS
}

void WaitFlip() {
  while (gcmGetFlipStatus() != 0) usleep(200);
  gcmResetFlipStatus();
}

bool VideoUp(TextScreen& screen) {
  g_host = memalign(1024 * 1024, kHostSize);
  if (!g_host) return false;
  if (rsxInit(&g_ctx, kCmdSize, kHostSize, g_host) != 0 || !g_ctx) return false;

  videoState st;
  if (videoGetState(0, 0, &st) != 0 || st.state != 0) return false;
  videoResolution res;
  if (videoGetResolution(st.displayMode.resolution, &res) != 0) return false;

  videoConfiguration cfg;
  memset(&cfg, 0, sizeof cfg);
  cfg.resolution = st.displayMode.resolution;
  cfg.format = VIDEO_BUFFER_FORMAT_XRGB;
  cfg.pitch = res.width * sizeof(u32);
  if (videoConfigure(0, &cfg, NULL, 0) != 0) return false;

  g_w = res.width;
  g_h = res.height;
  gcmSetFlipMode(GCM_FLIP_VSYNC);
  for (int i = 0; i < 2; ++i) {
    const u32 pitch = g_w * sizeof(u32);
    g_buf[i].ptr = static_cast<uint32_t*>(rsxMemalign(64, pitch * g_h));
    if (!g_buf[i].ptr) return false;
    if (gcmAddressToOffset(g_buf[i].ptr, &g_buf[i].offset) != 0) return false;
    if (gcmSetDisplayBuffer(i, g_buf[i].offset, pitch, g_w, g_h) != 0) return false;
    memset(g_buf[i].ptr, 0, static_cast<size_t>(pitch) * g_h);
  }
  gcmResetFlipStatus();

  // Ampliacao inteira: 480p/576p x1, 720p x2, 1080p x3. A grade ocupa ~90% (area segura da TV).
  g_scale = g_h / 360 < 1 ? 1 : g_h / 360;
  const int cols = static_cast<int>(g_w * 0.92) / (kGlyphW * g_scale);
  const int rows = static_cast<int>(g_h * 0.90) / (kGlyphH * g_scale);
  screen.Resize(cols > 100 ? 100 : cols, rows > 40 ? 40 : rows);
  return true;
}

}  // namespace

bool PlatformInit(TextScreen& screen) {
  sysUtilRegisterCallback(SYSUTIL_EVENT_SLOT0, SysutilCallback, NULL);
  g_video = VideoUp(screen);
  if (g_video) screen.set_xmb_background(true);  // fundo GameCube/XMB procedimental
  return g_video;
}

void PlatformShutdown() {
  if (g_video) {
    gcmSetWaitFlip(g_ctx);
    for (int i = 0; i < 2; ++i)
      if (g_buf[i].ptr) rsxFree(g_buf[i].ptr);
    rsxFinish(g_ctx, 1);
    g_video = false;
  }
  if (g_host) { free(g_host); g_host = nullptr; }
  sysUtilUnregisterCallback(SYSUTIL_EVENT_SLOT0);
}

bool PlatformPump() {
  sysUtilCheckCallback();
  return !g_exit;
}

void PlatformPresent(TextScreen& screen) {
  if (!g_video || !screen.TakeDirty()) return;  // nada mudou: nao gasta tempo desenhando
  if (!g_first_flip) WaitFlip();
  screen.Rasterize(g_buf[g_cur].ptr, g_w, g_h, g_w, g_scale);
  if (gcmSetFlip(g_ctx, g_cur) == 0) {
    rsxFlushBuffer(g_ctx);
    gcmSetWaitFlip(g_ctx);
    g_first_flip = false;
    g_cur ^= 1;
  }
}

void PlatformSleepMs(unsigned ms) { usleep(ms * 1000u); }

}  // namespace dps3
#endif  // DOLPHINPS3_PLATFORM_PS3
