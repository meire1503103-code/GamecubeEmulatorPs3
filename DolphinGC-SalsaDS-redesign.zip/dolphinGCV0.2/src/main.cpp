// DolphinGC V0.2 - emulador SOMENTE de GameCube para PS3 (em desenvolvimento).
// A biblioteca lista todos os discos GameCube ISO/GCM encontrados na pasta DolphinGC.
// Jogos ficam na pasta DolphinGC (PS3: /dev_hdd0/DolphinGC; PC: ./DolphinGC).
// Ainda NAO ha MMIO, GPU, DSP, audio nem input: o boot roda ate a primeira instrucao
// nao implementada ou acesso a memoria nao mapeada (normalmente os registradores de
// hardware em 0xCC00xxxx) e mostra onde parou.
//
// Build PS3: adicionar src/*.cpp ao Makefile PSL1GHT do projeto e definir
// -DDOLPHINPS3_PLATFORM_PS3. Sem essa macro compila como host (g++) para testes.
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstdarg>
#include <cstring>
#include <dirent.h>
#include <fstream>
#include <memory>
#include <sstream>
#include <sys/stat.h>
#include <string>
#include <vector>
#ifdef DOLPHINPS3_PLATFORM_PS3
#include <unistd.h>
#endif

#include "args.h"
#include "boot.h"
#include "cpu.h"
#include "disc.h"
#include "dol.h"
#include "fst.h"
#include "input.h"
#include "memory.h"
#include "menu.h"
#include "mmio.h"
#include "strutil.h"
#include "system.h"
#include "ui.h"

namespace {

constexpr const char* kVersion = "DolphinGC V0.2 (somente GameCube)";

// Tudo que o programa "imprime" vai para o stdout (log.txt no PS3) E para uma lista de linhas que o
// menu mostra na TV. Sem isso, no PS3 o resultado de rodar um jogo so existiria dentro do log.
std::vector<std::string> g_report;
std::string g_partial;

void Out(const char* fmt, ...) {
  char buf[1024];
  va_list ap;
  va_start(ap, fmt);
  std::vsnprintf(buf, sizeof buf, fmt, ap);
  va_end(ap);
  std::fputs(buf, stdout);
  for (const char* p = buf; *p; ++p) {
    if (*p == '\n') {
      if (g_report.size() < 20000) g_report.push_back(g_partial);
      g_partial.clear();
    } else if (*p != '\r') {
      g_partial.push_back(*p);
    }
  }
}

void FlushReport() {
  if (!g_partial.empty()) { g_report.push_back(g_partial); g_partial.clear(); }
}

// Fonte do controle para o jogo: no PS3 le o pad (libpad) e converte para GameCube.
bool GamePadSource(dps3::GameCubePadState& out) {
#ifdef DOLPHINPS3_PLATFORM_PS3
  dps3::Ps3PadState ps3;
  if (!dps3::PadPoll(ps3)) return false;
  out = dps3::MapPs3ToGameCube(ps3);
  return true;
#else
  (void)out;
  return false;
#endif
}

// Limite de seguranca do primeiro boot (instrucoes interpretadas).
constexpr uint64_t kMaxBootSteps = 50000000ull;

#ifdef DOLPHINPS3_PLATFORM_PS3
// PS3 nao tem linha de comando nem console visivel. Ao instalar o .pkg, o app
// fica em /dev_hdd0/game/DGCV00001/USRDIR/ (mesmo ID do sfo.xml/Makefile).
//  - args.txt : mesmos argumentos da CLI, ex.:  /dev_hdd0/DolphinGC/jogo.iso
//  - log.txt  : tudo que o programa imprimiria (stdout/stderr) vai para este arquivo
constexpr const char* kArgsFile = "/dev_hdd0/game/DGCV00001/USRDIR/args.txt";
constexpr const char* kLogFile = "/dev_hdd0/game/DGCV00001/USRDIR/log.txt";

void RedirectOutputToLog() {
  // Trunca uma vez e abre stdout/stderr em modo append (evita um sobrescrever o outro).
  if (std::FILE* t = std::fopen(kLogFile, "w")) std::fclose(t);
  std::freopen(kLogFile, "a", stdout);
  std::freopen(kLogFile, "a", stderr);
  std::setvbuf(stdout, nullptr, _IONBF, 0);  // sem buffer: o log sobrevive a um travamento
  std::setvbuf(stderr, nullptr, _IONBF, 0);
}
#endif

std::vector<std::string> CollectArgs(int argc, char** argv) {
  std::vector<std::string> a;
#ifdef DOLPHINPS3_PLATFORM_PS3
  (void)argc; (void)argv;
  std::ifstream in(kArgsFile);
  if (in) {
    std::stringstream ss;
    ss << in.rdbuf();
    a = dps3::TokenizeArgsText(ss.str());
  }
#else
  for (int i = 1; i < argc; ++i) a.push_back(argv[i]);
#endif
  return a;
}


// Pasta onde ficam os jogos: DolphinGC. No PS3 fica em /dev_hdd0; no PC, ao lado do programa.
#ifdef DOLPHINPS3_PLATFORM_PS3
constexpr const char* kIsoDir = "/dev_hdd0/DolphinGC";
#else
constexpr const char* kIsoDir = "DolphinGC";
#endif

// Cria a pasta DolphinGC se ainda nao existir (para o usuario so copiar os jogos para la).
void EnsureGameDir() {
#ifdef DOLPHINPS3_PLATFORM_PS3
  mkdir(kIsoDir, 0777);
#else
  mkdir(kIsoDir, 0777);
#endif
}

bool HasDiscExtension(const std::string& name) {
  const size_t dot = name.rfind('.');
  if (dot == std::string::npos) return false;
  std::string ext = name.substr(dot);
  std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) { return std::tolower(c); });
  return ext == ".iso" || ext == ".gcm";
}

std::vector<std::string> ListDiscs(const std::string& dir) {
  std::vector<std::string> out;
  if (DIR* d = opendir(dir.c_str())) {
    while (const dirent* e = readdir(d)) {
      const std::string name = e->d_name;
      if (HasDiscExtension(name)) out.push_back(dir + "/" + name);
    }
    closedir(d);
  }
  std::sort(out.begin(), out.end());
  return out;
}

struct LibraryGame {
  std::string path, title, game_id, info;
};

std::vector<LibraryGame> g_library;

std::vector<LibraryGame> ScanLibrary() {
  std::vector<LibraryGame> games;
  const std::vector<std::string> paths = ListDiscs(kIsoDir);
  for (const std::string& path : paths) {
    LibraryGame game;
    game.path = path;
    const size_t slash = path.find_last_of('/');
    const std::string filename = slash == std::string::npos ? path : path.substr(slash + 1);
    const size_t dot = filename.find_last_of('.');
    game.title = dot == std::string::npos ? filename : filename.substr(0, dot);
    dps3::DiscReader disc;
    std::string err;
    if (disc.Open(path, err)) {
      game.game_id = disc.game_id();
      if (!disc.title().empty()) {
        game.title = disc.title();
        while (!game.title.empty() && (game.title.back() == ' ' || game.title.back() == '\0'))
          game.title.pop_back();
      }
    } else {
      game.game_id = "NAO VALIDADO";
    }
    game.info = "ID|" + game.game_id + "\nArquivo|" + filename +
                "\nFormato|ISO/GCM\nPasta|DolphinGC";
    games.push_back(game);
  }
  return games;
}

// Carrega e (opcionalmente) lista a FST / executa o boot de um disco. Devolve o codigo de saida.
// Contexto do callback de progresso do boot (atualiza a tela e deixa cancelar com Bolinha).
struct BootUi {
  dps3::Ui* ui = nullptr;
  std::string title;
  uint64_t last_draw = ~0ull;
};

bool BootProgress(uint64_t steps, void* user) {
  BootUi* b = static_cast<BootUi*>(user);
  if (!b->ui) return true;
  if (b->ui->CancelRequested()) return false;
  const uint64_t step_m = steps / 1000000ull;
  if (step_m != b->last_draw) {  // so redesenha a cada 1 milhao de passos
    b->last_draw = step_m;
    dps3::TextScreen& s = b->ui->screen();
    s.Clear();
    s.PutCentered(0, "EXECUTANDO", dps3::kCyan);
    s.HLine(1);
    s.PutCentered(5, b->title, dps3::kWhite);
    s.PutCentered(7, dps3::NumStrU(step_m) + " milhoes de instrucoes executadas", dps3::kYellow);
    s.PutCentered(9, "(ainda nao ha video do jogo: veja o relatorio ao final)", dps3::kGray);
    s.HLine(s.rows() - 2);
    s.PutCentered(s.rows() - 1, "Bolinha: cancelar", dps3::kGray);
    dps3::PlatformPresent(s);
  }
  return true;
}

int RunTarget(const std::string& target, bool list_files, dps3::Ui* ui = nullptr) {
  std::string err;
  dps3::DiscReader disc;
  if (!disc.Open(target, err)) {
    Out("erro ao abrir disco: %s\n", err.c_str());
    return 1;
  }
  Out("Console : %s\nGame ID : %s\nTitulo  : %s\nDisco   : %u  Versao: %u\nTamanho : %llu bytes\n",
              dps3::KindName(disc.kind()), disc.game_id().c_str(), disc.title().c_str(),
              disc.disc_number(), disc.version(),
              static_cast<unsigned long long>(disc.size()));
  if (list_files) {
    dps3::GameCubeFst fst;
    std::string fst_error;
    if (!fst.Load(disc, fst_error)) {
      Out("Erro ao carregar FST: %s\n", fst_error.c_str());
      return 1;
    }
    Out("\n=== GAMECUBE FILE SYSTEM ===\n");
    for (const auto& entry : fst.entries()) {
      if (entry.type == dps3::FstEntryType::Directory) {
        Out("[DIR]  %s\n", entry.path.c_str());
      } else {
        Out("[FILE] %s | Offset: %llu | Size: %llu\n", entry.path.c_str(),
                    static_cast<unsigned long long>(entry.offset),
                    static_cast<unsigned long long>(entry.size));
      }
    }
    Out("\nTotal de entradas: %lu\n", static_cast<unsigned long>(fst.entries().size()));
    return 0;
  }

  // ---- boot: apploader real (preferido) ou, se falhar, DOL direto ----
  dps3::Memory mem;
  if (!mem.Init(err)) { Out("erro: %s\n", err.c_str()); return 1; }
  // MmioHandler tem ~64 KB: no heap para nao estourar a pilha pequena do PS3.
  std::unique_ptr<dps3::MmioHandler> hw_ptr(new dps3::MmioHandler);
  dps3::MmioHandler& hw = *hw_ptr;
  mem.SetMmio(&hw);
  hw.Attach(&mem, &disc);
  dps3::Cpu cpu(mem);

  uint32_t entry = 0;
  std::string app_err;
  if (dps3::BootGameCubeApploader(disc, mem, cpu, entry, app_err)) {
    Out("\nBoot    : apploader executado na CPU, entry do jogo 0x%08X\n", entry);
  } else {
    Out("\nBoot    : apploader falhou (%s)\n          usando o DOL principal direto.\n", app_err.c_str());
    // O apploader pode ter sujado a RAM/CPU: recomeca limpo.
    if (!mem.Init(err)) { Out("erro: %s\n", err.c_str()); return 1; }
    hw.Reset();
    dps3::DolImage dol;
    if (!dps3::BootGameCubeDol(disc, mem, cpu, dol, err)) {
      Out("erro ao carregar o DOL: %s\n", err.c_str());
      return 1;
    }
    Out("DOL     : %lu secoes, entry 0x%08X, bss 0x%08X (+0x%X)\n",
                static_cast<unsigned long>(dol.sections.size()), dol.entry, dol.bss_address, dol.bss_size);
  }

  BootUi boot_ui;
  boot_ui.ui = ui;
  boot_ui.title = disc.title().empty() ? disc.game_id() : disc.title();
  const dps3::StopReason why =
      dps3::RunSystem(cpu, hw, kMaxBootSteps, GamePadSource, BootProgress, &boot_ui);
  Out("\nCPU parou: %s\n", dps3::StopReasonName(why));
  Out("  passos : %llu\n  pc     : 0x%08X   instr: 0x%08X\n",
              static_cast<unsigned long long>(cpu.steps()), cpu.pc, cpu.last_instr);
  if (why == dps3::StopReason::MemFault)
    Out("  endereco acessado: 0x%08X\n", cpu.fault_addr);
  Out("  lr=0x%08X ctr=0x%08X cr=0x%08X xer=0x%08X msr=0x%08X\n", cpu.lr, cpu.ctr, cpu.cr, cpu.xer, cpu.msr);
  for (int i = 0; i < 32; i += 4)
    Out("  r%-2d=%08X r%-2d=%08X r%-2d=%08X r%-2d=%08X\n", i, cpu.gpr[i], i + 1,
                cpu.gpr[i + 1], i + 2, cpu.gpr[i + 2], i + 3, cpu.gpr[i + 3]);
  Out("\nHardware: %llu acessos MMIO, %llu quadros de VI, DVD: %llu leituras / %llu bytes / %llu erros\n"
              "          interrupcoes PI pendentes: 0x%08X\n",
              static_cast<unsigned long long>(hw.mmio_accesses()), static_cast<unsigned long long>(hw.frames()),
              static_cast<unsigned long long>(hw.dvd_reads()), static_cast<unsigned long long>(hw.dvd_bytes()),
              static_cast<unsigned long long>(hw.dvd_errors()), hw.pi_cause());

  Out("\n[status V0.2] ainda faltam para o jogo aparecer: video GX->RSX, audio DSP\n"
              "  de verdade, mais instrucoes/hardware (veja onde a CPU parou acima).\n");
  return 0;
}

// Menu de escolha de ISO. Devolve "" se o usuario voltou/cancelou.
std::string ChooseDisc(dps3::Ui& ui) {
  std::vector<std::string> discs = ListDiscs(kIsoDir);
  if (discs.empty()) {
      ui.ShowLines("ESCOLHA O JOGO",
                 {std::string("Nenhum arquivo ISO/GCM encontrado em ") + kIsoDir + ".", "",
                  "Copie um disco de GameCube para a pasta DolphinGC", "e abra esta opcao de novo.", "",
                  "Discos de Wii e arquivos RVZ/WIA/GCZ nao sao aceitos."},
                 "Bolinha: voltar");
    return "";
  }
  dps3::MenuSystem pick;
  std::vector<dps3::MenuItem> items;
  for (size_t i = 0; i < discs.size(); ++i) {
    const size_t slash = discs[i].rfind('/');
    items.push_back({slash == std::string::npos ? discs[i] : discs[i].substr(slash + 1),
                     static_cast<int>(i)});
  }
  items.push_back({"Voltar", -2});
  pick.SetItems(items, "ESCOLHA O JOGO");
  pick.set_back_action(-2, true);
  for (;;) {
    pick.RenderScreen(ui.screen());
    dps3::UiEvent ev;
    if (!ui.Wait(ev)) return "";
    const int act = ev.direct >= 0 ? pick.SelectOption(ev.direct) : pick.Handle(ev.nav);
    if (act == -2) return "";
    if (act >= 0 && act < static_cast<int>(discs.size())) return discs[act];
  }
}

// Roda um disco e mostra o relatorio na tela (no PS3 a tela e a unica saida visivel).
int RunTargetOnScreen(dps3::Ui& ui, const std::string& path, bool list_files, const char* title) {
  g_report.clear();
  g_partial.clear();
  const int rc = RunTarget(path, list_files, &ui);
  FlushReport();
  if (!ui.exit_requested()) ui.ShowLines(title, g_report);
  return rc;
}

// Refaz a biblioteca ao abrir/solicitar atualizacao e preserva o jogo selecionado pelo caminho.
void RefreshMenuState(dps3::MenuSystem& menu) {
  const int old_action = menu.selected_action();
  std::string old_path;
  if (old_action >= dps3::MENU_ACTION_OPEN_GAME_BASE) {
    const size_t old_index = static_cast<size_t>(old_action - dps3::MENU_ACTION_OPEN_GAME_BASE);
    if (old_index < g_library.size()) old_path = g_library[old_index].path;
  }

  g_library = ScanLibrary();
  std::vector<dps3::MenuItem> items;
  items.reserve(g_library.size() + 11);
  if (g_library.empty()) {
    items.push_back({"Nenhum jogo encontrado", dps3::MENU_ACTION_EMPTY,
                     "Copie arquivos ISO/GCM de GameCube para DolphinGC.\nPressione Triangulo para atualizar.",
                     "JOGOS", "", "COPIAR ISO/GCM", static_cast<uint8_t>(dps3::kGray)});
  } else {
    for (size_t i = 0; i < g_library.size(); ++i) {
      const LibraryGame& game = g_library[i];
      items.push_back({game.title, dps3::MENU_ACTION_OPEN_GAME_BASE + static_cast<int>(i), game.info,
                       "JOGOS", "", "INICIAR JOGO", static_cast<uint8_t>(dps3::kGreen)});
    }
  }
  items.push_back({"Abrir arquivo ISO/GCM", dps3::MENU_ACTION_LOAD_ISO,
                   "Escolha manualmente um disco de GameCube.", "FERRAMENTAS", "", "ABRIR ARQUIVO", 0});
  items.push_back({"Arquivos do disco (FST)", dps3::MENU_ACTION_LIST_FST,
                   "Mostra pastas e arquivos do disco selecionado.", "FERRAMENTAS", "", "VER ARQUIVOS", 0});
  items.push_back({"Hello World", dps3::MENU_ACTION_HELLO,
                   "Demo simples executada pela CPU PowerPC emulada.", "FERRAMENTAS", "", "EXECUTAR DEMO", 0});
  items.push_back({"Calculadora", dps3::MENU_ACTION_CALC,
                   "Demonstra operacoes feitas pela CPU emulada.", "FERRAMENTAS", "", "ABRIR", 0});
  items.push_back({"Geral", dps3::MENU_ACTION_SETTINGS_GENERAL,
                   "Pasta de jogos, formatos aceitos e atualizacao da biblioteca.", "CONFIGURACAO", "", "VER", 0});
  items.push_back({"Graficos", dps3::MENU_ACTION_SETTINGS_GRAPHICS,
                   "Renderer da interface e estado do video GameCube.", "CONFIGURACAO", "", "VER", 0});
  items.push_back({"Controles", dps3::MENU_ACTION_CONTROLS,
                   "Mapeamento do DualShock 3 para o controle GameCube.", "CONFIGURACAO", "", "VER CONTROLES", 0});
  items.push_back({"Desempenho", dps3::MENU_ACTION_SETTINGS_PERFORMANCE,
                   "Estado do nucleo e recursos de desempenho disponiveis.", "CONFIGURACAO", "", "VER", 0});
  items.push_back({"Sobre o DolphinGC", dps3::MENU_ACTION_INFO,
                   "Versao, estado do projeto e informacoes da biblioteca.", "SOBRE", "", "INFORMACOES", 0});
  items.push_back({"Sair", dps3::MENU_ACTION_EXIT, "Fecha o DolphinGC e volta ao XMB.",
                   "SOBRE", "", "SAIR", 0});
  menu.SetItems(items, "BIBLIOTECA DE JOGOS");

  bool restored = false;
  if (!old_path.empty()) {
    for (size_t i = 0; i < g_library.size(); ++i)
      if (g_library[i].path == old_path)
        restored = menu.SelectAction(dps3::MENU_ACTION_OPEN_GAME_BASE + static_cast<int>(i));
  }
  if (!restored && old_action >= 0) restored = menu.SelectAction(old_action);
  if (!restored) {
    if (g_library.empty()) menu.SelectAction(dps3::MENU_ACTION_EMPTY);
    else menu.SelectAction(dps3::MENU_ACTION_OPEN_GAME_BASE);
  }
  char status[96];
  std::snprintf(status, sizeof status, "%lu JOGO(S)  |  %s",
                static_cast<unsigned long>(g_library.size()), kIsoDir);
  menu.SetStatus(status, g_library.empty() ? dps3::kYellow : dps3::kIce);
}

int RunMenu() {
  dps3::Ui ui;
  ui.Init();
  dps3::MenuSystem menu;
  menu.Init();
  RefreshMenuState(menu);
  std::printf("[Menu] Sistema de Menu inicializado com sucesso.\n");
  dps3::ControllerProfile profile = dps3::ControllerProfile::GameCube;
  int rc = 0;
  for (;;) {
    menu.RenderScreen(ui.screen());
    dps3::UiEvent ev;
    if (!ui.Wait(ev)) break;  // XMB pediu para fechar, ou fim da entrada no PC
    const int old_selection = menu.selected();
    const int act = ev.direct >= 0 ? menu.SelectOption(ev.direct) : menu.Handle(ev.nav);
    if (act < 0) {
      if (ui.screen().xmb_background() && menu.selected() != old_selection) {
        // Transicao curta disparada por entrada: 5 frames, sem animacao continua enquanto parado.
        for (int frame = 0; frame <= 4; ++frame) {
          menu.SetFocusTransitionFrame(frame);
          menu.RenderScreen(ui.screen());
          dps3::PlatformPresent(ui.screen());
          if (frame < 4) dps3::PlatformSleepMs(12);
        }
        menu.SetFocusTransitionFrame(4);
      }
      continue;
    }
    menu.SetFocusTransitionFrame(4);
    if (act == dps3::MENU_ACTION_REFRESH) {
      RefreshMenuState(menu);
      continue;
    }
    if (act == dps3::MENU_ACTION_EXIT) break;
    if (act >= dps3::MENU_ACTION_OPEN_GAME_BASE) {
      const size_t index = static_cast<size_t>(act - dps3::MENU_ACTION_OPEN_GAME_BASE);
      if (index < g_library.size())
        rc = RunTargetOnScreen(ui, g_library[index].path, false, "RELATORIO DO BOOT");
    } else if (act == dps3::MENU_ACTION_EMPTY) {
      RefreshMenuState(menu);
    } else if (act == dps3::MENU_ACTION_HELLO) {
      ui.RunHelloScreen();
    } else if (act == dps3::MENU_ACTION_CALC) {
      ui.RunCalculatorScreen();
    } else if (act == dps3::MENU_ACTION_LOAD_ISO || act == dps3::MENU_ACTION_LIST_FST) {
      const std::string path = ChooseDisc(ui);
      if (!path.empty())
        rc = RunTargetOnScreen(ui, path, act == dps3::MENU_ACTION_LIST_FST,
                               act == dps3::MENU_ACTION_LIST_FST ? "FST DO DISCO" : "RELATORIO DO BOOT");
    } else if (act == dps3::MENU_ACTION_CONTROLS) {
      ui.RunControlsScreen(profile);
    } else if (act == dps3::MENU_ACTION_SETTINGS_GENERAL) {
      ui.ShowLines("CONFIGURACOES GERAIS",
                   {std::string("Pasta da biblioteca: ") + kIsoDir,
                    "Formatos: ISO e GCM sem compressao.",
                    "Atualizacao: Triangulo na aba Jogos.",
                    "Os arquivos nao sao movidos nem modificados pelo emulador."}, "O: voltar");
    } else if (act == dps3::MENU_ACTION_SETTINGS_GRAPHICS) {
      ui.ShowLines("CONFIGURACOES GRAFICAS",
                   {"Saida da interface: framebuffer XRGB pela RSX.",
                    "Resolucao: deteccao automatica do modo do PS3.",
                    "Video dos jogos: GX para RSX ainda nao implementado.",
                    "Filtros e escalas de jogo: indisponiveis nesta versao."}, "O: voltar");
    } else if (act == dps3::MENU_ACTION_SETTINGS_PERFORMANCE) {
      ui.ShowLines("DESEMPENHO",
                   {"Esta versao ainda nao apresenta jogos em execucao.",
                    "A CPU PowerPC possui interpretador; o video GX e o audio DSP ainda faltam.",
                    "Nao existem controles de clock ou filtros pesados ativos no menu.",
                    "A interface fica ociosa sem redesenho continuo."}, "O: voltar");
    } else if (act == dps3::MENU_ACTION_INFO) {
      ui.ShowLines("INFORMACOES",
                   {kVersion, std::string("Perfil de controle ativo: ") + dps3::ProfileName(profile),
                    std::string("Pasta dos jogos: ") + kIsoDir,
                    std::string("Discos encontrados: ") + dps3::NumStrU(g_library.size()), "",
                    "Estado: o boot experimental ainda nao exibe video do jogo nem audio.",
                    "Hello World e Calculadora rodam de verdade na CPU emulada."},
                   "O: voltar");
    }
    if (ui.exit_requested()) break;
    RefreshMenuState(menu);  // preserva o jogo selecionado e detecta arquivos adicionados/removidos
  }
  ui.Shutdown();
  return rc;
}

}  // namespace

int main(int argc, char** argv) {
#ifdef DOLPHINPS3_PLATFORM_PS3
  RedirectOutputToLog();
#endif
  dps3::LaunchOptions opt;
  std::string err;
  if (!dps3::ParseArgs(CollectArgs(argc, argv), opt, err)) {
    std::fprintf(stderr, "erro: %s\n\n%s", err.c_str(), dps3::UsageText());
    return 2;
  }
  if (opt.show_help) { std::fputs(dps3::UsageText(), stdout); return 0; }
  if (opt.show_version) { std::printf("%s\n", kVersion); return 0; }

  EnsureGameDir();
  std::printf("%s\n", kVersion);

  // Prioridade do alvo de boot: --exec, depois primeiro FILE posicional.
  std::string target = !opt.exec_file.empty() ? opt.exec_file
                       : (!opt.files.empty() ? opt.files[0] : std::string());
  if (target.empty()) return RunMenu();  // sem disco informado: abre o menu
  return RunTarget(target, opt.list_files);
}
