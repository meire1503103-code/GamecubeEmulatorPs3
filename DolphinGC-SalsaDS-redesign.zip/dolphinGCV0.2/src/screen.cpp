#include "screen.h"

#include <algorithm>
#include <cmath>

#include "font8x16.h"

namespace dps3 {

void TextScreen::Resize(int cols, int rows) {
  cols_ = std::max(1, cols);
  rows_ = std::max(1, rows);
  cells_.assign(static_cast<size_t>(cols_) * rows_, Cell());
  shown_.clear();  // forca um redesenho completo
}

void TextScreen::Clear(Color bg) {
  scenic_ = false;  // telas auxiliares usam o fundo escurecido; o menu principal liga o modo claro
  Cell c;
  c.bg = bg;
  std::fill(cells_.begin(), cells_.end(), c);
}

void TextScreen::Put(int x, int y, const std::string& s, Color fg, Color bg) {
  if (y < 0 || y >= rows_) return;
  for (size_t i = 0; i < s.size(); ++i, ++x) {
    if (x < 0) continue;
    if (x >= cols_) break;
    char ch = s[i];
    if (ch < kFirstGlyph || ch > kLastGlyph) ch = '?';
    Cell& c = cells_[static_cast<size_t>(y) * cols_ + x];
    c.ch = ch; c.fg = fg; c.bg = bg;
  }
}

void TextScreen::PutCentered(int y, const std::string& s, Color fg, Color bg) {
  Put((cols_ - static_cast<int>(s.size())) / 2, y, s, fg, bg);
}

void TextScreen::FillRow(int y, Color bg) {
  if (y < 0 || y >= rows_) return;
  for (int x = 0; x < cols_; ++x) {
    Cell& c = cells_[static_cast<size_t>(y) * cols_ + x];
    c.ch = ' '; c.bg = bg;
  }
}

void TextScreen::HLine(int y, char ch, Color fg) {
  Put(0, y, std::string(static_cast<size_t>(cols_), ch), fg);
}

std::string TextScreen::RowText(int y) const {
  std::string s;
  if (y < 0 || y >= rows_) return s;
  for (int x = 0; x < cols_; ++x) s.push_back(cells_[static_cast<size_t>(y) * cols_ + x].ch);
  while (!s.empty() && s.back() == ' ') s.pop_back();
  return s;
}

bool TextScreen::TakeDirty() {
  if (shown_ == cells_ && shown_scenic_ == scenic_) return false;
  shown_ = cells_;
  shown_scenic_ = scenic_;
  return true;
}

uint32_t TextScreen::RgbOf(Color c) {
  static const uint32_t kPal[kColorCount] = {
    0x00090C10, 0x00F3F5F5, 0x00FFD477, 0x0068D9D0, 0x0077D69A, 0x00F06D63, 0x00939CA2, 0x003D55A5,
    0x00182022, 0x004A6B53, 0x000B0E12, 0x001A2921, 0x00253A2D, 0x00304F3C,
    0x000B0E12, 0x003B438C, 0x006756BD, 0x00BD6657, 0x0076DFFF};
  return kPal[c < kColorCount ? c : kWhite];
}

namespace {

inline int Clamp255(int v) { return v < 0 ? 0 : (v > 255 ? 255 : v); }
inline uint32_t Rgb(int r, int g, int b) {
  return (static_cast<uint32_t>(Clamp255(r)) << 16) | (static_cast<uint32_t>(Clamp255(g)) << 8) |
         static_cast<uint32_t>(Clamp255(b));
}
inline int Lerp(int a, int b, int t256) { return a + (b - a) * t256 / 256; }
inline uint32_t Mix(uint32_t a, uint32_t b, int t256) {  // t256 0..256: quanto de `b`
  return Rgb(Lerp(static_cast<int>((a >> 16) & 255), static_cast<int>((b >> 16) & 255), t256),
             Lerp(static_cast<int>((a >> 8) & 255), static_cast<int>((b >> 8) & 255), t256),
             Lerp(static_cast<int>(a & 255), static_cast<int>(b & 255), t256));
}

// Fundo minimalista escuro, inspirado na legibilidade de uma biblioteca de console.
// Calculado uma vez por resolucao e guardado em RAM; sem particulas, blur ou animacao.
void BuildXmbBackground(std::vector<uint32_t>& bg, int w, int h) {
  bg.assign(static_cast<size_t>(w) * h, 0);
  for (int y = 0; y < h; ++y) {
    const uint32_t row = Mix(Rgb(22, 27, 30), Rgb(10, 13, 15), y * 160 / std::max(1, h));
    uint32_t* p = bg.data() + static_cast<size_t>(y) * w;
    std::fill(p, p + w, row);
  }
}

}  // namespace

void TextScreen::Rasterize(uint32_t* dst, int width, int height, int pitch_px, int scale) const {
  if (!dst || scale < 1) return;
  const int gw = kGlyphW * scale, gh = kGlyphH * scale;
  const int ox = std::max(0, (width - cols_ * gw) / 2);
  const int oy = std::max(0, (height - rows_ * gh) / 2);
  const uint32_t bg0 = RgbOf(kBlack);

  // Fundo XMB em cache (RAM comum): refeito so se a resolucao mudar.
  static std::vector<uint32_t> scenic_cache;
  static int scenic_w = 0, scenic_h = 0;
  if (xmb_background_) {
    if (scenic_w != width || scenic_h != height) {
      BuildXmbBackground(scenic_cache, width, height);
      scenic_w = width; scenic_h = height;
    }
  }

  // Uma linha de pixels de cada vez, sempre escrevendo em ordem crescente (memoria de video).
  std::vector<uint32_t> line(static_cast<size_t>(width));
  for (int y = 0; y < height; ++y) {
    std::vector<uint32_t>::iterator lb = line.begin();
    if (xmb_background_) {
      const uint32_t* src = scenic_cache.data() + static_cast<size_t>(y) * width;
      if (scenic_) std::copy(src, src + width, lb);
      else for (int x = 0; x < width; ++x) line[x] = Mix(src[x], bg0, 170);  // escurece p/ ler o texto
    } else {
      std::fill(line.begin(), line.end(), bg0);
    }
    const int ry = y - oy;
    if (ry >= 0 && ry < rows_ * gh) {
      const int row = ry / gh, gy = (ry % gh) / scale;
      for (int col = 0; col < cols_; ++col) {
        const Cell& c = cells_[static_cast<size_t>(row) * cols_ + col];
        if (ox + (col + 1) * gw > width) break;
        const uint32_t fg = RgbOf(static_cast<Color>(c.fg));
        const uint8_t bits = kFont8x16[(static_cast<unsigned char>(c.ch) - kFirstGlyph) * kGlyphH + gy];
        uint32_t* p = line.data() + ox + col * gw;
        if (!xmb_background_) {
          const uint32_t bg = RgbOf(static_cast<Color>(c.bg));
          for (int gx = 0; gx < kGlyphW; ++gx) {
            const uint32_t px = (bits & (0x80 >> gx)) ? fg : bg;
            for (int s = 0; s < scale; ++s) *p++ = px;
          }
          continue;
        }
        // Modo XMB: kBlack = transparente; paineis e fases de foco sao translucidos.
        int alpha = 256;                       // 256 = cor solida
        if (c.bg == kBlack) alpha = 0;
        else if (c.bg == kPanel) alpha = 170;
        else if (c.bg == kBar) alpha = 215;
        else if (c.bg == kShade) alpha = 190;
        else if (c.bg == kFocus0) alpha = 120;
        else if (c.bg == kFocus1) alpha = 155;
        else if (c.bg == kFocus2) alpha = 185;
        const uint32_t bgc = RgbOf(static_cast<Color>(c.bg));
        for (int gx = 0; gx < kGlyphW; ++gx) {
          const bool on = (bits & (0x80 >> gx)) != 0;
          for (int s = 0; s < scale; ++s, ++p) {
            if (on) *p = fg;
            else if (alpha == 256) *p = bgc;
            else if (alpha > 0) *p = Mix(*p, bgc, alpha);
          }
        }
      }
    }
    std::copy(line.begin(), line.end(), dst + static_cast<size_t>(y) * pitch_px);
  }
}

void TextScreen::DumpText(std::FILE* out) const {
  int last = rows_ - 1;
  while (last > 0 && RowText(last).empty()) --last;
  std::fputc('\n', out);
  for (int y = 0; y <= last; ++y) std::fprintf(out, "%s\n", RowText(y).c_str());
  std::fflush(out);
}

}  // namespace dps3
