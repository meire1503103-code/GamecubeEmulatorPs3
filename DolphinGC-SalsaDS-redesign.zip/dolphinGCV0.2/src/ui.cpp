#include "ui.h"

#include <cstdio>
#include <cstdlib>

#include "demos.h"
#include "input.h"
#include "strutil.h"

namespace dps3 {
namespace {
constexpr unsigned kPollMs = 16;  // ~60 Hz: o app dorme entre leituras do controle (nao gasta CPU a toa)

// Quebra linhas maiores que `width` (de preferencia em espaco); a continuacao ganha 2 espacos de recuo.
std::vector<std::string> WrapLines(const std::vector<std::string>& in, size_t width) {
  std::vector<std::string> out;
  for (const std::string& line : in) {
    std::string rest = line;
    bool first = true;
    for (;;) {
      const size_t room = first ? width : (width > 2 ? width - 2 : 1);
      if (rest.size() <= room) { out.push_back((first ? "" : "  ") + rest); break; }
      size_t cut = rest.rfind(' ', room);
      if (cut == std::string::npos || cut < room / 2) cut = room;   // sem espaco bom: corta seco
      out.push_back((first ? "" : "  ") + rest.substr(0, cut));
      rest = rest.substr(cut);
      while (!rest.empty() && rest[0] == ' ') rest.erase(0, 1);
      first = false;
      if (rest.empty()) break;
    }
  }
  return out;
}
}

bool Ui::Init() {
  video_ok_ = PlatformInit(screen_);
  PadInit();
  return true;
}

void Ui::Shutdown() {
  PadShutdown();
  PlatformShutdown();
}

bool Ui::Wait(UiEvent& ev) {
  ev = UiEvent();
#ifdef DOLPHINPS3_PLATFORM_PS3
  for (;;) {
    if (!PlatformPump()) { exit_ = true; return false; }
    Ps3PadState cur;
    const bool got = PadPoll(cur);
    if (got) last_pad_ = cur;
    if (got != pad_connected_) {          // controle ligado/desligado: redesenha sem o aviso
      pad_connected_ = got;
      return true;
    }
    if (!pad_connected_)
      screen_.PutCentered(screen_.rows() - 3, "Nenhum controle detectado: ligue o DualShock 3 (botao PS)", kRed);
    PlatformPresent(screen_);
    ev.nav = rep_.Update(last_pad_, clock_ms_);
    if (ev.nav != MenuInput::None) return true;
    PlatformSleepMs(kPollMs);
    clock_ms_ += kPollMs;
  }
#else
  PlatformPresent(screen_);
  std::printf("> ");
  std::fflush(stdout);
  char line[256];
  if (!std::fgets(line, sizeof line, stdin)) { exit_ = true; return false; }
  std::string t = line;
  while (!t.empty() && (t.back() == '\n' || t.back() == '\r')) t.pop_back();
  ev.text = t;
  if (t.empty()) ev.nav = MenuInput::Confirm;
  else if (t[0] == 'w') ev.nav = MenuInput::Up;
  else if (t[0] == 's') ev.nav = MenuInput::Down;
  else if (t[0] == 'a') ev.nav = MenuInput::Left;
  else if (t[0] == 'd') ev.nav = MenuInput::Right;
  else if (t[0] == 'r' || t[0] == 'R') ev.nav = MenuInput::Refresh;
  else if (t[0] == 'b') ev.nav = MenuInput::Back;
  else if (t[0] >= '0' && t[0] <= '9') ev.direct = std::atoi(t.c_str());
  return true;
#endif
}

bool Ui::CancelRequested() {
  if (!PlatformPump()) { exit_ = true; return true; }
  Ps3PadState cur;
  if (!PadPoll(cur)) return false;
  const bool pressed = cur.circle && !last_pad_.circle;
  last_pad_ = cur;
  rep_.Reset(cur);  // o que foi segurado aqui nao pode virar "Voltar" na tela seguinte
  return pressed;
}

void Ui::ShowLines(const std::string& title, const std::vector<std::string>& raw_lines,
                   const std::string& footer) {
  const std::vector<std::string> lines = WrapLines(raw_lines, static_cast<size_t>(screen_.cols() - 4));
  int top = 0;
  for (;;) {
    const int body = screen_.rows() - 5;  // titulo + linha + (3 linhas do rodape/margem)
    const int n = static_cast<int>(lines.size());
    const int max_top = n > body ? n - body : 0;
    if (top > max_top) top = max_top;
    if (top < 0) top = 0;

    screen_.Clear();
    screen_.PutCentered(0, title, kCyan);
    screen_.HLine(1);
    for (int i = 0; i < body && top + i < n; ++i) screen_.Put(1, 2 + i, lines[top + i]);
    if (top > 0) screen_.Put(screen_.cols() - 3, 2, "^", kGray);
    if (top < max_top) screen_.Put(screen_.cols() - 3, 1 + body, "v", kGray);
    screen_.HLine(screen_.rows() - 2);
    char pos[48];
    std::snprintf(pos, sizeof pos, "  [%d-%d de %d]", n ? top + 1 : 0, top + body < n ? top + body : n, n);
    screen_.PutCentered(screen_.rows() - 1, footer + (n > body ? pos : ""), kGray);

    UiEvent ev;
    if (!Wait(ev)) return;
    switch (ev.nav) {
      case MenuInput::Up: --top; break;
      case MenuInput::Down: ++top; break;
      case MenuInput::Left: top -= body; break;
      case MenuInput::Right: top += body; break;
      case MenuInput::CategoryPrev: top -= body; break;
      case MenuInput::CategoryNext: top += body; break;
      case MenuInput::Refresh: break;
      case MenuInput::Back:
      case MenuInput::Confirm: return;
      case MenuInput::None: break;
    }
  }
}

void Ui::RunHelloScreen() {
  std::string out, err;
  uint64_t steps = 0;
  std::vector<std::string> lines;
  lines.push_back("Programa PowerPC (montado em memoria) rodando na CPU emulada:");
  lines.push_back("");
  if (!RunHelloWorld(out, &steps, err)) {
    lines.push_back("ERRO: " + err);
  } else {
    lines.push_back("--- saida do programa ---");
    size_t pos = 0;
    while (pos < out.size()) {
      size_t nl = out.find('\n', pos);
      if (nl == std::string::npos) nl = out.size();
      lines.push_back("  " + out.substr(pos, nl - pos));
      pos = nl + 1;
    }
    lines.push_back("-------------------------");
    lines.push_back("");
    lines.push_back("Instrucoes PowerPC executadas: " + NumStrU(steps));
    lines.push_back("Cada letra foi um 'stb' do guest na porta de console 0xCC00FF00.");
  }
  ShowLines("HELLO WORLD", lines, "Bolinha: voltar");
}

void Ui::RunCalculatorScreen() {
  static const char kKeys[4][4] = {{'7', '8', '9', '/'}, {'4', '5', '6', '*'},
                                   {'1', '2', '3', '-'}, {'C', '0', '=', '+'}};
  Calculator calc;
  int cx = 0, cy = 0;
  for (;;) {
    TextScreen& s = screen_;
    s.Clear();
    s.PutCentered(0, "CALCULADORA", kCyan);
    s.HLine(1);
    if (!calc.ok()) {
      s.PutCentered(4, "Erro ao iniciar a CPU emulada:", kRed);
      s.PutCentered(5, calc.init_error(), kRed);
    } else {
      const int bw = 30, bx = (s.cols() - bw) / 2;
      const std::string expr = calc.Expression(), disp = calc.Display();
      s.Put(bx, 3, std::string(static_cast<size_t>(bw), ' '), kWhite, kGray);
      s.Put(bx + bw - 1 - static_cast<int>(expr.size()), 3, expr, calc.error().empty() ? kWhite : kRed, kGray);
      s.Put(bx, 4, std::string(static_cast<size_t>(bw), ' '), kBlack, kWhite);
      s.Put(bx + bw - 1 - static_cast<int>(disp.size()), 4, disp, calc.error().empty() ? kBlack : kRed, kWhite);
      const int kx = (s.cols() - 4 * 8 + 1) / 2;
      for (int r = 0; r < 4; ++r)
        for (int c = 0; c < 4; ++c) {
          const bool sel = r == cy && c == cx;
          const std::string key = std::string("[ ") + kKeys[r][c] + " ]";
          s.Put(kx + c * 8, 6 + r * 2, key, sel ? kYellow : kWhite, sel ? kBlue : kBlack);
        }
      char info[96];
      std::snprintf(info, sizeof info, "Contas feitas pela CPU PowerPC emulada: %u (%llu instrucoes)",
                    calc.guest_ops(), static_cast<unsigned long long>(calc.guest_steps()));
      s.PutCentered(15 < s.rows() - 3 ? 15 : s.rows() - 3, info, kGreen);
    }
    s.HLine(s.rows() - 2);
    s.PutCentered(s.rows() - 1, "D-Pad: mover   X: apertar tecla   Bolinha: voltar   (PC: digite a conta)", kGray);

    UiEvent ev;
    if (!Wait(ev)) return;
    switch (ev.nav) {
      case MenuInput::Up: cy = (cy + 3) % 4; break;
      case MenuInput::Down: cy = (cy + 1) % 4; break;
      case MenuInput::Left: cx = (cx + 3) % 4; break;
      case MenuInput::Right: cx = (cx + 1) % 4; break;
      case MenuInput::CategoryPrev:
      case MenuInput::CategoryNext:
      case MenuInput::Refresh: break;
      case MenuInput::Confirm:
        if (ev.text.empty()) calc.Press(kKeys[cy][cx]); else calc.Press('=');
        break;
      case MenuInput::Back: return;
      case MenuInput::None: break;
    }
    // PC: cada caractere digitado e uma tecla ("12+30=" faz a conta inteira).
    for (size_t i = 0; i < ev.text.size(); ++i) {
      const char ch = ev.text[i];
      if ((ch >= '0' && ch <= '9') || ch == '+' || ch == '-' || ch == '*' || ch == '/' ||
          ch == '=' || ch == 'c' || ch == 'C' || ch == 'B')
        calc.Press(ch);
    }
  }
}

void Ui::RunControlsScreen(ControllerProfile& profile) {
  for (;;) {
    RenderControlsScreen(profile, screen_);
    UiEvent ev;
    if (!Wait(ev)) return;
    if (ev.nav == MenuInput::Back) return;
    if (ev.nav == MenuInput::Right) profile = NextProfile(profile);
    if (ev.nav == MenuInput::Left) profile = PrevProfile(profile);
  }
}

}  // namespace dps3
