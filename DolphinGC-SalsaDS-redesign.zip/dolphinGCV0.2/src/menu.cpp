#include "menu.h"

#include <algorithm>
#include <cstdio>
#include <string>
#include <vector>

namespace dps3 {

bool MenuSystem::Init() {
  items_.clear();
  selected_ = 0;
  has_back_ = false;
  title_ = "DOLPHIN GAMECUBE";
  status_.clear();
  AddItem("Nenhum jogo encontrado", MENU_ACTION_EMPTY,
          "Copie arquivos ISO/GCM de GameCube para a pasta DolphinGC.\nUse Triangulo para atualizar a biblioteca.",
          "JOGOS", "ATUALIZAR");
  AddItem("Atualizar biblioteca", MENU_ACTION_REFRESH,
          "Procura novamente os arquivos ISO/GCM na pasta de jogos.", "JOGOS", "ATUALIZAR");
  AddItem("Abrir arquivo ISO/GCM", MENU_ACTION_LOAD_ISO,
          "Escolha manualmente um disco de GameCube.", "FERRAMENTAS", "ABRIR ARQUIVO");
  AddItem("Arquivos do disco (FST)", MENU_ACTION_LIST_FST,
          "Mostra pastas e arquivos do disco selecionado.", "FERRAMENTAS", "VER ARQUIVOS");
  AddItem("Hello World", MENU_ACTION_HELLO,
          "Demo simples executada pela CPU PowerPC emulada.", "FERRAMENTAS", "EXECUTAR DEMO");
  AddItem("Calculadora", MENU_ACTION_CALC,
          "Demonstra operacoes executadas pela CPU emulada.", "FERRAMENTAS", "ABRIR");
  AddItem("Configuracoes gerais", MENU_ACTION_SETTINGS_GENERAL,
          "Pasta de jogos, formatos de disco e atualizacao da biblioteca.", "CONFIGURACAO", "VER");
  AddItem("Graficos", MENU_ACTION_SETTINGS_GRAPHICS,
          "Estado atual do renderer e opcoes disponiveis nesta versao.", "CONFIGURACAO", "VER");
  AddItem("Controles", MENU_ACTION_CONTROLS,
          "Mapeamento do DualShock 3 para o controle de GameCube.", "CONFIGURACAO", "VER CONTROLES");
  AddItem("Desempenho", MENU_ACTION_SETTINGS_PERFORMANCE,
          "Estado do nucleo e recursos de desempenho disponiveis.", "CONFIGURACAO", "VER");
  AddItem("Sobre o DolphinGC", MENU_ACTION_INFO,
          "Versao, estado do projeto e informacoes da biblioteca.", "SOBRE", "INFORMACOES");
  AddItem("Sair", MENU_ACTION_EXIT, "Fecha o DolphinGC e volta ao XMB.", "SOBRE", "SAIR");
  return true;
}

void MenuSystem::SetItems(const std::vector<MenuItem>& items, const std::string& title) {
  items_ = items;
  title_ = title;
  selected_ = 0;
  has_back_ = false;
}

void MenuSystem::AddItem(const std::string& label, int action_id, const std::string& info,
                         const std::string& group, const std::string& cta) {
  items_.push_back(MenuItem{label, action_id, info, group, std::string(), cta, 0});
}

void MenuSystem::SetItemState(int action_id, const std::string& badge, Color color, const std::string& cta) {
  for (MenuItem& it : items_) {
    if (it.action_id != action_id) continue;
    it.badge = badge;
    it.badge_color = static_cast<uint8_t>(color);
    if (!cta.empty()) it.cta = cta;
  }
}

bool MenuSystem::SelectAction(int action_id) {
  for (size_t i = 0; i < items_.size(); ++i)
    if (items_[i].action_id == action_id) { selected_ = static_cast<int>(i); return true; }
  return false;
}

void MenuSystem::RenderConsole(std::FILE* out) const {
  std::fprintf(out, "\n========================================\n");
  std::fprintf(out, "  %s\n", title_.c_str());
  std::fprintf(out, "========================================\n");
  for (size_t i = 0; i < items_.size(); ++i) {
    std::fprintf(out, " %s[%d] %s\n", static_cast<int>(i) == selected_ ? "> " : "  ",
                 static_cast<int>(i), items_[i].label.c_str());
  }
  std::fprintf(out, "========================================\n");
  std::fflush(out);
}

std::string MenuSystem::DefaultFooter() {
  return "D-Pad/Analogico: mover   X: abrir   O: voltar   L1/R1: categoria";
}

void MenuSystem::RenderScreenPlain(TextScreen& screen, const std::string& footer) const {
  screen.Clear();
  screen.PutCentered(0, title_, kCyan);
  screen.HLine(1);
  const int n = static_cast<int>(items_.size());
  const int top = 3, bottom = screen.rows() - 3;
  const int visible = bottom - top + 1 > 1 ? bottom - top + 1 : 1;
  int first = 0;
  if (n > visible) {
    first = selected_ - visible / 2;
    if (first < 0) first = 0;
    if (first > n - visible) first = n - visible;
  }
  for (int row = 0; row < visible && first + row < n; ++row) {
    const int i = first + row, y = top + row;
    const bool sel = i == selected_;
    if (sel) screen.FillRow(y, kBlue);
    char head[32];
    std::snprintf(head, sizeof head, " %s[%d] ", sel ? "> " : "  ", i);
    const std::string tag = items_[i].badge.empty() ? std::string() : "  [" + items_[i].badge + "]";
    screen.Put(1, y, std::string(head) + items_[i].label + tag, sel ? kYellow : kWhite, sel ? kBlue : kBlack);
  }
  if (first > 0) screen.Put(screen.cols() - 3, top, "^", kGray);
  if (first + visible < n) screen.Put(screen.cols() - 3, bottom, "v", kGray);
  screen.HLine(screen.rows() - 2);
  screen.PutCentered(screen.rows() - 1, footer, kGray);
}

namespace {

std::string Fit(const std::string& s, int w) {
  if (w <= 0) return std::string();
  if (static_cast<int>(s.size()) <= w) return s;
  if (w <= 2) return s.substr(0, static_cast<size_t>(w));
  return s.substr(0, static_cast<size_t>(w - 2)) + "..";
}

void Wrap(const std::string& text, int w, std::vector<std::string>& out) {
  size_t i = 0;
  while (i <= text.size()) {
    size_t nl = text.find('\n', i);
    if (nl == std::string::npos) nl = text.size();
    const std::string para = text.substr(i, nl - i);
    std::string cur, word;
    for (size_t k = 0; k <= para.size(); ++k) {
      if (k == para.size() || para[k] == ' ') {
        if (!word.empty()) {
          if (!cur.empty() && static_cast<int>(cur.size() + 1 + word.size()) > w) {
            out.push_back(cur);
            cur.clear();
          }
          cur += (cur.empty() ? "" : " ") + word;
          word.clear();
        }
      } else {
        word.push_back(para[k]);
      }
    }
    out.push_back(cur);
    i = nl + 1;
  }
}

std::vector<std::string> Categories(const std::vector<MenuItem>& items) {
  std::vector<std::string> out;
  for (const MenuItem& item : items) {
    if (item.group.empty()) continue;
    if (std::find(out.begin(), out.end(), item.group) == out.end()) out.push_back(item.group);
  }
  return out;
}

std::vector<int> GroupItems(const std::vector<MenuItem>& items, const std::string& group) {
  std::vector<int> out;
  for (size_t i = 0; i < items.size(); ++i)
    if (items[i].group == group) out.push_back(static_cast<int>(i));
  return out;
}

std::string InfoField(const std::string& info, const std::string& field) {
  const std::string key = field + "|";
  const size_t pos = info.find(key);
  if (pos == std::string::npos) return std::string();
  const size_t begin = pos + key.size();
  const size_t end = info.find('\n', begin);
  return info.substr(begin, end == std::string::npos ? end : end - begin);
}

unsigned Hash(const std::string& s) {
  unsigned h = 2166136261u;
  for (unsigned char c : s) h = (h ^ c) * 16777619u;
  return h;
}

std::string Mark(const std::string& title) {
  std::string out;
  for (size_t i = 0; i < title.size() && out.size() < 3; ++i)
    if ((i == 0 || title[i - 1] == ' ') && title[i] != ' ') out.push_back(title[i]);
  if (out.empty()) out = title.substr(0, std::min<size_t>(3, title.size()));
  return out;
}

Color CoverAccent(const std::string& title) {
  const Color palette[] = {kIce, kViolet, kGreen, kYellow, kCyan, kMagenta};
  return palette[Hash(title) % (sizeof(palette) / sizeof(palette[0]))];
}

// Capa ilustrativa sem decoder: cada ISO recebe uma arte abstrata propria, calculada uma vez por desenho.
void DrawCover(TextScreen& screen, const MenuItem& item, int x, int y, int w, int h,
               bool selected, Color focus_color) {
  if (w < 8 || h < 3) return;
  const unsigned seed = Hash(item.label);
  const Color accent = CoverAccent(item.label);
  for (int row = 0; row < h; ++row) {
    for (int col = 0; col < w; ++col) {
      const bool edge = row == 0 || row == h - 1 || col == 0 || col == w - 1;
      const int offset = static_cast<int>(seed % static_cast<unsigned>(w));
      const int band = (col - offset - row * 3 + w * 2) % w;
      Color bg = kNavy;
      if (row > 0 && row < h - 1 && band < w / 3) bg = accent;
      else if (row > 0 && row < h - 1 && band > w * 2 / 3) bg = (seed & 1u) ? kBlue : kPurple;
      if (edge) bg = selected ? focus_color : kPanel;
      screen.Put(x + col, y + row, " ", kWhite, bg);
    }
  }
  screen.Put(x + 1, y, "GC", kIce, kNavy);
  const std::string mark = Mark(item.label);
  screen.Put(x + std::max(1, (w - static_cast<int>(mark.size())) / 2), y + h / 2,
             mark, kWhite, accent);
}

}  // namespace

void MenuSystem::RenderScreen(TextScreen& screen, const std::string& footer) const {
  if (!screen.xmb_background()) { RenderScreenPlain(screen, footer); return; }
  screen.Clear();
  screen.set_scenic(true);
  const int cols = screen.cols(), rows = screen.rows();
  if (cols < 58 || rows < 15) {
    RenderScreenPlain(screen, footer);
    screen.set_scenic(true);
    return;
  }

  const std::string active = selected_ >= 0 && selected_ < static_cast<int>(items_.size())
                                 ? items_[selected_].group : std::string();
  const Color focus_colors[5] = {kPanel, kFocus0, kFocus1, kFocus2, kBar};
  const Color focus_color = focus_colors[focus_frame_];
  const std::vector<std::string> categories = Categories(items_);
  screen.FillRow(0, kShade);
  screen.FillRow(1, kShade);
  screen.FillRow(2, kShade);
  screen.Put(2, 0, "DOLPHIN GC", kWhite, kShade);
  screen.Put(14, 0, "GAMECUBE", kIce, kShade);
  screen.Put(cols - 7, 0, "V0.2", kGray, kShade);
  screen.Put(2, 1, Fit(title_, cols - 4), kWhite, kShade);
  screen.Put(2, 2, Fit(status_.empty() ? "BIBLIOTECA DE JOGOS" : status_, cols - 4),
             status_.empty() ? kGray : status_color_, kShade);

  // Abas simples, operadas pelos ombros do DualShock 3.
  int tab_x = 2;
  for (const std::string& category : categories) {
    const std::string tab = " " + category + " ";
    const bool sel = category == active;
    screen.Put(tab_x, 4, tab, sel ? kBlack : kGray, sel ? kGreen : kBlack);
    tab_x += static_cast<int>(tab.size()) + 2;
  }
  if (tab_x < cols - 10) screen.Put(cols - 10, 4, "L1 / R1", kGray);

  const int top = 6;
  const int bottom = rows - 4;
  if (active == "JOGOS") {
    const std::vector<int> indices = GroupItems(items_, active);
    if (indices.empty() || items_[indices[0]].action_id == MENU_ACTION_EMPTY) {
      screen.PutCentered(top + 1, "NENHUM JOGO ENCONTRADO", kWhite);
      screen.PutCentered(top + 3, "Copie arquivos ISO/GCM para a pasta DolphinGC", kGray);
      screen.PutCentered(top + 4, "Pressione X ou Triangulo para atualizar a biblioteca.", kGreen);
    } else {
      const int available_h = bottom - top + 1;
      const int art_h = std::max(6, std::min(10, available_h - 5));
      const int tile_h = art_h + 2;
      const int grid_cols = 4;
      int grid_rows = available_h / tile_h;
      if (grid_rows < 1) grid_rows = 1;
      if (grid_rows > 3) grid_rows = 3;
      const int page_size = grid_cols * grid_rows;
      int local_selected = 0;
      for (size_t i = 0; i < indices.size(); ++i)
        if (indices[i] == selected_) { local_selected = static_cast<int>(i); break; }
      const int first = (local_selected / page_size) * page_size;
      const int card_w = std::max(12, (cols - 4 - (grid_cols - 1) * 2) / grid_cols);
      for (int slot = 0; slot < page_size && first + slot < static_cast<int>(indices.size()); ++slot) {
        const int item_index = indices[first + slot];
        const MenuItem& item = items_[item_index];
        const int gx = slot % grid_cols, gy = slot / grid_cols;
        const int x = 2 + gx * (card_w + 2);
        const int y = top + gy * tile_h;
        const bool sel = item_index == selected_;
        if (item.action_id == MENU_ACTION_EMPTY) continue;
        if (item.action_id == MENU_ACTION_REFRESH) {
          for (int r = 0; r < art_h; ++r)
            for (int c = 0; c < card_w; ++c)
          screen.Put(x + c, y + r, " ", kWhite, sel ? focus_color : kPanel);
          const std::string refresh = Fit("ATUALIZAR", card_w);
          screen.Put(x + (card_w - static_cast<int>(refresh.size())) / 2, y + 1, refresh,
                     sel ? kWhite : kIce, sel ? focus_color : kPanel);
          screen.Put(x + 1, y + art_h, Fit(item.label, card_w - 2), sel ? kWhite : kGray);
          continue;
        }
        DrawCover(screen, item, x, y, card_w, art_h, sel, focus_color);
        screen.Put(x, y + art_h, Fit(item.label, card_w), sel ? kWhite : kGray,
                   sel ? focus_color : kBlack);
      }
      if (selected_ >= 0 && selected_ < static_cast<int>(items_.size())) {
        const MenuItem& selected = items_[selected_];
        std::string detail = selected.action_id >= MENU_ACTION_OPEN_GAME_BASE
                                 ? "ID " + InfoField(selected.info, "ID") + "   " + selected.label
                                 : selected.label;
        screen.Put(2, rows - 4, Fit(detail, cols - 4), kIce, kBlack);
      }
      if (static_cast<int>(indices.size()) > page_size) {
        char page[32];
        std::snprintf(page, sizeof page, "%d / %d", first / page_size + 1,
                      (static_cast<int>(indices.size()) + page_size - 1) / page_size);
        screen.Put(cols - 8, rows - 4, page, kGray);
      }
    }
  } else {
    const std::vector<int> indices = GroupItems(items_, active);
    const int list_x = 2;
    const int list_w = std::max(20, cols * 38 / 100);
    const int detail_x = list_x + list_w + 2;
    const int detail_w = cols - detail_x - 2;
    const int visible = std::max(1, bottom - top + 1);
    int local_selected = 0;
    for (size_t i = 0; i < indices.size(); ++i)
      if (indices[i] == selected_) { local_selected = static_cast<int>(i); break; }
    int first = local_selected - visible / 2;
    if (first < 0) first = 0;
    if (first > static_cast<int>(indices.size()) - visible)
      first = std::max(0, static_cast<int>(indices.size()) - visible);
    for (int y = top; y <= bottom; ++y)
      for (int x = list_x; x < list_x + list_w; ++x) screen.Put(x, y, " ", kWhite, kPanel);
    for (int row = 0; row < visible && first + row < static_cast<int>(indices.size()); ++row) {
      const int item_index = indices[first + row];
      const MenuItem& item = items_[item_index];
      const bool sel = item_index == selected_;
      const int y = top + row;
      if (sel) for (int x = list_x; x < list_x + list_w; ++x) screen.Put(x, y, " ", kWhite, focus_color);
      screen.Put(list_x + 1, y, sel ? ">" : " ", sel ? kYellow : kGray,
                 sel ? focus_color : kPanel);
      screen.Put(list_x + 3, y, Fit(item.label, list_w - 5), sel ? kWhite : kGray,
                 sel ? focus_color : kPanel);
    }
    if (!indices.empty() && detail_w > 12) {
      const MenuItem& item = items_[selected_];
      for (int y = top; y <= bottom; ++y)
        for (int x = detail_x; x < cols - 1; ++x) screen.Put(x, y, " ", kWhite, kPanel);
      const int w = detail_w - 3;
      screen.Put(detail_x + 1, top, "SELECIONADO", kIce, kPanel);
      screen.Put(detail_x + 1, top + 2, Fit(item.label, w), kWhite, kPanel);
      if (!item.badge.empty())
        screen.Put(detail_x + 1, top + 4, " " + Fit(item.badge, w - 2) + " ", kBlack,
                   item.badge_color ? static_cast<Color>(item.badge_color) : kGreen);
      std::vector<std::string> lines;
      Wrap(item.info, w, lines);
      int y = top + (item.badge.empty() ? 4 : 6);
      for (const std::string& line : lines) {
        if (y >= bottom - 2) break;
        screen.Put(detail_x + 1, y++, Fit(line, w), kGray, kPanel);
      }
      if (bottom > top + 2) {
        const std::string action = "[X] " + (item.cta.empty() ? std::string("ABRIR") : item.cta);
        screen.Put(detail_x + 1, bottom - 1, Fit(action, w), kGreen, kPanel);
      }
    }
  }

  screen.FillRow(rows - 2, kShade);
  screen.FillRow(rows - 1, kShade);
  screen.PutCentered(rows - 2, Fit("X ABRIR    O VOLTAR    L1/R1 CATEGORIAS    TRIANGULO ATUALIZAR", cols - 2),
                     kWhite, kShade);
  screen.PutCentered(rows - 1, Fit(footer, cols - 2), kGray, kShade);
}

int MenuSystem::Handle(MenuInput in) {
  if (items_.empty()) return in == MenuInput::Refresh ? MENU_ACTION_REFRESH : -1;
  const std::string group = items_[selected_].group;
  if (group != "JOGOS" && in == MenuInput::Left) in = MenuInput::CategoryPrev;
  if (group != "JOGOS" && in == MenuInput::Right) in = MenuInput::CategoryNext;
  const std::vector<int> indices = GroupItems(items_, group);
  int local = 0;
  for (size_t i = 0; i < indices.size(); ++i)
    if (indices[i] == selected_) { local = static_cast<int>(i); break; }
  switch (in) {
    case MenuInput::Up:
    case MenuInput::Down:
    case MenuInput::Left:
    case MenuInput::Right: {
      if (indices.empty()) return -1;
      const int n = static_cast<int>(indices.size());
      if (group == "JOGOS") {
        const bool empty_library = items_[indices[0]].action_id == MENU_ACTION_EMPTY;
        if (empty_library && (in == MenuInput::Up || in == MenuInput::Down)) {
          const int step = in == MenuInput::Up ? -1 : 1;
          local = (local + step + n) % n;
          selected_ = indices[local];
          return -1;
        }
        if (in == MenuInput::Left || in == MenuInput::Right) {
          const int step = in == MenuInput::Left ? -1 : 1;
          local = (local + step + n) % n;
        } else {
          const int row = local / 4, col = local % 4;
          const int last_row = (n - 1) / 4;
          if (in == MenuInput::Up) {
            if (row > 0) local -= 4;
            else {
              local = last_row * 4 + col;
              if (local >= n) local = n - 1;
            }
          } else {
            if (row < last_row) {
              local += 4;
              if (local >= n) local = n - 1;
            } else {
              local = col < n ? col : n - 1;
            }
          }
        }
      } else {
        if (in == MenuInput::Up) local = (local + n - 1) % n;
        if (in == MenuInput::Down) local = (local + 1) % n;
      }
      selected_ = indices[local];
      return -1;
    }
    case MenuInput::CategoryPrev:
    case MenuInput::CategoryNext: {
      const std::vector<std::string> categories = Categories(items_);
      if (categories.size() < 2) return -1;
      int category = 0;
      for (size_t i = 0; i < categories.size(); ++i)
        if (categories[i] == group) { category = static_cast<int>(i); break; }
      const int delta = in == MenuInput::CategoryNext ? 1 : -1;
      category = (category + delta + static_cast<int>(categories.size())) % static_cast<int>(categories.size());
      const std::vector<int> next = GroupItems(items_, categories[category]);
      if (!next.empty()) selected_ = next[0];
      return -1;
    }
    case MenuInput::Refresh:
      return MENU_ACTION_REFRESH;
    case MenuInput::Confirm:
      return SelectOption(selected_);
    case MenuInput::Back:
      if (has_back_) return back_action_;
      if (group != "JOGOS") {
        const std::vector<int> games = GroupItems(items_, "JOGOS");
        if (!games.empty()) selected_ = games[0];
      }
      return -1;
    case MenuInput::None:
      break;
  }
  return -1;
}

int MenuSystem::SelectOption(int choice) const {
  if (choice < 0 || choice >= static_cast<int>(items_.size())) return -1;
  return items_[choice].action_id;
}

MenuInput MenuInputFromPad(const Ps3PadState& prev, const Ps3PadState& cur) {
  const bool prev_up = prev.dpad_up || prev.left_stick_y <= 64;
  const bool prev_down = prev.dpad_down || prev.left_stick_y >= 192;
  const bool cur_up = cur.dpad_up || cur.left_stick_y <= 64;
  const bool cur_down = cur.dpad_down || cur.left_stick_y >= 192;
  const bool prev_left = prev.dpad_left || prev.left_stick_x <= 64;
  const bool prev_right = prev.dpad_right || prev.left_stick_x >= 192;
  const bool cur_left = cur.dpad_left || cur.left_stick_x <= 64;
  const bool cur_right = cur.dpad_right || cur.left_stick_x >= 192;

  if (cur_up && !prev_up) return MenuInput::Up;
  if (cur_down && !prev_down) return MenuInput::Down;
  if (cur_left && !prev_left) return MenuInput::Left;
  if (cur_right && !prev_right) return MenuInput::Right;
  if ((cur.cross && !prev.cross) || (cur.start && !prev.start)) return MenuInput::Confirm;
  if (cur.circle && !prev.circle) return MenuInput::Back;
  if (cur.l1 && !prev.l1) return MenuInput::CategoryPrev;
  if (cur.r1 && !prev.r1) return MenuInput::CategoryNext;
  if (cur.triangle && !prev.triangle) return MenuInput::Refresh;
  return MenuInput::None;
}

MenuInput PadRepeater::Update(const Ps3PadState& cur, uint32_t now_ms) {
  const Ps3PadState prev = prev_;
  prev_ = cur;
  const MenuInput edge = MenuInputFromPad(prev, cur);
  const bool directional = edge == MenuInput::Up || edge == MenuInput::Down ||
                           edge == MenuInput::Left || edge == MenuInput::Right;
  if (edge != MenuInput::None) {
    held_ = directional ? edge : MenuInput::None;
    next_ms_ = now_ms + delay_;
    return edge;
  }
  if (held_ == MenuInput::None) return MenuInput::None;
  const Ps3PadState neutral;
  Ps3PadState probe = cur;
  if (MenuInputFromPad(neutral, probe) != held_) { held_ = MenuInput::None; return MenuInput::None; }
  if (now_ms >= next_ms_) { next_ms_ = now_ms + rate_; return held_; }
  return MenuInput::None;
}

ControllerProfile NextProfile(ControllerProfile) { return ControllerProfile::GameCube; }
ControllerProfile PrevProfile(ControllerProfile) { return ControllerProfile::GameCube; }

void RenderControlsScreen(ControllerProfile p, std::FILE* out) {
  std::fprintf(out, "\n========================================\n");
  std::fprintf(out, "  CONTROLES - perfil: %s\n", ProfileName(p));
  std::fprintf(out, "========================================\n");
  std::fputs(DescribeMapping(p).c_str(), out);
  std::fprintf(out, "========================================\n");
  std::fprintf(out, "  Bolinha: voltar\n");
  std::fflush(out);
}

void RenderControlsScreen(ControllerProfile p, TextScreen& screen) {
  screen.Clear();
  screen.PutCentered(0, std::string("CONTROLES - perfil: ") + ProfileName(p), kCyan);
  screen.HLine(1);
  const std::string text = DescribeMapping(p);
  int y = 3;
  size_t pos = 0;
  while (pos < text.size() && y < screen.rows() - 3) {
    size_t nl = text.find('\n', pos);
    if (nl == std::string::npos) nl = text.size();
    screen.Put(2, y++, text.substr(pos, nl - pos));
    pos = nl + 1;
  }
  screen.HLine(screen.rows() - 2);
  screen.PutCentered(screen.rows() - 1, "O: voltar", kGray);
}

} // namespace dps3
