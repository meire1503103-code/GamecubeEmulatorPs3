#include "check.h"
#include "menu.h"

#include <cstdio>
#include <string>
#include <vector>

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;

std::vector<MenuItem> SampleItems() {
  return {
      {"Jogo GC 01", MENU_ACTION_OPEN_GAME_BASE, "ID|GABC01\nArquivo|jogo01.iso", "JOGOS", "", "INICIAR JOGO", static_cast<uint8_t>(kGreen)},
      {"Jogo GC 02", MENU_ACTION_OPEN_GAME_BASE + 1, "ID|GABC02\nArquivo|jogo02.gcm", "JOGOS", "", "INICIAR JOGO", static_cast<uint8_t>(kGreen)},
      {"Jogo GC 03", MENU_ACTION_OPEN_GAME_BASE + 2, "ID|GABC03\nArquivo|jogo03.iso", "JOGOS", "", "INICIAR JOGO", static_cast<uint8_t>(kGreen)},
      {"Abrir arquivo ISO/GCM", MENU_ACTION_LOAD_ISO, "Selecione um disco manualmente.", "FERRAMENTAS", "", "ABRIR ARQUIVO", 0},
      {"Controles", MENU_ACTION_CONTROLS, "Mapeamento do DualShock 3.", "CONFIGURACAO", "", "VER CONTROLES", 0},
      {"Sobre o DolphinGC", MENU_ACTION_INFO, "Versao e estado do projeto.", "SOBRE", "", "INFORMACOES", 0},
  };
}

void TestNavigation() {
  std::printf("[SIM] menu: biblioteca generica, abas e retorno\n");
  MenuSystem m;
  CHECK(m.Init());
  CHECK(m.items().size() == 12);
  CHECK(m.selected_action() == MENU_ACTION_EMPTY);
  CHECK(m.Handle(MenuInput::Confirm) == MENU_ACTION_EMPTY);
  CHECK(m.Handle(MenuInput::Down) == -1 && m.selected_action() == MENU_ACTION_REFRESH);
  CHECK(m.Handle(MenuInput::Confirm) == MENU_ACTION_REFRESH);
  CHECK(m.Handle(MenuInput::CategoryNext) == -1 && m.selected_action() == MENU_ACTION_LOAD_ISO);
  CHECK(m.Handle(MenuInput::Down) == -1 && m.selected_action() == MENU_ACTION_LIST_FST);
  CHECK(m.Handle(MenuInput::Confirm) == MENU_ACTION_LIST_FST);
  CHECK(m.Handle(MenuInput::Up) == -1 && m.selected_action() == MENU_ACTION_LOAD_ISO);
  CHECK(m.Handle(MenuInput::CategoryNext) == -1 && m.selected_action() == MENU_ACTION_SETTINGS_GENERAL);
  CHECK(m.Handle(MenuInput::Down) == -1 && m.selected_action() == MENU_ACTION_SETTINGS_GRAPHICS);
  CHECK(m.Handle(MenuInput::Down) == -1 && m.selected_action() == MENU_ACTION_CONTROLS);
  CHECK(m.Handle(MenuInput::CategoryNext) == -1 && m.selected_action() == MENU_ACTION_INFO);
  CHECK(m.Handle(MenuInput::Confirm) == MENU_ACTION_INFO);
  CHECK(m.Handle(MenuInput::Back) == -1 && m.selected_action() == MENU_ACTION_EMPTY);
  CHECK(m.Handle(MenuInput::CategoryPrev) == -1 && m.selected_action() == MENU_ACTION_INFO);
  CHECK(m.SelectOption(0) == MENU_ACTION_EMPTY);
  CHECK(m.SelectAction(MENU_ACTION_SETTINGS_PERFORMANCE));
  CHECK(m.selected_action() == MENU_ACTION_SETTINGS_PERFORMANCE);
  CHECK(!m.SelectAction(999));

  m.SetItems({{"a", 10}, {"Voltar", -2}}, "sub");
  m.set_back_action(-2, true);
  CHECK(m.selected() == 0 && m.Handle(MenuInput::Back) == -2);

  MenuSystem empty;
  CHECK(empty.Handle(MenuInput::Down) == -1 && empty.Handle(MenuInput::Confirm) == -1);
  CHECK(empty.Handle(MenuInput::Refresh) == MENU_ACTION_REFRESH);
}

void TestState() {
  std::printf("[SIM] menu: estado de acao e preservacao da selecao\n");
  MenuSystem m;
  m.Init();
  CHECK(m.SelectAction(MENU_ACTION_CALC) && m.selected_action() == MENU_ACTION_CALC);
  CHECK(m.SelectAction(MENU_ACTION_REFRESH) && m.selected() == 1);
  CHECK(m.items()[1].badge.empty() && m.items()[1].cta == "ATUALIZAR");
  m.SetItemState(MENU_ACTION_REFRESH, "PASTA ATUALIZADA", kGreen, "ATUALIZAR");
  CHECK(m.items()[1].badge == "PASTA ATUALIZADA" && m.items()[1].badge_color == kGreen);
  m.SetItemState(MENU_ACTION_REFRESH, "PRONTA", kYellow, "");
  CHECK(m.items()[1].cta == "ATUALIZAR");
}

void TestRenderLibrary() {
  std::printf("[SIM] menu: biblioteca de capas, nome, detalhes e acao\n");
  MenuSystem m;
  m.SetItems(SampleItems(), "BIBLIOTECA DE JOGOS");
  m.SetStatus("3 JOGOS  |  DolphinGC", kIce);
  TextScreen s;
  s.Resize(73, 20);
  s.set_xmb_background(true);
  m.RenderScreen(s);
  CHECK(s.RowText(0).find("DOLPHIN GC") != std::string::npos);
  CHECK(s.RowText(0).find("GAMECUBE") != std::string::npos);
  CHECK(s.RowText(0).find("V0.2") != std::string::npos);
  CHECK(s.RowText(2).find("3 JOGOS") != std::string::npos);
  CHECK(s.RowText(4).find("JOGOS") != std::string::npos);
  CHECK(s.RowText(4).find("FERRAMENTAS") != std::string::npos);
  CHECK(s.RowText(12).find("Jogo GC 01") != std::string::npos);  // titulo abaixo da capa
  CHECK(s.RowText(16).find("ID GABC01") != std::string::npos);           // detalhes da selecao
  CHECK(s.RowText(18).find("X ABRIR") != std::string::npos);
  CHECK(s.RowText(18).find("TRIANGULO ATUALIZAR") != std::string::npos);
  CHECK(s.TakeDirty());
  CHECK(!s.TakeDirty());
  m.SetFocusTransitionFrame(0);
  m.RenderScreen(s);
  CHECK(s.TakeDirty());
  m.SetFocusTransitionFrame(4);
  m.RenderScreen(s);
  CHECK(s.TakeDirty());
  CHECK(m.Handle(MenuInput::Right) == -1 && m.selected_action() == MENU_ACTION_OPEN_GAME_BASE + 1);
  m.RenderScreen(s);
  CHECK(s.RowText(12).find("Jogo GC 02") != std::string::npos);
  CHECK(m.Handle(MenuInput::Refresh) == MENU_ACTION_REFRESH);
  CHECK(m.Handle(MenuInput::CategoryNext) == -1 && m.selected_action() == MENU_ACTION_LOAD_ISO);
  CHECK(m.Handle(MenuInput::Back) == -1 && m.selected_action() == MENU_ACTION_OPEN_GAME_BASE);

  std::vector<MenuItem> many_games;
  for (int i = 0; i < 5; ++i)
    many_games.push_back({"Jogo", MENU_ACTION_OPEN_GAME_BASE + i, "", "JOGOS", "", "INICIAR", 0});
  MenuSystem pages;
  pages.SetItems(many_games, "BIBLIOTECA DE JOGOS");
  CHECK(pages.Handle(MenuInput::Down) == -1 && pages.selected_action() == MENU_ACTION_OPEN_GAME_BASE + 4);
  CHECK(pages.Handle(MenuInput::Up) == -1 && pages.selected_action() == MENU_ACTION_OPEN_GAME_BASE);

  MenuSystem blank;
  blank.SetItems({{"Nenhum jogo encontrado", MENU_ACTION_EMPTY,
                   "Copie arquivos ISO/GCM.", "JOGOS", "", "COPIAR ISO/GCM", 0},
                  {"Atualizar biblioteca", MENU_ACTION_REFRESH, "Atualiza.", "JOGOS", "", "ATUALIZAR", 0}},
                 "BIBLIOTECA DE JOGOS");
  TextScreen empty_screen;
  empty_screen.Resize(73, 20);
  empty_screen.set_xmb_background(true);
  blank.RenderScreen(empty_screen);
  CHECK(empty_screen.RowText(7).find("NENHUM JOGO ENCONTRADO") != std::string::npos);
  CHECK(empty_screen.RowText(10).find("Triangulo") != std::string::npos);
}

void TestRenderSettingsAndPlain() {
  std::printf("[SIM] menu: configuracao por abas e fallback host\n");
  MenuSystem m;
  m.SetItems(SampleItems(), "BIBLIOTECA DE JOGOS");
  m.SelectAction(MENU_ACTION_CONTROLS);
  TextScreen s;
  s.Resize(73, 20);
  s.set_xmb_background(true);
  m.RenderScreen(s);
  CHECK(s.RowText(4).find("CONFIGURACAO") != std::string::npos);
  CHECK(s.RowText(6).find("Controles") != std::string::npos);
  CHECK(s.RowText(10).find("DualShock 3") != std::string::npos);

  MenuSystem plain_menu;
  plain_menu.Init();
  TextScreen plain;
  plain.Resize(73, 20);
  plain_menu.RenderScreen(plain);
  CHECK(plain.RowText(0).find("DOLPHIN GAMECUBE") != std::string::npos);
  CHECK(plain.RowText(3).find("[0] Nenhum jogo encontrado") != std::string::npos);
  CHECK(plain.RowText(4).find("[1] Atualizar biblioteca") != std::string::npos);
}

void TestPadEdges() {
  std::printf("[SIM] menu: D-pad, analogicos e botoes DualShock 3\n");
  Ps3PadState a, b;
  CHECK(MenuInputFromPad(a, b) == MenuInput::None);
  b.dpad_down = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Down);
  CHECK(MenuInputFromPad(b, b) == MenuInput::None);
  b = Ps3PadState(); b.dpad_up = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Up);
  b = Ps3PadState(); b.left_stick_y = 255;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Down);
  b = Ps3PadState(); b.left_stick_y = 0;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Up);
  b = Ps3PadState(); b.cross = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Confirm);
  b = Ps3PadState(); b.start = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Confirm);
  b = Ps3PadState(); b.circle = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Back);
  b = Ps3PadState(); b.l1 = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::CategoryPrev);
  b = Ps3PadState(); b.r1 = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::CategoryNext);
  b = Ps3PadState(); b.triangle = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Refresh);
  b = Ps3PadState(); b.dpad_left = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Left);
  b = Ps3PadState(); b.dpad_right = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Right);
  b = Ps3PadState(); b.left_stick_x = 255;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Right);
  b = Ps3PadState(); b.left_stick_x = 0;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Left);
}

void TestRepeater() {
  std::printf("[SIM] menu: repeticao do direcional, sem repeticao de ombros\n");
  PadRepeater r(400, 100);
  Ps3PadState neutral, down;
  down.dpad_down = true;
  CHECK(r.Update(neutral, 0) == MenuInput::None);
  CHECK(r.Update(down, 10) == MenuInput::Down);
  CHECK(r.Update(down, 200) == MenuInput::None);
  CHECK(r.Update(down, 410) == MenuInput::Down);
  CHECK(r.Update(neutral, 420) == MenuInput::None);
  Ps3PadState l1; l1.l1 = true;
  CHECK(r.Update(l1, 500) == MenuInput::CategoryPrev);
  CHECK(r.Update(l1, 1000) == MenuInput::None);
  r.Reset(down);
  CHECK(r.Update(down, 3000) == MenuInput::None);
}

void TestProfiles() {
  std::printf("[SIM] menu: perfil unico (GameCube)\n");
  const ControllerProfile p = ControllerProfile::GameCube;
  CHECK(NextProfile(p) == ControllerProfile::GameCube);
  CHECK(PrevProfile(p) == ControllerProfile::GameCube);
}

}  // namespace

int main() {
  TestNavigation();
  TestState();
  TestRenderLibrary();
  TestRenderSettingsAndPlain();
  TestPadEdges();
  TestRepeater();
  TestProfiles();
  std::printf("\n[SIM] test_menu: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
