#include "check.h"
#include "menu.h"

#include <cstdio>

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;

void TestNavigation() {
  std::printf("[SIM] menu: navegacao, selecao direta e volta\n");
  MenuSystem m;
  CHECK(m.Init());
  CHECK(m.items().size() == 8);
  CHECK(m.selected() == 0);
  CHECK(m.Handle(MenuInput::Confirm) == MENU_ACTION_LOAD_MKDD);  // 1o item: jogar Mario Kart
  CHECK(m.Handle(MenuInput::Down) == -1 && m.selected() == 1);
  CHECK(m.Handle(MenuInput::Confirm) == MENU_ACTION_LOAD_ISO);   // 2o item: outro jogo
  CHECK(m.Handle(MenuInput::Up) == -1 && m.selected() == 0);
  CHECK(m.Handle(MenuInput::Up) == -1 && m.selected() == 7);     // da a volta para cima
  CHECK(m.Handle(MenuInput::Confirm) == MENU_ACTION_EXIT);
  CHECK(m.Handle(MenuInput::Down) == -1 && m.selected() == 0);   // da a volta para baixo
  for (int i = 0; i < 5; ++i) m.Handle(MenuInput::Down);
  CHECK(m.Handle(MenuInput::Confirm) == MENU_ACTION_CONTROLS);
  CHECK(m.Handle(MenuInput::None) == -1);
  CHECK(m.Handle(MenuInput::Left) == -1 && m.Handle(MenuInput::Right) == -1);  // sem efeito no menu
  CHECK(m.Handle(MenuInput::Back) == -1);                        // menu principal nao tem "voltar"
  CHECK(m.SelectOption(0) == MENU_ACTION_LOAD_MKDD);
  CHECK(m.SelectOption(1) == MENU_ACTION_LOAD_ISO);
  CHECK(m.SelectOption(2) == MENU_ACTION_HELLO);
  CHECK(m.SelectOption(3) == MENU_ACTION_CALC);
  CHECK(m.SelectOption(4) == MENU_ACTION_LIST_FST);
  CHECK(m.SelectOption(6) == MENU_ACTION_INFO);
  CHECK(m.SelectOption(7) == MENU_ACTION_EXIT);
  CHECK(m.SelectOption(8) == -1 && m.SelectOption(-1) == -1);

  m.SetItems({{"a", 10}, {"Voltar", -2}}, "sub");
  m.set_back_action(-2, true);
  CHECK(m.selected() == 0 && m.Handle(MenuInput::Back) == -2);

  MenuSystem empty;
  CHECK(empty.Handle(MenuInput::Down) == -1 && empty.Handle(MenuInput::Confirm) == -1);
}

void TestState() {
  std::printf("[SIM] menu: selos de status, botao de acao e cursor por acao\n");
  MenuSystem m;
  m.Init();
  CHECK(m.SelectAction(MENU_ACTION_HELLO) && m.selected() == 2);
  CHECK(m.SelectAction(MENU_ACTION_LOAD_MKDD) && m.selected() == 0);
  CHECK(!m.SelectAction(999) && m.selected() == 0);              // inexistente: cursor fica
  CHECK(m.items()[0].badge.empty() && m.items()[0].cta == "JOGAR AGORA");
  m.SetItemState(MENU_ACTION_LOAD_MKDD, "PRONTO PARA JOGAR", kGreen, "JOGAR AGORA");
  CHECK(m.items()[0].badge == "PRONTO PARA JOGAR" && m.items()[0].badge_color == kGreen);
  m.SetItemState(MENU_ACTION_LOAD_MKDD, "SEM ISO", kGray, "");   // cta vazio: mantem o anterior
  CHECK(m.items()[0].badge == "SEM ISO" && m.items()[0].cta == "JOGAR AGORA");
}


void TestRenderBeach() {
  std::printf("[SIM] menu: layout praia (cabecalho, grupos, painel de detalhes, botao de acao)\n");
  MenuSystem m;
  m.Init();
  m.SetItemState(MENU_ACTION_LOAD_MKDD, "PRONTO PARA JOGAR", kGreen, "JOGAR AGORA");
  m.SetStatus("Mario Kart pronto! Aperte X para jogar", kGreen);
  TextScreen s;
  s.Resize(73, 20);
  s.set_beach(true);
  m.RenderScreen(s);
  CHECK(s.RowText(0).find("DOLPHIN GC") != std::string::npos);
  CHECK(s.RowText(0).find("V0.2") != std::string::npos);
  CHECK(s.RowText(2).find("Mario Kart pronto") != std::string::npos);      // linha de status
  CHECK(s.RowText(4).find("JOGAR") != std::string::npos);                   // cabecalho de grupo
  CHECK(s.RowText(5).find("> * Jogar Mario Kart Double Dash") != std::string::npos);
  CHECK(s.RowText(5).find("(pasta") == std::string::npos);                  // detalhe fica no painel
  CHECK(s.RowText(5).find("PRONTO PARA JOGAR") != std::string::npos);       // selo no painel
  CHECK(s.RowText(7).find("DEMOS") != std::string::npos);
  CHECK(s.RowText(8).find("Hello World") != std::string::npos);
  CHECK(s.RowText(10).find("SISTEMA") != std::string::npos);
  bool cta = false;
  for (int y = 4; y < 17; ++y) if (s.RowText(y).find("[X]  JOGAR AGORA") != std::string::npos) cta = true;
  CHECK(cta);                                                               // botao de acao
  m.SelectAction(MENU_ACTION_CALC);
  m.RenderScreen(s);
  CHECK(s.RowText(9).find("> . Calculadora") != std::string::npos);
  CHECK(s.RowText(9).find("Calculadora") != std::string::npos);
  cta = false;
  for (int y = 4; y < 17; ++y) if (s.RowText(y).find("[X]  ABRIR CALCULADORA") != std::string::npos) cta = true;
  CHECK(cta);
  CHECK(s.RowText(18).find("Bolinha") != std::string::npos);                // dicas no rodape

  // Tela pequena: o cursor continua visivel e nada estoura.
  TextScreen tiny;
  tiny.Resize(60, 8);
  tiny.set_beach(true);
  MenuSystem m2;
  m2.Init();
  m2.SelectAction(MENU_ACTION_EXIT);
  m2.RenderScreen(tiny);
  bool found = false;
  for (int y = 0; y < tiny.rows(); ++y)
    if (tiny.RowText(y).find("> . Sair") != std::string::npos) found = true;
  CHECK(found);

  TextScreen plain;                                                         // sem praia: layout simples
  plain.Resize(73, 20);
  m.RenderScreen(plain);
  CHECK(plain.RowText(3).find("[0] Jogar Mario Kart Double Dash") != std::string::npos);
  CHECK(plain.RowText(3).find("[PRONTO") != std::string::npos);
}

void TestRenderScreen() {
  std::printf("[SIM] menu: desenho na tela (titulo, cursor, rolagem)\n");
  MenuSystem m;
  m.Init();
  TextScreen s;  // 80x22
  m.RenderScreen(s);
  CHECK(s.RowText(0).find("MENU PRINCIPAL") != std::string::npos);
  CHECK(s.RowText(3).find("> [0] Jogar Mario Kart") != std::string::npos);   // cursor no 1o item
  CHECK(s.RowText(5).find("  [2] Hello World") != std::string::npos);
  CHECK(s.RowText(10).find("[7] Sair") != std::string::npos);
  CHECK(s.RowText(s.rows() - 1).find("X ou Start") != std::string::npos);
  m.Handle(MenuInput::Down);
  m.RenderScreen(s);
  CHECK(s.RowText(3).find("> ") == std::string::npos);
  CHECK(s.RowText(4).find("> [1]") != std::string::npos);

  // Tela pequena: o cursor tem que continuar visivel (rolagem).
  TextScreen tiny;
  tiny.Resize(60, 8);   // so 3 linhas de itens
  MenuSystem m2;
  m2.Init();
  for (int i = 0; i < 7; ++i) m2.Handle(MenuInput::Down);   // ultimo item
  m2.RenderScreen(tiny);
  bool found = false;
  for (int y = 0; y < tiny.rows(); ++y)
    if (tiny.RowText(y).find("> [7] Sair") != std::string::npos) found = true;
  CHECK(found);
}

void TestPadEdges() {
  std::printf("[SIM] menu: eventos do pad so na borda\n");
  Ps3PadState a, b;
  CHECK(MenuInputFromPad(a, b) == MenuInput::None);
  b.dpad_down = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Down);
  CHECK(MenuInputFromPad(b, b) == MenuInput::None);            // segurando nao repete
  b = Ps3PadState(); b.dpad_up = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Up);
  b = Ps3PadState(); b.left_stick_y = 255;                      // analogico para baixo
  CHECK(MenuInputFromPad(a, b) == MenuInput::Down);
  b = Ps3PadState(); b.left_stick_y = 0;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Up);
  b = Ps3PadState(); b.cross = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Confirm);
  b = Ps3PadState(); b.start = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Confirm);
  b = Ps3PadState(); b.circle = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Back);
  b = Ps3PadState(); b.dpad_left = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Left);
  b = Ps3PadState(); b.dpad_right = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Right);
  b = Ps3PadState(); b.left_stick_x = 255;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Right);
  b = Ps3PadState(); b.left_stick_x = 0;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Left);
}

void TestRepeater() {
  std::printf("[SIM] menu: repeticao do direcional segurado\n");
  PadRepeater r(400, 100);
  Ps3PadState neutral, down;
  down.dpad_down = true;
  CHECK(r.Update(neutral, 0) == MenuInput::None);
  CHECK(r.Update(down, 10) == MenuInput::Down);            // 1o evento imediato
  CHECK(r.Update(down, 200) == MenuInput::None);           // ainda no atraso inicial
  CHECK(r.Update(down, 410) == MenuInput::Down);           // comeca a repetir
  CHECK(r.Update(down, 450) == MenuInput::None);
  CHECK(r.Update(down, 520) == MenuInput::Down);           // a cada 100 ms
  CHECK(r.Update(neutral, 530) == MenuInput::None);        // soltou
  CHECK(r.Update(neutral, 900) == MenuInput::None);        // nao repete mais
  Ps3PadState cross; cross.cross = true;
  CHECK(r.Update(cross, 1000) == MenuInput::Confirm);
  CHECK(r.Update(cross, 2000) == MenuInput::None);         // confirmar nunca repete
  r.Reset(down);                                           // segurava antes: nao gera evento novo
  CHECK(r.Update(down, 3000) == MenuInput::None);
}

void TestProfiles() {
  std::printf("[SIM] menu: perfil unico (GameCube)\n");
  ControllerProfile p = ControllerProfile::GameCube;
  CHECK(NextProfile(p) == ControllerProfile::GameCube);
  CHECK(PrevProfile(p) == ControllerProfile::GameCube);
}

}  // namespace

int main() {
  TestNavigation();
  TestState();
  TestRenderScreen();
  TestRenderBeach();
  TestPadEdges();
  TestRepeater();
  TestProfiles();
  std::printf("\n[SIM] test_menu: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
