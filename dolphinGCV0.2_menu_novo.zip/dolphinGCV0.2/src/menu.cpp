#include "menu.h"

#include <algorithm>
#include <cstdio>
#include <string>
#include <vector>

namespace dps3 {

bool MenuSystem::Init() {
  items_.clear();
  selected_ = 0;
  has_back_ = false;
  title_ = "MENU PRINCIPAL";
  status_.clear();
  // Ordem pensada para converter: primeiro o que o usuario quer (jogar), depois as demos que
  // funcionam sem disco, depois as ferramentas. O botao de acao de cada item diz o que acontece.
  AddItem("Jogar Mario Kart Double Dash (pasta DolphinGC)", MENU_ACTION_LOAD_MKDD,
          "Jogo|Mario Kart: Double Dash!!\nIDs|GM4E / GM4P / GM4J\nLocal|pasta DolphinGC\n\nProcura o disco sozinho, liga a CPU emulada e mostra o relatorio do boot.",
          "JOGAR", "JOGAR AGORA");
  AddItem("Escolher outro jogo (ISO / GCM)", MENU_ACTION_LOAD_ISO,
          "Formatos|ISO / GCM\nLocal|pasta DolphinGC\n\nEscolha qualquer disco de GameCube da pasta.",
          "JOGAR", "ESCOLHER JOGO");
  AddItem("Hello World (demo na CPU emulada)", MENU_ACTION_HELLO,
          "Tipo|Demonstracao\nExecuta|CPU emulada\nDisco|Nao precisa\n\nUm programa PowerPC de poucas instrucoes escreve a mensagem na porta de console.",
          "DEMOS", "EXECUTAR DEMO");
  AddItem("Calculadora (demo na CPU emulada)", MENU_ACTION_CALC,
          "Tipo|Demonstracao\nExecuta|CPU emulada\nDisco|Nao precisa\n\nCada conta (+ - * /) e feita por uma rotina PowerPC.",
          "DEMOS", "ABRIR CALCULADORA");
  AddItem("Explorar arquivos do disco (FST)", MENU_ACTION_LIST_FST,
          "Mostra os arquivos do disco\n(pastas, tamanhos e posicoes).",
          "SISTEMA", "VER ARQUIVOS");
  AddItem("Controles (PS3 -> GameCube)", MENU_ACTION_CONTROLS,
          "Mostra como os botoes do\ncontrole PS3 viram botoes\ndo controle de GameCube.",
          "SISTEMA", "VER CONTROLES");
  AddItem("Sobre o DolphinGC (versao e estado)", MENU_ACTION_INFO,
          "Versao do DolphinGC, pasta dos\njogos e estado atual do projeto.",
          "SISTEMA", "VER INFORMACOES");
  AddItem("Sair", MENU_ACTION_EXIT, "Fecha o DolphinGC e volta\npara o XMB.", "SISTEMA", "SAIR");
  return true;
}

void MenuSystem::SetItems(const std::vector<MenuItem>& items, const std::string& title) {
  items_ = items;
  title_ = title;
  selected_ = 0;
  has_back_ = false;
}

void MenuSystem::AddItem(const std::string& label, int action_id, const std::string& info,
                         const std::string& group, const std::string& cta) {
  items_.push_back(MenuItem{label, action_id, info, group, std::string(), cta, 0});
}

void MenuSystem::SetItemState(int action_id, const std::string& badge, Color color, const std::string& cta) {
  for (MenuItem& it : items_) {
    if (it.action_id != action_id) continue;
    it.badge = badge;
    it.badge_color = static_cast<uint8_t>(color);
    if (!cta.empty()) it.cta = cta;
  }
}

bool MenuSystem::SelectAction(int action_id) {
  for (size_t i = 0; i < items_.size(); ++i)
    if (items_[i].action_id == action_id) { selected_ = static_cast<int>(i); return true; }
  return false;
}

void MenuSystem::RenderConsole(std::FILE* out) const {
  std::fprintf(out, "\n========================================\n");
  std::fprintf(out, "  %s\n", title_.c_str());
  std::fprintf(out, "========================================\n");
  for (size_t i = 0; i < items_.size(); ++i) {
    std::fprintf(out, " %s[%d] %s\n", static_cast<int>(i) == selected_ ? "> " : "  ",
                 static_cast<int>(i), items_[i].label.c_str());
  }
  std::fprintf(out, "========================================\n");
  std::fflush(out);
}

std::string MenuSystem::DefaultFooter() {
  return "D-Pad/Analogico: mover   X ou Start: confirmar   Bolinha: voltar";
}

void MenuSystem::RenderScreenPlain(TextScreen& screen, const std::string& footer) const {
  screen.Clear();
  screen.PutCentered(0, title_, kCyan);
  screen.HLine(1);
  const int n = static_cast<int>(items_.size());
  const int top = 3, bottom = screen.rows() - 3;           // area dos itens (inclusive)
  const int visible = bottom - top + 1 > 1 ? bottom - top + 1 : 1;
  int first = 0;                                           // rolagem: mantem o cursor a vista
  if (n > visible) {
    first = selected_ - visible / 2;
    if (first < 0) first = 0;
    if (first > n - visible) first = n - visible;
  }
  for (int row = 0; row < visible && first + row < n; ++row) {
    const int i = first + row, y = top + row;
    const bool sel = i == selected_;
    if (sel) screen.FillRow(y, kBlue);
    char head[32];
    std::snprintf(head, sizeof head, " %s[%d] ", sel ? "> " : "  ", i);
    const std::string tag = items_[i].badge.empty() ? std::string() : "  [" + items_[i].badge + "]";
    screen.Put(1, y, std::string(head) + items_[i].label + tag, sel ? kYellow : kWhite, sel ? kBlue : kBlack);
  }
  if (first > 0) screen.Put(screen.cols() - 3, top, "^", kGray);
  if (first + visible < n) screen.Put(screen.cols() - 3, bottom, "v", kGray);
  screen.HLine(screen.rows() - 2);
  screen.PutCentered(screen.rows() - 1, footer, kGray);
}

namespace {

// Corta com ".." se o texto nao couber em `w` colunas.
std::string Fit(const std::string& s, int w) {
  if (w <= 0) return std::string();
  if (static_cast<int>(s.size()) <= w) return s;
  if (w <= 2) return s.substr(0, static_cast<size_t>(w));
  return s.substr(0, static_cast<size_t>(w - 2)) + "..";
}

// Quebra `text` em linhas de ate `w` colunas (por palavras); respeita '\n'.
void Wrap(const std::string& text, int w, std::vector<std::string>& out) {
  size_t i = 0;
  while (i <= text.size()) {
    size_t nl = text.find('\n', i);
    if (nl == std::string::npos) nl = text.size();
    const std::string para = text.substr(i, nl - i);
    std::string cur, word;
    for (size_t k = 0; k <= para.size(); ++k) {
      if (k == para.size() || para[k] == ' ') {
        if (!word.empty()) {
          if (!cur.empty() && static_cast<int>(cur.size() + 1 + word.size()) > w) { out.push_back(cur); cur.clear(); }
          cur += (cur.empty() ? "" : " ") + word;
          word.clear();
        }
      } else {
        word.push_back(para[k]);
      }
    }
    out.push_back(cur);
    i = nl + 1;
  }
}

}  // namespace

void MenuSystem::RenderScreen(TextScreen& screen, const std::string& footer) const {
  if (!screen.beach()) { RenderScreenPlain(screen, footer); return; }

  // ---- Menu "praia": cabecalho com status, lista agrupada a esquerda, painel com botao de acao ----
  screen.Clear();
  screen.set_scenic(true);
  const int cols = screen.cols(), rows = screen.rows();
  const int n = static_cast<int>(items_.size());

  // Cabecalho: marca + versao, titulo da tela e linha de status (a "oferta" do momento).
  screen.FillRow(0, kShade);
  screen.FillRow(1, kShade);
  screen.FillRow(2, kShade);
  screen.Put(2, 0, "DOLPHIN", kWhite, kShade);
  screen.Put(10, 0, "GC", kCyan, kShade);
  screen.Put(14, 0, "- GameCube no seu PS3", kGray, kShade);
  screen.Put(cols - 7, 0, "V0.2", kCyan, kShade);
  screen.Put(2, 1, Fit(title_, cols - 4), kYellow, kShade);
  if (!status_.empty()) {
    screen.Put(2, 2, "*", status_color_, kShade);
    screen.Put(4, 2, Fit(status_, cols - 6), status_color_, kShade);
  }

  // Linhas de exibicao: cabecalho de grupo (item = -1) ou item. O cursor so para em itens.
  struct DispRow { int item; int group_of; };
  std::vector<DispRow> disp;
  int sel_row = 0;
  std::string prev;
  for (int i = 0; i < n; ++i) {
    if (!items_[i].group.empty() && items_[i].group != prev) disp.push_back(DispRow{-1, i});
    prev = items_[i].group;
    if (i == selected_) sel_row = static_cast<int>(disp.size());
    disp.push_back(DispRow{i, i});
  }
  // Se o item selecionado e o 1o do grupo, o cabecalho dele (linha anterior) tambem fica a vista.
  const int total = static_cast<int>(disp.size());

  const int top = 4, bottom = rows - 3;                    // area das duas colunas (inclusive)
  const int visible = bottom - top + 1 > 1 ? bottom - top + 1 : 1;
  const int list_w = std::max(24, cols * 48 / 100);        // largura da lista (colunas)
  const int px0 = list_w + 1;                              // painel: de px0 ate cols-2
  int first = 0;
  if (total > visible) {
    first = sel_row - visible / 2;
    if (first < 0) first = 0;
    if (first > total - visible) first = total - visible;
    if (first > 0 && disp[first].item >= 0 && disp[first - 1].item < 0 && sel_row == first) --first;
  }
  const int list_rows = std::min(total, visible);
  const int panel_h = std::min(visible, std::max(list_rows, 13));  // altura minima: cabe o texto + botao
  const int last_y = top + panel_h - 1;

  // ---- Lista (vidro escuro; item selecionado = barra clara) ----
  for (int y = top; y <= last_y; ++y)
    for (int x = 1; x < list_w; ++x) screen.Put(x, y, " ", kWhite, kPanel);
  for (int r = 0; r < visible && first + r < total; ++r) {
    const DispRow& d = disp[first + r];
    const int y = top + r;
    if (d.item < 0) {                                       // cabecalho de grupo
      const std::string& g = items_[d.group_of].group;
      screen.Put(2, y, g, kCyan, kPanel);
      const int lx = 2 + static_cast<int>(g.size()) + 1;
      if (lx < list_w - 2) screen.Put(lx, y, std::string(static_cast<size_t>(list_w - 2 - lx), '-'), kGray, kPanel);
      continue;
    }
    const MenuItem& it = items_[d.item];
    const bool sel = d.item == selected_;
    const Color bg = sel ? kBar : kPanel;
    if (sel) for (int x = 1; x < list_w; ++x) screen.Put(x, y, " ", kWhite, kBar);
    const Color dot = it.badge.empty() ? kGray : (it.badge_color ? static_cast<Color>(it.badge_color) : kCyan);
    std::string name = it.label;                            // so o nome curto (antes de " (")
    const size_t par = name.find(" (");
    if (par != std::string::npos && par > 0) name = name.substr(0, par);
    screen.Put(2, y, sel ? ">" : " ", kYellow, bg);
    screen.Put(4, y, it.badge.empty() ? "." : "*", dot, bg);
    screen.Put(6, y, Fit(name, list_w - 7), sel ? kYellow : kWhite, bg);
  }
  if (first > 0) screen.Put(list_w - 2, top, "^", kWhite, kPanel);
  if (first + visible < total) screen.Put(list_w - 2, last_y, "v", kWhite, kPanel);

  // ---- Painel de detalhes + botao de acao ----
  if (px0 < cols - 3 && selected_ >= 0 && selected_ < n) {
    const MenuItem& it = items_[selected_];
    for (int y = top; y <= last_y; ++y)
      for (int x = px0; x < cols - 1; ++x) screen.Put(x, y, " ", kWhite, kPanel);
    const int w = cols - 1 - px0 - 2;
    const Color accent = it.badge_color ? static_cast<Color>(it.badge_color) : kCyan;
    std::string title = it.label.substr(0, it.label.find(" ("));
    screen.Put(px0 + 1, top, Fit(title, w), kYellow, kPanel);
    int y = top + 2;
    if (!it.badge.empty()) {                                // selo de status (chip colorido)
      screen.Put(px0 + 1, top + 1, " " + Fit(it.badge, w - 2) + " ", kBlack, accent);
      y = top + 3;
    }
    const int cta_y = last_y - 1;
    std::vector<std::string> lines;
    if (it.info.empty()) {
      char buf[48];
      std::snprintf(buf, sizeof buf, "Item %d de %d", selected_ + 1, n);
      lines.push_back(buf);
    } else {
      Wrap(it.info, w, lines);
    }
    int fw = 0;  // largura da coluna "campo" = maior campo + 2
    for (const std::string& ln : lines) {
      const size_t bpos = ln.find('|');
      if (bpos != std::string::npos && static_cast<int>(bpos) > fw) fw = static_cast<int>(bpos);
    }
    fw += 2;
    for (const std::string& ln : lines) {
      if (y >= cta_y - 1) break;                            // deixa uma linha livre acima do botao
      const size_t bar = ln.find('|');                      // "Campo|valor": campo em ciano, valor em branco
      if (bar != std::string::npos) {
        screen.Put(px0 + 1, y, Fit(ln.substr(0, bar), fw - 1), kCyan, kPanel);
        screen.Put(px0 + 1 + fw, y, Fit(ln.substr(bar + 1), w - fw), kWhite, kPanel);
      } else {
        screen.Put(px0 + 1, y, Fit(ln, w), kWhite, kPanel);
      }
      ++y;
    }
    // Botao de acao: faixa solida e colorida com o que acontece ao apertar X.
    if (cta_y > top + 2) {
      const std::string label = "[X]  " + (it.cta.empty() ? std::string("SELECIONAR") : it.cta);
      screen.Put(px0 + 1, cta_y, std::string(static_cast<size_t>(w), ' '), kBlack, accent);
      const std::string fit = Fit(label, w);
      screen.Put(px0 + 1 + (w - static_cast<int>(fit.size())) / 2, cta_y, fit, kBlack, accent);
    }
  }

  // Dicas de botoes no rodape.
  screen.FillRow(rows - 2, kShade);
  screen.FillRow(rows - 1, kShade);
  screen.PutCentered(rows - 2, Fit(footer, cols - 2), kWhite, kShade);
}

int MenuSystem::Handle(MenuInput in) {
  const int n = static_cast<int>(items_.size());
  switch (in) {
    case MenuInput::Up:
      if (n) selected_ = (selected_ + n - 1) % n;
      return -1;
    case MenuInput::Down:
      if (n) selected_ = (selected_ + 1) % n;
      return -1;
    case MenuInput::Confirm:
      return SelectOption(selected_);
    case MenuInput::Back:
      return has_back_ ? back_action_ : -1;
    case MenuInput::Left:
    case MenuInput::Right:
    case MenuInput::None:
      break;
  }
  return -1;
}

int MenuSystem::SelectOption(int choice) const {
  if (choice < 0 || choice >= static_cast<int>(items_.size())) return -1;
  return items_[choice].action_id;
}

MenuInput MenuInputFromPad(const Ps3PadState& prev, const Ps3PadState& cur) {
  // Analogico esquerdo conta como direcional, com histerese simples (>= 64 do centro).
  const bool prev_up = prev.dpad_up || prev.left_stick_y <= 64;
  const bool prev_down = prev.dpad_down || prev.left_stick_y >= 192;
  const bool cur_up = cur.dpad_up || cur.left_stick_y <= 64;
  const bool cur_down = cur.dpad_down || cur.left_stick_y >= 192;

  const bool prev_left = prev.dpad_left || prev.left_stick_x <= 64;
  const bool prev_right = prev.dpad_right || prev.left_stick_x >= 192;
  const bool cur_left = cur.dpad_left || cur.left_stick_x <= 64;
  const bool cur_right = cur.dpad_right || cur.left_stick_x >= 192;

  if (cur_up && !prev_up) return MenuInput::Up;
  if (cur_down && !prev_down) return MenuInput::Down;
  if (cur_left && !prev_left) return MenuInput::Left;
  if (cur_right && !prev_right) return MenuInput::Right;
  if ((cur.cross && !prev.cross) || (cur.start && !prev.start)) return MenuInput::Confirm;
  if (cur.circle && !prev.circle) return MenuInput::Back;
  return MenuInput::None;
}

MenuInput PadRepeater::Update(const Ps3PadState& cur, uint32_t now_ms) {
  const Ps3PadState prev = prev_;
  prev_ = cur;
  const MenuInput edge = MenuInputFromPad(prev, cur);
  const bool directional = edge == MenuInput::Up || edge == MenuInput::Down ||
                           edge == MenuInput::Left || edge == MenuInput::Right;
  if (edge != MenuInput::None) {
    held_ = directional ? edge : MenuInput::None;
    next_ms_ = now_ms + delay_;
    return edge;
  }
  if (held_ == MenuInput::None) return MenuInput::None;
  // Ainda segurando o mesmo sentido? (compara contra um pad neutro: so o sentido importa)
  const Ps3PadState neutral;
  Ps3PadState probe = cur;
  if (MenuInputFromPad(neutral, probe) != held_) { held_ = MenuInput::None; return MenuInput::None; }
  if (now_ms >= next_ms_) { next_ms_ = now_ms + rate_; return held_; }
  return MenuInput::None;
}

// Existe um unico perfil (GameCube); as funcoes ficam para o menu continuar igual.
ControllerProfile NextProfile(ControllerProfile) { return ControllerProfile::GameCube; }
ControllerProfile PrevProfile(ControllerProfile) { return ControllerProfile::GameCube; }

void RenderControlsScreen(ControllerProfile p, std::FILE* out) {
  std::fprintf(out, "\n========================================\n");
  std::fprintf(out, "  CONTROLES - perfil: %s\n", ProfileName(p));
  std::fprintf(out, "========================================\n");
  std::fputs(DescribeMapping(p).c_str(), out);
  std::fprintf(out, "========================================\n");
  std::fprintf(out, "  Bolinha: voltar\n");
  std::fflush(out);
}

void RenderControlsScreen(ControllerProfile p, TextScreen& screen) {
  screen.Clear();
  screen.PutCentered(0, std::string("CONTROLES - perfil: ") + ProfileName(p), kCyan);
  screen.HLine(1);
  const std::string text = DescribeMapping(p);
  int y = 3;
  size_t pos = 0;
  while (pos < text.size() && y < screen.rows() - 3) {
    size_t nl = text.find('\n', pos);
    if (nl == std::string::npos) nl = text.size();
    screen.Put(2, y++, text.substr(pos, nl - pos));
    pos = nl + 1;
  }
  screen.HLine(screen.rows() - 2);
  screen.PutCentered(screen.rows() - 1, "Bolinha: voltar", kGray);
}

} // namespace dps3
