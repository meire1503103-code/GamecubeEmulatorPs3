// DolphinGC V0.2 - emulador SOMENTE de GameCube para PS3 (em desenvolvimento).
// Foco do V0.2: Mario Kart: Double Dash!! (GM4E / GM4P / GM4J).
// Jogos ficam na pasta DolphinGC (PS3: /dev_hdd0/DolphinGC; PC: ./DolphinGC).
// Ainda NAO ha MMIO, GPU, DSP, audio nem input: o boot roda ate a primeira instrucao
// nao implementada ou acesso a memoria nao mapeada (normalmente os registradores de
// hardware em 0xCC00xxxx) e mostra onde parou.
//
// Build PS3: adicionar src/*.cpp ao Makefile PSL1GHT do projeto e definir
// -DDOLPHINPS3_PLATFORM_PS3. Sem essa macro compila como host (g++) para testes.
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstdarg>
#include <cstring>
#include <dirent.h>
#include <fstream>
#include <memory>
#include <sstream>
#include <sys/stat.h>
#include <string>
#include <vector>
#ifdef DOLPHINPS3_PLATFORM_PS3
#include <unistd.h>
#endif

#include "args.h"
#include "boot.h"
#include "cpu.h"
#include "disc.h"
#include "dol.h"
#include "fst.h"
#include "input.h"
#include "memory.h"
#include "menu.h"
#include "mmio.h"
#include "strutil.h"
#include "system.h"
#include "ui.h"

namespace {

constexpr const char* kVersion = "DolphinGC V0.2 (somente GameCube; alvo: Mario Kart Double Dash)";

// Tudo que o programa "imprime" vai para o stdout (log.txt no PS3) E para uma lista de linhas que o
// menu mostra na TV. Sem isso, no PS3 o resultado de rodar um jogo so existiria dentro do log.
std::vector<std::string> g_report;
std::string g_partial;

void Out(const char* fmt, ...) {
  char buf[1024];
  va_list ap;
  va_start(ap, fmt);
  std::vsnprintf(buf, sizeof buf, fmt, ap);
  va_end(ap);
  std::fputs(buf, stdout);
  for (const char* p = buf; *p; ++p) {
    if (*p == '\n') {
      if (g_report.size() < 20000) g_report.push_back(g_partial);
      g_partial.clear();
    } else if (*p != '\r') {
      g_partial.push_back(*p);
    }
  }
}

void FlushReport() {
  if (!g_partial.empty()) { g_report.push_back(g_partial); g_partial.clear(); }
}

// Fonte do controle para o jogo: no PS3 le o pad (libpad) e converte para GameCube.
bool GamePadSource(dps3::GameCubePadState& out) {
#ifdef DOLPHINPS3_PLATFORM_PS3
  dps3::Ps3PadState ps3;
  if (!dps3::PadPoll(ps3)) return false;
  out = dps3::MapPs3ToGameCube(ps3);
  return true;
#else
  (void)out;
  return false;
#endif
}

// Limite de seguranca do primeiro boot (instrucoes interpretadas).
constexpr uint64_t kMaxBootSteps = 50000000ull;

#ifdef DOLPHINPS3_PLATFORM_PS3
// PS3 nao tem linha de comando nem console visivel. Ao instalar o .pkg, o app
// fica em /dev_hdd0/game/DGCV00001/USRDIR/ (mesmo ID do sfo.xml/Makefile).
//  - args.txt : mesmos argumentos da CLI, ex.:  /dev_hdd0/DolphinGC/jogo.iso
//  - log.txt  : tudo que o programa imprimiria (stdout/stderr) vai para este arquivo
constexpr const char* kArgsFile = "/dev_hdd0/game/DGCV00001/USRDIR/args.txt";
constexpr const char* kLogFile = "/dev_hdd0/game/DGCV00001/USRDIR/log.txt";

void RedirectOutputToLog() {
  // Trunca uma vez e abre stdout/stderr em modo append (evita um sobrescrever o outro).
  if (std::FILE* t = std::fopen(kLogFile, "w")) std::fclose(t);
  std::freopen(kLogFile, "a", stdout);
  std::freopen(kLogFile, "a", stderr);
  std::setvbuf(stdout, nullptr, _IONBF, 0);  // sem buffer: o log sobrevive a um travamento
  std::setvbuf(stderr, nullptr, _IONBF, 0);
}
#endif

std::vector<std::string> CollectArgs(int argc, char** argv) {
  std::vector<std::string> a;
#ifdef DOLPHINPS3_PLATFORM_PS3
  (void)argc; (void)argv;
  std::ifstream in(kArgsFile);
  if (in) {
    std::stringstream ss;
    ss << in.rdbuf();
    a = dps3::TokenizeArgsText(ss.str());
  }
#else
  for (int i = 1; i < argc; ++i) a.push_back(argv[i]);
#endif
  return a;
}


// Pasta onde ficam os jogos: DolphinGC. No PS3 fica em /dev_hdd0; no PC, ao lado do programa.
#ifdef DOLPHINPS3_PLATFORM_PS3
constexpr const char* kIsoDir = "/dev_hdd0/DolphinGC";
#else
constexpr const char* kIsoDir = "DolphinGC";
#endif

// Cria a pasta DolphinGC se ainda nao existir (para o usuario so copiar os jogos para la).
void EnsureGameDir() {
#ifdef DOLPHINPS3_PLATFORM_PS3
  mkdir(kIsoDir, 0777);
#else
  mkdir(kIsoDir, 0777);
#endif
}

bool HasDiscExtension(const std::string& name) {
  const size_t dot = name.rfind('.');
  if (dot == std::string::npos) return false;
  std::string ext = name.substr(dot);
  std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) { return std::tolower(c); });
  return ext == ".iso" || ext == ".gcm";
}

std::vector<std::string> ListDiscs(const std::string& dir) {
  std::vector<std::string> out;
  if (DIR* d = opendir(dir.c_str())) {
    while (const dirent* e = readdir(d)) {
      const std::string name = e->d_name;
      if (HasDiscExtension(name)) out.push_back(dir + "/" + name);
    }
    closedir(d);
  }
  std::sort(out.begin(), out.end());
  return out;
}

// Carrega e (opcionalmente) lista a FST / executa o boot de um disco. Devolve o codigo de saida.
// Contexto do callback de progresso do boot (atualiza a tela e deixa cancelar com Bolinha).
struct BootUi {
  dps3::Ui* ui = nullptr;
  std::string title;
  uint64_t last_draw = ~0ull;
};

bool BootProgress(uint64_t steps, void* user) {
  BootUi* b = static_cast<BootUi*>(user);
  if (!b->ui) return true;
  if (b->ui->CancelRequested()) return false;
  const uint64_t step_m = steps / 1000000ull;
  if (step_m != b->last_draw) {  // so redesenha a cada 1 milhao de passos
    b->last_draw = step_m;
    dps3::TextScreen& s = b->ui->screen();
    s.Clear();
    s.PutCentered(0, "EXECUTANDO", dps3::kCyan);
    s.HLine(1);
    s.PutCentered(5, b->title, dps3::kWhite);
    s.PutCentered(7, dps3::NumStrU(step_m) + " milhoes de instrucoes executadas", dps3::kYellow);
    s.PutCentered(9, "(ainda nao ha video do jogo: veja o relatorio ao final)", dps3::kGray);
    s.HLine(s.rows() - 2);
    s.PutCentered(s.rows() - 1, "Bolinha: cancelar", dps3::kGray);
    dps3::PlatformPresent(s);
  }
  return true;
}

int RunTarget(const std::string& target, bool list_files, dps3::Ui* ui = nullptr) {
  std::string err;
  dps3::DiscReader disc;
  if (!disc.Open(target, err)) {
    Out("erro ao abrir disco: %s\n", err.c_str());
    return 1;
  }
  Out("Console : %s\nGame ID : %s\nTitulo  : %s\nDisco   : %u  Versao: %u\nTamanho : %llu bytes\n",
              dps3::KindName(disc.kind()), disc.game_id().c_str(), disc.title().c_str(),
              disc.disc_number(), disc.version(),
              static_cast<unsigned long long>(disc.size()));
  if (dps3::IsMarioKartDoubleDash(disc.game_id()))
    Out("Alvo    : Mario Kart: Double Dash!! detectado (regiao %c)\n", disc.game_id()[3]);

  if (list_files) {
    dps3::GameCubeFst fst;
    std::string fst_error;
    if (!fst.Load(disc, fst_error)) {
      Out("Erro ao carregar FST: %s\n", fst_error.c_str());
      return 1;
    }
    Out("\n=== GAMECUBE FILE SYSTEM ===\n");
    for (const auto& entry : fst.entries()) {
      if (entry.type == dps3::FstEntryType::Directory) {
        Out("[DIR]  %s\n", entry.path.c_str());
      } else {
        Out("[FILE] %s | Offset: %llu | Size: %llu\n", entry.path.c_str(),
                    static_cast<unsigned long long>(entry.offset),
                    static_cast<unsigned long long>(entry.size));
      }
    }
    Out("\nTotal de entradas: %lu\n", static_cast<unsigned long>(fst.entries().size()));
    return 0;
  }

  // ---- boot: apploader real (preferido) ou, se falhar, DOL direto ----
  dps3::Memory mem;
  if (!mem.Init(err)) { Out("erro: %s\n", err.c_str()); return 1; }
  // MmioHandler tem ~64 KB: no heap para nao estourar a pilha pequena do PS3.
  std::unique_ptr<dps3::MmioHandler> hw_ptr(new dps3::MmioHandler);
  dps3::MmioHandler& hw = *hw_ptr;
  mem.SetMmio(&hw);
  hw.Attach(&mem, &disc);
  dps3::Cpu cpu(mem);

  uint32_t entry = 0;
  std::string app_err;
  if (dps3::BootGameCubeApploader(disc, mem, cpu, entry, app_err)) {
    Out("\nBoot    : apploader executado na CPU, entry do jogo 0x%08X\n", entry);
  } else {
    Out("\nBoot    : apploader falhou (%s)\n          usando o DOL principal direto.\n", app_err.c_str());
    // O apploader pode ter sujado a RAM/CPU: recomeca limpo.
    if (!mem.Init(err)) { Out("erro: %s\n", err.c_str()); return 1; }
    hw.Reset();
    dps3::DolImage dol;
    if (!dps3::BootGameCubeDol(disc, mem, cpu, dol, err)) {
      Out("erro ao carregar o DOL: %s\n", err.c_str());
      return 1;
    }
    Out("DOL     : %lu secoes, entry 0x%08X, bss 0x%08X (+0x%X)\n",
                static_cast<unsigned long>(dol.sections.size()), dol.entry, dol.bss_address, dol.bss_size);
  }

  BootUi boot_ui;
  boot_ui.ui = ui;
  boot_ui.title = disc.title().empty() ? disc.game_id() : disc.title();
  const dps3::StopReason why =
      dps3::RunSystem(cpu, hw, kMaxBootSteps, GamePadSource, BootProgress, &boot_ui);
  Out("\nCPU parou: %s\n", dps3::StopReasonName(why));
  Out("  passos : %llu\n  pc     : 0x%08X   instr: 0x%08X\n",
              static_cast<unsigned long long>(cpu.steps()), cpu.pc, cpu.last_instr);
  if (why == dps3::StopReason::MemFault)
    Out("  endereco acessado: 0x%08X\n", cpu.fault_addr);
  Out("  lr=0x%08X ctr=0x%08X cr=0x%08X xer=0x%08X msr=0x%08X\n", cpu.lr, cpu.ctr, cpu.cr, cpu.xer, cpu.msr);
  for (int i = 0; i < 32; i += 4)
    Out("  r%-2d=%08X r%-2d=%08X r%-2d=%08X r%-2d=%08X\n", i, cpu.gpr[i], i + 1,
                cpu.gpr[i + 1], i + 2, cpu.gpr[i + 2], i + 3, cpu.gpr[i + 3]);
  Out("\nHardware: %llu acessos MMIO, %llu quadros de VI, DVD: %llu leituras / %llu bytes / %llu erros\n"
              "          interrupcoes PI pendentes: 0x%08X\n",
              static_cast<unsigned long long>(hw.mmio_accesses()), static_cast<unsigned long long>(hw.frames()),
              static_cast<unsigned long long>(hw.dvd_reads()), static_cast<unsigned long long>(hw.dvd_bytes()),
              static_cast<unsigned long long>(hw.dvd_errors()), hw.pi_cause());

  Out("\n[status V0.2] ainda faltam para o jogo aparecer: video GX->RSX, audio DSP\n"
              "  de verdade, mais instrucoes/hardware (veja onde a CPU parou acima).\n");
  return 0;
}

// Procura na pasta DolphinGC a primeira imagem que seja Mario Kart: Double Dash!!. "" se nao achar.
std::string FindMarioKart() {
  for (const std::string& path : ListDiscs(kIsoDir)) {
    dps3::DiscReader d;
    std::string e;
    if (d.Open(path, e) && dps3::IsMarioKartDoubleDash(d.game_id())) return path;
  }
  return "";
}

// Menu de escolha de ISO. Devolve "" se o usuario voltou/cancelou.
std::string ChooseDisc(dps3::Ui& ui) {
  std::vector<std::string> discs = ListDiscs(kIsoDir);
  if (discs.empty()) {
    ui.ShowLines("ESCOLHA O JOGO",
                 {std::string("Nenhuma ISO/GCM encontrada em ") + kIsoDir + ".", "",
                  "Copie o jogo (ex.: Mario Kart Double Dash) para a pasta DolphinGC",
                  "e abra esta opcao de novo.", "",
                  "Discos de Wii e arquivos RVZ/WIA/GCZ nao sao aceitos."},
                 "Bolinha: voltar");
    return "";
  }
  dps3::MenuSystem pick;
  std::vector<dps3::MenuItem> items;
  for (size_t i = 0; i < discs.size(); ++i) {
    const size_t slash = discs[i].rfind('/');
    items.push_back({slash == std::string::npos ? discs[i] : discs[i].substr(slash + 1),
                     static_cast<int>(i)});
  }
  items.push_back({"Voltar", -2});
  pick.SetItems(items, "ESCOLHA O JOGO");
  pick.set_back_action(-2, true);
  for (;;) {
    pick.RenderScreen(ui.screen());
    dps3::UiEvent ev;
    if (!ui.Wait(ev)) return "";
    const int act = ev.direct >= 0 ? pick.SelectOption(ev.direct) : pick.Handle(ev.nav);
    if (act == -2) return "";
    if (act >= 0 && act < static_cast<int>(discs.size())) return discs[act];
  }
}

// Roda um disco e mostra o relatorio na tela (no PS3 a tela e a unica saida visivel).
int RunTargetOnScreen(dps3::Ui& ui, const std::string& path, bool list_files, const char* title) {
  g_report.clear();
  g_partial.clear();
  const int rc = RunTarget(path, list_files, &ui);
  FlushReport();
  if (!ui.exit_requested()) ui.ShowLines(title, g_report);
  return rc;
}

// Atualiza selos, botoes e a linha de status do menu conforme o que ha na pasta DolphinGC.
// Chamado ao abrir o menu e depois de cada acao (abre os discos da pasta, entao nao roda por quadro).
// Devolve true se o Mario Kart esta pronto.
bool RefreshMenuState(dps3::MenuSystem& menu) {
  const std::vector<std::string> discs = ListDiscs(kIsoDir);
  const bool mk = !FindMarioKart().empty();
  if (mk)
    menu.SetItemState(dps3::MENU_ACTION_LOAD_MKDD, "PRONTO PARA JOGAR", dps3::kGreen, "JOGAR AGORA");
  else
    menu.SetItemState(dps3::MENU_ACTION_LOAD_MKDD, "SEM ISO NA PASTA", dps3::kGray, "VER COMO INSTALAR");
  char buf[96];
  if (discs.empty()) {
    menu.SetItemState(dps3::MENU_ACTION_LOAD_ISO, "PASTA VAZIA", dps3::kGray, "VER COMO INSTALAR");
    menu.SetStatus("Sem jogos ainda: teste as demos ou copie uma ISO para DolphinGC", dps3::kYellow);
  } else {
    std::snprintf(buf, sizeof buf, "%lu JOGO(S) ENCONTRADO(S)", static_cast<unsigned long>(discs.size()));
    menu.SetItemState(dps3::MENU_ACTION_LOAD_ISO, buf, dps3::kGreen, "ESCOLHER JOGO");
    if (mk) menu.SetStatus("Mario Kart pronto! Aperte X para jogar", dps3::kGreen);
    else {
      std::snprintf(buf, sizeof buf, "%lu jogo(s) na pasta DolphinGC: escolha um para iniciar",
                    static_cast<unsigned long>(discs.size()));
      menu.SetStatus(buf, dps3::kCyan);
    }
  }
  menu.SetItemState(dps3::MENU_ACTION_HELLO, "FUNCIONA SEM DISCO", dps3::kCyan, "EXECUTAR DEMO");
  menu.SetItemState(dps3::MENU_ACTION_CALC, "FUNCIONA SEM DISCO", dps3::kCyan, "ABRIR CALCULADORA");
  return mk;
}

int RunMenu() {
  dps3::Ui ui;
  ui.Init();
  dps3::MenuSystem menu;
  menu.Init();
  // Cursor ja no melhor primeiro passo: jogar (se ha Mario Kart) ou a demo que roda sem disco.
  menu.SelectAction(RefreshMenuState(menu) ? dps3::MENU_ACTION_LOAD_MKDD : dps3::MENU_ACTION_HELLO);
  std::printf("[Menu] Sistema de Menu inicializado com sucesso.\n");
  dps3::ControllerProfile profile = dps3::ControllerProfile::GameCube;
  int rc = 0;
  for (;;) {
    menu.RenderScreen(ui.screen());
    dps3::UiEvent ev;
    if (!ui.Wait(ev)) break;  // XMB pediu para fechar, ou fim da entrada no PC
    const int act = ev.direct >= 0 ? menu.SelectOption(ev.direct) : menu.Handle(ev.nav);
    if (act < 0) continue;
    if (act == dps3::MENU_ACTION_EXIT) break;
    if (act == dps3::MENU_ACTION_HELLO) {
      ui.RunHelloScreen();
    } else if (act == dps3::MENU_ACTION_CALC) {
      ui.RunCalculatorScreen();
    } else if (act == dps3::MENU_ACTION_LOAD_MKDD) {
      const std::string path = FindMarioKart();
      if (path.empty())
        ui.ShowLines("MARIO KART DOUBLE DASH",
                     {"Mario Kart Double Dash nao encontrado em " + std::string(kIsoDir) + ".", "",
                      "Copie o ISO/GCM (IDs GM4E, GM4P ou GM4J) para essa pasta."},
                     "Bolinha: voltar");
      else
        rc = RunTargetOnScreen(ui, path, false, "RELATORIO DO BOOT");
    } else if (act == dps3::MENU_ACTION_LOAD_ISO || act == dps3::MENU_ACTION_LIST_FST) {
      const std::string path = ChooseDisc(ui);
      if (!path.empty())
        rc = RunTargetOnScreen(ui, path, act == dps3::MENU_ACTION_LIST_FST,
                               act == dps3::MENU_ACTION_LIST_FST ? "FST DO DISCO" : "RELATORIO DO BOOT");
    } else if (act == dps3::MENU_ACTION_CONTROLS) {
      ui.RunControlsScreen(profile);
    } else if (act == dps3::MENU_ACTION_INFO) {
      ui.ShowLines("INFORMACOES",
                   {kVersion, std::string("Perfil de controle ativo: ") + dps3::ProfileName(profile),
                    std::string("Pasta dos jogos: ") + kIsoDir, "",
                    "Estado: ainda nao roda jogos (sem video GX->RSX nem audio).",
                    "Hello World e Calculadora rodam de verdade na CPU emulada."},
                   "Bolinha: voltar");
    }
    if (ui.exit_requested()) break;
    RefreshMenuState(menu);  // o usuario pode ter mexido na pasta; mantem selos e status em dia
  }
  ui.Shutdown();
  return rc;
}

}  // namespace

int main(int argc, char** argv) {
#ifdef DOLPHINPS3_PLATFORM_PS3
  RedirectOutputToLog();
#endif
  dps3::LaunchOptions opt;
  std::string err;
  if (!dps3::ParseArgs(CollectArgs(argc, argv), opt, err)) {
    std::fprintf(stderr, "erro: %s\n\n%s", err.c_str(), dps3::UsageText());
    return 2;
  }
  if (opt.show_help) { std::fputs(dps3::UsageText(), stdout); return 0; }
  if (opt.show_version) { std::printf("%s\n", kVersion); return 0; }

  EnsureGameDir();
  std::printf("%s\n", kVersion);

  // Prioridade do alvo de boot: --exec, depois primeiro FILE posicional.
  std::string target = !opt.exec_file.empty() ? opt.exec_file
                       : (!opt.files.empty() ? opt.files[0] : std::string());
  if (target.empty()) return RunMenu();  // sem disco informado: abre o menu
  return RunTarget(target, opt.list_files);
}
