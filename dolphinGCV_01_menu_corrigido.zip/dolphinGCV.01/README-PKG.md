# DolphinGC V.01 - emulador de GameCube para PS3

> **Status honesto:** este projeto ainda **nao roda jogos**. Nada aqui foi testado num PS3 nem com o
> PSL1GHT real (so no PC, com testes automaticos). O alvo do V.01 e **Mario Kart: Double Dash!!**,
> mas ele ainda nao chega na tela. Veja "O que ainda falta" abaixo.
>
> **Novo nesta versao:** o menu agora e desenhado **na TV** (framebuffer da RSX) e traz dois programas
> que rodam de verdade na CPU emulada: **Hello World** e **Calculadora**.

Esta versao e **somente GameCube**: o suporte a Wii (Wiimote, Nunchuk, Classic, discos Wii) foi removido.
Discos Wii e arquivos RVZ/WIA/GCZ sao recusados com mensagem clara.

## Pasta dos jogos: `DolphinGC`
- **PS3:** `/dev_hdd0/DolphinGC/`  (o app cria a pasta sozinho ao abrir)
- **PC (testes):** `./DolphinGC/` ao lado do programa (ja vem uma pasta aqui no zip)
- Coloque la o ISO/GCM. Para o Mario Kart Double Dash o menu tem um item direto:
  **"Rodar Mario Kart Double Dash"** (acha sozinho os IDs `GM4E`, `GM4P` ou `GM4J`).

## Compilar (PS3)
```
export PS3DEV=/usr/local/ps3dev ; export PSL1GHT=$PS3DEV
export PATH=$PATH:$PS3DEV/bin:$PS3DEV/ppu/bin:$PS3DEV/spu/bin
make          # gera dolphinGCV.01.elf / .self
make pkg      # gera dolphinGCV.01.pkg (e .gnpdrm.pkg); ID do app: DGCV00001
```
O `Makefile` agora usa o `ppu_rules` do PSL1GHT (o modelo dos exemplos oficiais). O anterior chamava
`ppu-lv2-elf.sh`, que nao existe no SDK, entao o `make pkg` nao funcionava. `make pkg` tambem ja leva
`ICON0.PNG`, `PIC1.PNG` (fundo do XMB) e `config/` para dentro do .pkg.

Se o seu `ppu_rules` for antigo e nao copiar `pkgfiles/` (o `PIC1.PNG` nao aparece no XMB), os passos
manuais sao: `make_self_npdrm dolphinGCV.01.elf EBOOT.BIN UP0001-DGCV00001_00-0000000000000000`,
`sfo.py --title "DolphinGC V.01" --appid DGCV00001 -f sfo.xml PARAM.SFO` e
`pkg.py --contentid UP0001-DGCV00001_00-0000000000000000 pkg/ dolphinGCV.01.pkg`, com `pkg/` contendo
`ICON0.PNG`, `PIC1.PNG`, `PARAM.SFO` e `USRDIR/EBOOT.BIN`.

## Usar no PS3
1. Instale o `.pkg`. A pasta `/dev_hdd0/DolphinGC/` e criada sozinha na 1a abertura; copie os jogos para la.
2. Abra o app: o menu aparece na TV. D-Pad ou analogico esquerdo navega (segurar repete), **X/Start**
   confirma, **Bolinha** volta. Botao PS > "Sair do jogo" fecha o app normalmente.
3. Primeiro teste sugerido: **Hello World** e **Calculadora** (nao precisam de nenhum jogo).
4. Alternativa sem menu: `/dev_hdd0/game/DGCV00001/USRDIR/args.txt` com o caminho da ISO.
5. Tudo que o app imprime tambem vai para `/dev_hdd0/game/DGCV00001/USRDIR/log.txt`.

## Menu (o que mudou)
- **Antes:** o menu so imprimia texto, e no PS3 o texto ia para o `log.txt`; na TV ficava tela preta.
- **Agora:** `src/screen.*` (grade de texto + fonte 8x16), `src/platform_ps3.cpp` (video RSX com 2 buffers,
  resolucao automatica 480p..1080p, ampliacao inteira) e `src/ui.*` (telas). O resultado de rodar um jogo,
  a lista da FST e as informacoes tambem aparecem na tela, com rolagem e quebra de linha.
- O app trata o botao PS (sysutil) e nao trava mais o XMB; o boot roda em fatias, mostra o progresso e
  **Bolinha cancela**.
- Sem controle conectado, a tela avisa em vermelho.

## Programas de demonstracao (rodam na CPU emulada)
- **Hello World** (`src/demos.cpp`): um programa PowerPC de ~10 instrucoes le a string da RAM do guest e
  escreve cada letra na porta de console `0xCC00FF00` (extensao do DolphinGC no MMIO).
- **Calculadora**: teclado na tela (D-Pad move, X aperta). Cada conta (+ - * /) e executada por uma rotina
  PowerPC (`add/subf/mullw/divw`) na CPU emulada; a tela mostra quantas contas/instrucoes foram executadas.
  Inteiros de 32 bits, ate 9 digitos; avisa divisao por zero e estouro.
- Servem de prova de que CPU, memoria e MMIO funcionam, mesmo sem jogo.

## Otimizacoes
- Tela: so redesenha quando a grade muda (menu parado = 0 trabalho de video); o laco de entrada dorme
  16 ms entre leituras do controle em vez de ficar rodando sem parar.
- `RunSystem`: controle e progresso consultados a cada ~65 mil passos (antes: a cada 4096 = 16x mais syscalls
  de `libpad`).
- Calculadora/Hello reaproveitam uma unica VM (a RAM do guest tem 24 MiB; nao e realocada a cada conta).
- Makefile do PS3: `-O2 -mcpu=cell`, `-fno-rtti`, `-Wl,--gc-sections`. No PC, `-O2` mediu ~183 Mpassos/s contra
  ~140-175 do `-O3` (o PPU do PS3 e em ordem; codigo compacto tende a ajudar). **Nao medido no PS3.**
- O nucleo do interpretador (`cpu.cpp`) nao foi alterado: ja estava em ~184 Mpassos/s no PC.

## Testar no PC
```
make -f Makefile.host all     # build/dolphinGCV.01_host (menu no terminal)
make -f Makefile.host test    # 15 suites de teste
make -f Makefile.host bench   # mede passos/segundo do interpretador
make -f Makefile.host asan    # mesmos testes com AddressSanitizer
```

## O que ja existe (ate agora)
- **Boot pelo apploader real:** o app carrega o apploader do disco (0x2440), executa ele na CPU emulada
  (`entry -> init -> main -> close`) e deixa ele copiar o jogo para a RAM. Se o apploader falhar, cai no
  boot direto do DOL e mostra o motivo. Testado com um apploader sintetico (`tests/test_apploader.cpp`);
  **nao foi testado com o apploader do Mario Kart**.
- **Hardware simplificado ligado a memoria** (`src/mmio.*`): leitura de disco por DMA (DI) com
  interrupcao, controle (SI) alimentado pelo pad do PS3, retrace de video e interrupcoes (VI/PI),
  mailbox do DSP. Antes disso, qualquer acesso a 0xCC00xxxx falhava na hora.
- **Laco do sistema** (`src/system.*`): avanca o relogio, entrega interrupcoes externas e le o controle.
- **CPU ~2,4x mais rapida** no PC (79 -> ~193 milhoes de instrucoes/s no `make -f Makefile.host bench`).
  No PS3 real a velocidade sera bem menor; ainda nao foi medida la.
- **Aviso:** o codigo especifico do PS3 (`platform_ps3.cpp`, `pad_ps3.cpp`) foi escrito seguindo os exemplos do
  PSL1GHT e so teve a sintaxe checada contra cabecalhos de mentira; no 1o build real pode precisar de ajuste de
  nome de funcao/header (fica concentrado nesses dois arquivos).
- O `hle.cpp` NAO esta ligado: os enderecos dele sao ficticios.

## O que ainda falta para o Mario Kart Double Dash aparecer
1. Rodar com o ISO real e corrigir o que parar primeiro (instrucoes da CPU ainda nao implementadas,
   registradores de hardware que o jogo espera). O log mostra pc, instrucao e acessos MMIO.
2. Video: traduzir o FIFO do GX para RSX (hoje `gx.cpp` so imprime os comandos).
3. Audio: DSP e AI de verdade (hoje so o mailbox inicial).
4. Fidelidade: o hardware atual e simplificado (nao ciclo-exato); jogos podem exigir mais detalhes.
5. Desempenho no PS3: provavelmente precisara de otimizacao pesada ou recompilador dinamico.

## Controles (PS3 -> GameCube)
Veja `config/mapeamento_botoes.txt` (o menu mostra o mesmo texto).

## Arquivos
`Makefile` (PS3), `Makefile.host` (PC), `sfo.xml`, `ICON0.PNG` (320x176), `PIC1.PNG` (1920x1080), `src/`, `tests/`, `config/`, `DolphinGC/`.
