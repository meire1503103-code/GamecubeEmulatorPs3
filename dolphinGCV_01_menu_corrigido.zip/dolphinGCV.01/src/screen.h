// DolphinGC V.01 - tela de texto (grade de caracteres coloridos).
//
// Todo o menu e desenhado aqui, igual no PS3 e no PC. No PS3, Rasterize() converte a grade em
// pixels XRGB do framebuffer da RSX (ver platform_ps3.cpp); no PC, DumpText() imprime no terminal.
// A grade lembra o que foi mostrado da ultima vez: so redesenha quando algo mudou (TakeDirty).
#pragma once
#include <cstdint>
#include <cstdio>
#include <string>
#include <vector>

namespace dps3 {

// Paleta fixa (indices usados em fg/bg de cada celula).
enum Color : uint8_t {
  kBlack = 0, kWhite, kYellow, kCyan, kGreen, kRed, kGray, kBlue, kColorCount
};

class TextScreen {
 public:
  TextScreen() { Resize(80, 22); }
  void Resize(int cols, int rows);
  int cols() const { return cols_; }
  int rows() const { return rows_; }

  void Clear(Color bg = kBlack);
  // Escreve `s` a partir de (x, y); corta o que passar da borda. Caracteres fora de 32..126 viram '?'.
  void Put(int x, int y, const std::string& s, Color fg = kWhite, Color bg = kBlack);
  void PutCentered(int y, const std::string& s, Color fg = kWhite, Color bg = kBlack);
  void FillRow(int y, Color bg);
  void HLine(int y, char ch = '=', Color fg = kGray);

  std::string RowText(int y) const;  // texto puro da linha (sem cores, sem espacos finais)

  // true se a grade mudou desde a ultima chamada (e marca como "ja mostrada").
  bool TakeDirty();

  // Desenha a grade em `dst` (XRGB8888, `pitch_px` pixels por linha) com ampliacao inteira `scale`,
  // centralizada e sobre fundo preto. Nao le `dst` (a memoria de video da RSX e lenta para leitura).
  void Rasterize(uint32_t* dst, int width, int height, int pitch_px, int scale) const;

  void DumpText(std::FILE* out) const;  // PC: mostra o texto no terminal

  static uint32_t RgbOf(Color c);

 private:
  struct Cell {
    char ch = ' ';
    uint8_t fg = kWhite, bg = kBlack;
    bool operator==(const Cell& o) const { return ch == o.ch && fg == o.fg && bg == o.bg; }
  };
  int cols_ = 0, rows_ = 0;
  std::vector<Cell> cells_, shown_;
};

}  // namespace dps3
