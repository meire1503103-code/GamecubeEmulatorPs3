// DolphinGC V.01 - MMIO: registradores de hardware do Flipper (0xCC000000..0xCC00FFFF).
//
// Implementado de forma SIMPLIFICADA (nao e ciclo-exato):
//  - PI: causa/mascara de interrupcao + revisao do chip.
//  - DI: leitura de disco por DMA (comando 0xA8), com interrupcao de fim de transferencia.
//  - SI: controle do canal 0 (dados lidos do estado GameCubePadState; resposta de ID e de leitura).
//  - VI: interrupcoes de retrace (4 registradores de display interrupt), geradas por Tick().
//  - DSP: mailbox DSP->CPU com o valor inicial que o SDK espera (0x8071FEED).
//  - Demais areas (CP, PE, AI, EXI, MI...): armazenam o que foi escrito e devolvem o mesmo valor.
#pragma once
#include <cstdint>
#include <string>

#include "input.h"
#include "memory.h"

namespace dps3 {

class DiscReader;

// Quantos passos da CPU equivalem a um quadro (486 MHz / 60 Hz ~= 8,1 M ciclos; ~1 passo/ciclo).
constexpr uint64_t kStepsPerFrame = 8100000ull;

// Porta de console do DolphinGC (nao existe no GameCube de verdade): um byte escrito em
// 0xCC00FF00 vai para o texto de saida do programa guest. Usada pelos programas de demonstracao
// (Hello World / Calculadora) para "imprimir" sem precisar de video.
constexpr uint32_t kConsolePortOffset = 0xFF00;

// Bits do registrador de causa de interrupcao do PI.
enum PiInterrupt : uint32_t {
  PI_INT_DI = 1u << 2,
  PI_INT_SI = 1u << 3,
  PI_INT_VI = 1u << 8
};

class MmioHandler : public MmioBus {
 public:
  MmioHandler();
  void Reset();
  // Liga a memoria do guest (destino do DMA) e o disco (origem). Ambos podem ser nulos em testes.
  void Attach(Memory* mem, DiscReader* disc) { mem_ = mem; disc_ = disc; }

  bool MmioRead(uint32_t phys, unsigned size, uint32_t& value) override;
  bool MmioWrite(uint32_t phys, unsigned size, uint32_t value) override;

  // Estado atual do controle do jogador 1 (preenchido pelo pad do PS3).
  void SetPad(const GameCubePadState& pad) { pad_ = pad; }

  // Avanca o relogio simulado; gera o retrace de video a cada kStepsPerFrame passos.
  void Tick(uint64_t cpu_steps);
  // true se ha interrupcao nao mascarada pendente (a CPU deve receber a excecao 0x500).
  bool InterruptPending() const { return (pi_cause_ & pi_mask_) != 0; }

  // Diagnostico / testes.
  uint32_t pi_cause() const { return pi_cause_; }
  uint64_t frames() const { return frames_; }
  uint64_t dvd_reads() const { return dvd_reads_; }
  uint64_t dvd_bytes() const { return dvd_bytes_; }
  uint64_t dvd_errors() const { return dvd_errors_; }
  uint64_t mmio_accesses() const { return accesses_; }

  // Texto escrito pelo guest na porta de console.
  const std::string& console() const { return console_; }
  void ClearConsole() { console_.clear(); }

 private:
  uint32_t Get32(uint32_t off) const;
  void Set32(uint32_t off, uint32_t v);
  void SetPiBit(uint32_t bit, bool on) { if (on) pi_cause_ |= bit; else pi_cause_ &= ~bit; }
  void RefreshDiIrq();
  void RefreshSiIrq();
  void RefreshViIrq();
  void ExecuteDiCommand();
  void ExecuteSiTransfer();
  uint32_t PadInH() const;
  uint32_t PadInL() const;
  void OnVerticalRetrace();

  uint8_t raw_[kMmioSize];  // armazenamento generico (big-endian)
  uint32_t pi_cause_ = 0, pi_mask_ = 0;
  uint64_t frame_steps_ = 0, frames_ = 0;
  uint64_t dvd_reads_ = 0, dvd_bytes_ = 0, dvd_errors_ = 0, accesses_ = 0;
  GameCubePadState pad_;
  std::string console_;
  Memory* mem_ = nullptr;
  DiscReader* disc_ = nullptr;
};

}  // namespace dps3
