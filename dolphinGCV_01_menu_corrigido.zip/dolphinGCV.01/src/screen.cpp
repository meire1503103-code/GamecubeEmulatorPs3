#include "screen.h"

#include <algorithm>

#include "font8x16.h"

namespace dps3 {

void TextScreen::Resize(int cols, int rows) {
  cols_ = std::max(1, cols);
  rows_ = std::max(1, rows);
  cells_.assign(static_cast<size_t>(cols_) * rows_, Cell());
  shown_.clear();  // forca um redesenho completo
}

void TextScreen::Clear(Color bg) {
  Cell c;
  c.bg = bg;
  std::fill(cells_.begin(), cells_.end(), c);
}

void TextScreen::Put(int x, int y, const std::string& s, Color fg, Color bg) {
  if (y < 0 || y >= rows_) return;
  for (size_t i = 0; i < s.size(); ++i, ++x) {
    if (x < 0) continue;
    if (x >= cols_) break;
    char ch = s[i];
    if (ch < kFirstGlyph || ch > kLastGlyph) ch = '?';
    Cell& c = cells_[static_cast<size_t>(y) * cols_ + x];
    c.ch = ch; c.fg = fg; c.bg = bg;
  }
}

void TextScreen::PutCentered(int y, const std::string& s, Color fg, Color bg) {
  Put((cols_ - static_cast<int>(s.size())) / 2, y, s, fg, bg);
}

void TextScreen::FillRow(int y, Color bg) {
  if (y < 0 || y >= rows_) return;
  for (int x = 0; x < cols_; ++x) {
    Cell& c = cells_[static_cast<size_t>(y) * cols_ + x];
    c.ch = ' '; c.bg = bg;
  }
}

void TextScreen::HLine(int y, char ch, Color fg) {
  Put(0, y, std::string(static_cast<size_t>(cols_), ch), fg);
}

std::string TextScreen::RowText(int y) const {
  std::string s;
  if (y < 0 || y >= rows_) return s;
  for (int x = 0; x < cols_; ++x) s.push_back(cells_[static_cast<size_t>(y) * cols_ + x].ch);
  while (!s.empty() && s.back() == ' ') s.pop_back();
  return s;
}

bool TextScreen::TakeDirty() {
  if (shown_ == cells_) return false;
  shown_ = cells_;
  return true;
}

uint32_t TextScreen::RgbOf(Color c) {
  static const uint32_t kPal[kColorCount] = {
    0x00101018, 0x00F0F0F0, 0x00FFD84A, 0x0050D8F0, 0x0060E070, 0x00FF5050, 0x00808890, 0x002A4A9A};
  return kPal[c < kColorCount ? c : kWhite];
}

void TextScreen::Rasterize(uint32_t* dst, int width, int height, int pitch_px, int scale) const {
  if (!dst || scale < 1) return;
  const int gw = kGlyphW * scale, gh = kGlyphH * scale;
  const int ox = std::max(0, (width - cols_ * gw) / 2);
  const int oy = std::max(0, (height - rows_ * gh) / 2);
  const uint32_t bg0 = RgbOf(kBlack);

  // Uma linha de pixels de cada vez, sempre escrevendo em ordem crescente (memoria de video).
  std::vector<uint32_t> line(static_cast<size_t>(width));
  for (int y = 0; y < height; ++y) {
    std::fill(line.begin(), line.end(), bg0);
    const int ry = y - oy;
    if (ry >= 0 && ry < rows_ * gh) {
      const int row = ry / gh, gy = (ry % gh) / scale;
      for (int col = 0; col < cols_; ++col) {
        const Cell& c = cells_[static_cast<size_t>(row) * cols_ + col];
        const uint32_t fg = RgbOf(static_cast<Color>(c.fg)), bg = RgbOf(static_cast<Color>(c.bg));
        const uint8_t bits = kFont8x16[(static_cast<unsigned char>(c.ch) - kFirstGlyph) * kGlyphH + gy];
        uint32_t* p = line.data() + ox + col * gw;
        if (ox + (col + 1) * gw > width) break;
        for (int gx = 0; gx < kGlyphW; ++gx) {
          const uint32_t px = (bits & (0x80 >> gx)) ? fg : bg;
          for (int s = 0; s < scale; ++s) *p++ = px;
        }
      }
    }
    std::copy(line.begin(), line.end(), dst + static_cast<size_t>(y) * pitch_px);
  }
}

void TextScreen::DumpText(std::FILE* out) const {
  int last = rows_ - 1;
  while (last > 0 && RowText(last).empty()) --last;
  std::fputc('\n', out);
  for (int y = 0; y <= last; ++y) std::fprintf(out, "%s\n", RowText(y).c_str());
  std::fflush(out);
}

}  // namespace dps3
