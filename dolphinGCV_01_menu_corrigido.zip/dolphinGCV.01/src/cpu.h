// DolphinGC V.01 - fase 3: interpretador do Gekko (PowerPC 750CXe, 32 bits).
//
// Implementado: aritmetica/logica inteira (com carry/overflow/Rc), rotacoes,
// comparacoes, branches (b/bc/bclr/bcctr), load/store inteiro (+ update,
// indexado, lmw/stmw, byte-reverse), operacoes de CR, SPRs (LR/CTR/XER e um
// banco generico para HID/GQR/BAT/etc.) e time base aproximado.
// FPU escalar, Paired Singles e MMU/BAT (Fase 7): aritmetica simples/dupla,
// conversoes inteiras (fctiw/fctiwz), arredondamento FPSCR, aproximacoes HW
// (fres/frsqrte), SIMD paired singles (ps_*/psq_*) e traducao BAT (IBAT/DBAT).
#pragma once
#include <cstdint>

#include "memory.h"

namespace dps3 {

enum class StopReason {
  Running,        // instrucao executada normalmente
  Syscall,        // 'sc' executado (pc ja aponta para a proxima instrucao)
  Unimplemented,  // opcode ainda nao suportado (pc NAO avanca; veja last_instr)
  MemFault,       // acesso a endereco nao mapeado (veja fault_addr)
  StepLimit,      // Run() atingiu o limite de passos
  Cancelled       // o usuario cancelou (RunSystem, pelo callback de progresso)
};

enum class Exception : uint8_t { None, ExternalInterrupt, Alignment, Program, SystemCall, FloatingPointUnavailable };

const char* StopReasonName(StopReason r);

class Cpu {
 public:
  explicit Cpu(Memory& mem) : mem_(mem) { Reset(0); }

  void Reset(uint32_t entry);
  StopReason Step();
  StopReason Run(uint64_t max_steps);

  uint64_t steps() const { return steps_; }
  // Time base: o Gekko incrementa o TB a cada 12 ciclos de CPU. Aqui assumimos
  // ~1 ciclo por instrucao (aproximacao; nao e contagem de ciclos real).
  uint64_t time_base() const { return steps_ / 12; }

  uint32_t gpr[32];
  double fpr[32];   // ps0 de cada registrador (double)
  float ps1_[32];   // ps1 de cada registrador (slot separado; nao compartilha bits com fpr)
  uint32_t fpscr = 0;
  uint32_t pc = 0, lr = 0, ctr = 0, cr = 0, xer = 0, msr = 0;
  uint32_t fault_addr = 0;  // valido apos MemFault
  uint32_t last_instr = 0;  // ultima instrucao buscada
  uint32_t srr0 = 0, srr1 = 0;
  uint32_t dar = 0, dsisr = 0;
  Exception last_exception = Exception::None;
  void RequestExternalInterrupt() { external_interrupt_pending_ = true; }
  void ClearExternalInterrupt() { external_interrupt_pending_ = false; }
  bool external_interrupt_pending() const { return external_interrupt_pending_; }
  void RaiseException(Exception type, uint32_t fault_address = 0, uint32_t syndrome = 0);

  // Paired Singles (Gekko SIMD): ps0 (high 32 bits / double slot) e ps1 (low 32 bits)
  float ps0(unsigned idx) const;
  float ps1(unsigned idx) const;
  void set_ps0(unsigned idx, float val);
  void set_ps1(unsigned idx, float val);
  void set_ps(unsigned idx, float v0, float v1);

 private:
  uint32_t ReadSpr(uint32_t n) const;
  void WriteSpr(uint32_t n, uint32_t v);
  void SetCrField(unsigned field, unsigned bits4);
  unsigned So() const { return (xer >> 31) & 1; }
  void SetCa(bool ca) { xer = (xer & ~0x20000000u) | (ca ? 0x20000000u : 0); }
  bool Ca() const { return (xer & 0x20000000u) != 0; }
  void RecordCr0(uint32_t result);
  void CmpS(unsigned field, int32_t x, int32_t y);
  void CmpU(unsigned field, uint32_t x, uint32_t y);
  bool CrBit(unsigned bi) const { return (cr >> (31 - bi)) & 1; }
  bool BranchCondition(uint32_t bo, uint32_t bi);
  bool Load(uint32_t ea, unsigned size, bool sign, uint32_t& v);
  bool Store(uint32_t ea, unsigned size, uint32_t v);
  bool CheckAlignment(uint32_t ea, unsigned size);
  void ReturnFromInterrupt();
  bool IrEnabled() const { return (msr & (1u << 5)) != 0; }
  bool DrEnabled() const { return (msr & (1u << 4)) != 0; }
  void ApplyFpscrRounding() const;
  static float ApproxRecip(float x);
  static float ApproxRsqrt(float x);
  StopReason ExecArith(uint32_t inst);
  StopReason ExecOp19(uint32_t inst, uint32_t& next);
  StopReason ExecOp31(uint32_t inst);
  StopReason ExecFloating(uint32_t inst, uint32_t op);
  StopReason ExecPairedSingles(uint32_t inst);
  StopReason ExecQuantizedLoadStore(uint32_t inst, uint32_t op);
  float Dequantize(uint32_t raw, uint8_t type, uint8_t scale) const;
  uint32_t Quantize(float val, uint8_t type, uint8_t scale) const;

  Memory& mem_;
  uint64_t steps_ = 0;
  uint32_t spr_[1024];
  bool external_interrupt_pending_ = false;
  bool exception_taken_this_step_ = false;
  bool reserve_valid_ = false;     // reserva de lwarx/stwcx.
  uint32_t reserve_addr_ = 0;
};

}  // namespace dps3
