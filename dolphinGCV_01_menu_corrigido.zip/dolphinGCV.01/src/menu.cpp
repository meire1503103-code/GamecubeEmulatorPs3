#include "menu.h"

#include <cstdio>

namespace dps3 {

bool MenuSystem::Init() {
  items_.clear();
  selected_ = 0;
  has_back_ = false;
  title_ = "DOLPHINGC V.01 - MENU PRINCIPAL";
  // Os programas de demonstracao vem primeiro: funcionam sem nenhum jogo na pasta DolphinGC.
  AddItem("Hello World (programa PowerPC na CPU emulada)", MENU_ACTION_HELLO);
  AddItem("Calculadora (contas feitas pela CPU emulada)", MENU_ACTION_CALC);
  AddItem("Rodar Mario Kart Double Dash (pasta DolphinGC)", MENU_ACTION_LOAD_MKDD);
  AddItem("Carregar outro jogo / ISO (GameCube)", MENU_ACTION_LOAD_ISO);
  AddItem("Listar FST do Disco (File System)", MENU_ACTION_LIST_FST);
  AddItem("Ver controles (PS3 -> GameCube)", MENU_ACTION_CONTROLS);
  AddItem("Informacoes do Sistema / Versao", MENU_ACTION_INFO);
  AddItem("Sair", MENU_ACTION_EXIT);
  return true;
}

void MenuSystem::SetItems(const std::vector<MenuItem>& items, const std::string& title) {
  items_ = items;
  title_ = title;
  selected_ = 0;
  has_back_ = false;
}

void MenuSystem::AddItem(const std::string& label, int action_id) {
  items_.push_back(MenuItem{label, action_id});
}

void MenuSystem::RenderConsole(std::FILE* out) const {
  std::fprintf(out, "\n========================================\n");
  std::fprintf(out, "  %s\n", title_.c_str());
  std::fprintf(out, "========================================\n");
  for (size_t i = 0; i < items_.size(); ++i) {
    std::fprintf(out, " %s[%d] %s\n", static_cast<int>(i) == selected_ ? "> " : "  ",
                 static_cast<int>(i), items_[i].label.c_str());
  }
  std::fprintf(out, "========================================\n");
  std::fflush(out);
}

std::string MenuSystem::DefaultFooter() {
  return "D-Pad/Analogico: mover   X ou Start: confirmar   Bolinha: voltar";
}

void MenuSystem::RenderScreen(TextScreen& screen, const std::string& footer) const {
  screen.Clear();
  screen.PutCentered(0, title_, kCyan);
  screen.HLine(1);
  const int n = static_cast<int>(items_.size());
  const int top = 3, bottom = screen.rows() - 3;           // area dos itens (inclusive)
  const int visible = bottom - top + 1 > 1 ? bottom - top + 1 : 1;
  int first = 0;                                           // rolagem: mantem o cursor a vista
  if (n > visible) {
    first = selected_ - visible / 2;
    if (first < 0) first = 0;
    if (first > n - visible) first = n - visible;
  }
  for (int row = 0; row < visible && first + row < n; ++row) {
    const int i = first + row, y = top + row;
    const bool sel = i == selected_;
    if (sel) screen.FillRow(y, kBlue);
    char head[32];
    std::snprintf(head, sizeof head, " %s[%d] ", sel ? "> " : "  ", i);
    screen.Put(1, y, std::string(head) + items_[i].label, sel ? kYellow : kWhite, sel ? kBlue : kBlack);
  }
  if (first > 0) screen.Put(screen.cols() - 3, top, "^", kGray);
  if (first + visible < n) screen.Put(screen.cols() - 3, bottom, "v", kGray);
  screen.HLine(screen.rows() - 2);
  screen.PutCentered(screen.rows() - 1, footer, kGray);
}

int MenuSystem::Handle(MenuInput in) {
  const int n = static_cast<int>(items_.size());
  switch (in) {
    case MenuInput::Up:
      if (n) selected_ = (selected_ + n - 1) % n;
      return -1;
    case MenuInput::Down:
      if (n) selected_ = (selected_ + 1) % n;
      return -1;
    case MenuInput::Confirm:
      return SelectOption(selected_);
    case MenuInput::Back:
      return has_back_ ? back_action_ : -1;
    case MenuInput::Left:
    case MenuInput::Right:
    case MenuInput::None:
      break;
  }
  return -1;
}

int MenuSystem::SelectOption(int choice) const {
  if (choice < 0 || choice >= static_cast<int>(items_.size())) return -1;
  return items_[choice].action_id;
}

MenuInput MenuInputFromPad(const Ps3PadState& prev, const Ps3PadState& cur) {
  // Analogico esquerdo conta como direcional, com histerese simples (>= 64 do centro).
  const bool prev_up = prev.dpad_up || prev.left_stick_y <= 64;
  const bool prev_down = prev.dpad_down || prev.left_stick_y >= 192;
  const bool cur_up = cur.dpad_up || cur.left_stick_y <= 64;
  const bool cur_down = cur.dpad_down || cur.left_stick_y >= 192;

  const bool prev_left = prev.dpad_left || prev.left_stick_x <= 64;
  const bool prev_right = prev.dpad_right || prev.left_stick_x >= 192;
  const bool cur_left = cur.dpad_left || cur.left_stick_x <= 64;
  const bool cur_right = cur.dpad_right || cur.left_stick_x >= 192;

  if (cur_up && !prev_up) return MenuInput::Up;
  if (cur_down && !prev_down) return MenuInput::Down;
  if (cur_left && !prev_left) return MenuInput::Left;
  if (cur_right && !prev_right) return MenuInput::Right;
  if ((cur.cross && !prev.cross) || (cur.start && !prev.start)) return MenuInput::Confirm;
  if (cur.circle && !prev.circle) return MenuInput::Back;
  return MenuInput::None;
}

MenuInput PadRepeater::Update(const Ps3PadState& cur, uint32_t now_ms) {
  const Ps3PadState prev = prev_;
  prev_ = cur;
  const MenuInput edge = MenuInputFromPad(prev, cur);
  const bool directional = edge == MenuInput::Up || edge == MenuInput::Down ||
                           edge == MenuInput::Left || edge == MenuInput::Right;
  if (edge != MenuInput::None) {
    held_ = directional ? edge : MenuInput::None;
    next_ms_ = now_ms + delay_;
    return edge;
  }
  if (held_ == MenuInput::None) return MenuInput::None;
  // Ainda segurando o mesmo sentido? (compara contra um pad neutro: so o sentido importa)
  const Ps3PadState neutral;
  Ps3PadState probe = cur;
  if (MenuInputFromPad(neutral, probe) != held_) { held_ = MenuInput::None; return MenuInput::None; }
  if (now_ms >= next_ms_) { next_ms_ = now_ms + rate_; return held_; }
  return MenuInput::None;
}

// Existe um unico perfil (GameCube); as funcoes ficam para o menu continuar igual.
ControllerProfile NextProfile(ControllerProfile) { return ControllerProfile::GameCube; }
ControllerProfile PrevProfile(ControllerProfile) { return ControllerProfile::GameCube; }

void RenderControlsScreen(ControllerProfile p, std::FILE* out) {
  std::fprintf(out, "\n========================================\n");
  std::fprintf(out, "  CONTROLES - perfil: %s\n", ProfileName(p));
  std::fprintf(out, "========================================\n");
  std::fputs(DescribeMapping(p).c_str(), out);
  std::fprintf(out, "========================================\n");
  std::fprintf(out, "  Bolinha: voltar\n");
  std::fflush(out);
}

void RenderControlsScreen(ControllerProfile p, TextScreen& screen) {
  screen.Clear();
  screen.PutCentered(0, std::string("CONTROLES - perfil: ") + ProfileName(p), kCyan);
  screen.HLine(1);
  const std::string text = DescribeMapping(p);
  int y = 3;
  size_t pos = 0;
  while (pos < text.size() && y < screen.rows() - 3) {
    size_t nl = text.find('\n', pos);
    if (nl == std::string::npos) nl = text.size();
    screen.Put(2, y++, text.substr(pos, nl - pos));
    pos = nl + 1;
  }
  screen.HLine(screen.rows() - 2);
  screen.PutCentered(screen.rows() - 1, "Bolinha: voltar", kGray);
}

} // namespace dps3
