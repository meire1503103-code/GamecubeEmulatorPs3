#include "mmio.h"

#include <algorithm>
#include <cstring>
#include <vector>

#include "disc.h"

namespace dps3 {
namespace {

// Offsets dentro da janela MMIO (fisico 0x0C00xxxx).
enum : uint32_t {
  VI_DISPINT0 = 0x2030, VI_DISPINT3 = 0x203C,
  DSP_MAIL_FROM = 0x5004,
  PI_INTSR = 0x3000, PI_INTMSR = 0x3004, PI_REV = 0x302C,
  DI_SR = 0x6000, DI_CMD0 = 0x6008, DI_CMD1 = 0x600C, DI_CMD2 = 0x6010,
  DI_MAR = 0x6014, DI_LEN = 0x6018, DI_CR = 0x601C,
  SI_OUT0 = 0x6400, SI_INH = 0x6404, SI_INL = 0x6408,
  SI_COMCSR = 0x6434, SI_SR = 0x6438, SI_BUF = 0x6480
};

constexpr uint32_t kDiMaskBits = 0x2A;  // DEINTMASK(1) | TCINTMASK(3) | BRKINTMASK(5)
constexpr uint32_t kDiIntBits = 0x54;   // DEINT(2) | TCINT(4) | BRKINT(6)
constexpr uint32_t kDiTcInt = 0x10;
constexpr uint32_t kSiTcInt = 0x80000000u, kSiTcIntMask = 0x40000000u, kSiStart = 1u;
constexpr uint32_t kSiRdst0 = 0x20000000u;
constexpr uint32_t kViInt = 0x80000000u, kViEnable = 0x10000000u;

uint32_t RdBE(const uint8_t* p, unsigned n) {
  uint32_t v = 0;
  for (unsigned i = 0; i < n; ++i) v = (v << 8) | p[i];
  return v;
}
void WrBE(uint8_t* p, unsigned n, uint32_t v) {
  for (unsigned i = 0; i < n; ++i) p[i] = static_cast<uint8_t>(v >> (8 * (n - 1 - i)));
}

}  // namespace

MmioHandler::MmioHandler() { Reset(); }

void MmioHandler::Reset() {
  std::memset(raw_, 0, sizeof raw_);
  Set32(PI_REV, 0x246500B1u);       // revisao do chip (valor tipico de hardware de varejo)
  Set32(DSP_MAIL_FROM, 0x8071FEEDu);  // mailbox DSP->CPU inicial
  pi_cause_ = pi_mask_ = 0;
  frame_steps_ = frames_ = dvd_reads_ = dvd_bytes_ = dvd_errors_ = accesses_ = 0;
}

uint32_t MmioHandler::Get32(uint32_t off) const { return RdBE(raw_ + off, 4); }
void MmioHandler::Set32(uint32_t off, uint32_t v) { WrBE(raw_ + off, 4, v); }

uint32_t MmioHandler::PadInH() const {
  const uint32_t buttons = static_cast<uint32_t>(pad_.buttons) | 0x0080u;  // bit fixo "1" do protocolo
  return (buttons << 16) | (uint32_t(pad_.main_stick_x) << 8) | pad_.main_stick_y;
}
uint32_t MmioHandler::PadInL() const {
  return (uint32_t(pad_.c_stick_x) << 24) | (uint32_t(pad_.c_stick_y) << 16) |
         (uint32_t(pad_.trigger_l) << 8) | pad_.trigger_r;
}

void MmioHandler::RefreshDiIrq() {
  const uint32_t sr = Get32(DI_SR);
  const bool irq = ((sr & 0x2) && (sr & 0x4)) || ((sr & 0x8) && (sr & 0x10)) || ((sr & 0x20) && (sr & 0x40));
  SetPiBit(PI_INT_DI, irq);
}
void MmioHandler::RefreshSiIrq() {
  const uint32_t cs = Get32(SI_COMCSR);
  SetPiBit(PI_INT_SI, (cs & kSiTcInt) && (cs & kSiTcIntMask));
}
void MmioHandler::RefreshViIrq() {
  bool irq = false;
  for (uint32_t off = VI_DISPINT0; off <= VI_DISPINT3; off += 4) {
    const uint32_t v = Get32(off);
    if ((v & kViInt) && (v & kViEnable)) irq = true;
  }
  SetPiBit(PI_INT_VI, irq);
}

void MmioHandler::ExecuteDiCommand() {
  const uint32_t cmd0 = Get32(DI_CMD0), cmd1 = Get32(DI_CMD1), mar = Get32(DI_MAR);
  uint32_t len = Get32(DI_LEN);
  if (len == 0) len = Get32(DI_CMD2);
  const uint32_t op = cmd0 >> 24;
  bool ok = true;
  if (op == 0xA8 || op == 0x12) {
    ++dvd_reads_;
    if (!mem_ || len > kMem1Size) {
      ok = false;
    } else {
      std::vector<uint8_t> buf(len, 0);
      if (op == 0xA8 && disc_) {
        const uint64_t offset = static_cast<uint64_t>(cmd1) << 2;  // DI GameCube: offset em palavras
        if (offset < disc_->size()) {
          const size_t avail = static_cast<size_t>(std::min<uint64_t>(len, disc_->size() - offset));
          if (!disc_->Read(offset, buf.data(), avail)) ok = false;
        }  // alem do fim da imagem: zeros (ISOs cortadas)
      }
      if (ok && len && !mem_->WriteBlock(0x80000000u | (mar & 0x01FFFFFFu), buf.data(), len)) ok = false;
      if (ok) dvd_bytes_ += len;
    }
  }  // outros comandos (seek, parar motor...): concluem sem efeito
  if (!ok) ++dvd_errors_;
  Set32(DI_CR, Get32(DI_CR) & ~1u);  // TSTART volta a 0
  Set32(DI_LEN, 0);
  Set32(DI_SR, Get32(DI_SR) | kDiTcInt);
  RefreshDiIrq();
}

void MmioHandler::ExecuteSiTransfer() {
  const uint32_t cmd = Get32(SI_OUT0) >> 24;
  if (cmd == 0x00 || cmd == 0xFF) {
    Set32(SI_BUF, 0x09000000u);  // ID de controle padrao
  } else if (cmd == 0x40 || cmd == 0x41 || cmd == 0x42) {
    Set32(SI_BUF, PadInH() & 0x3FFFFFFFu);
    Set32(SI_BUF + 4, PadInL());
  }
  Set32(SI_COMCSR, (Get32(SI_COMCSR) & ~kSiStart) | kSiTcInt);
  RefreshSiIrq();
}

bool MmioHandler::MmioRead(uint32_t phys, unsigned size, uint32_t& value) {
  if (phys < kMmioBase) return false;
  const uint32_t off = phys - kMmioBase;
  if (static_cast<uint64_t>(off) + size > kMmioSize) return false;
  ++accesses_;
  if (size == 4 && (off & 3) == 0) {
    switch (off) {
      case PI_INTSR: value = pi_cause_; return true;
      case PI_INTMSR: value = pi_mask_; return true;
      case SI_INH:
        Set32(SI_SR, Get32(SI_SR) & ~kSiRdst0);  // ler os dados limpa "novo dado"
        value = PadInH() & 0x3FFFFFFFu;
        return true;
      case SI_INL: value = PadInL(); return true;
      default: break;
    }
  }
  value = RdBE(raw_ + off, size);
  return true;
}

bool MmioHandler::MmioWrite(uint32_t phys, unsigned size, uint32_t value) {
  if (phys < kMmioBase) return false;
  const uint32_t off = phys - kMmioBase;
  if (static_cast<uint64_t>(off) + size > kMmioSize) return false;
  ++accesses_;
  if (size == 4 && (off & 3) == 0) {
    switch (off) {
      case PI_INTSR: pi_cause_ &= ~value; return true;   // escrever 1 limpa
      case PI_INTMSR: pi_mask_ = value; return true;
      case DI_SR: {
        uint32_t sr = Get32(DI_SR);
        sr &= ~(value & kDiIntBits);                      // 1 limpa a interrupcao
        sr = (sr & ~kDiMaskBits) | (value & kDiMaskBits);  // mascaras sao gravaveis
        Set32(DI_SR, sr);
        RefreshDiIrq();
        return true;
      }
      case DI_CR:
        Set32(DI_CR, value & 7u);
        if (value & 1u) ExecuteDiCommand();
        return true;
      case SI_COMCSR: {
        uint32_t cs = Get32(SI_COMCSR);
        if (value & kSiTcInt) cs &= ~kSiTcInt;            // 1 limpa TCINT
        cs = (cs & kSiTcInt) | (value & 0x7FFFFFFEu);
        Set32(SI_COMCSR, cs);
        if (value & kSiStart) ExecuteSiTransfer(); else RefreshSiIrq();
        return true;
      }
      default:
        if (off >= VI_DISPINT0 && off <= VI_DISPINT3) {
          const uint32_t old = Get32(off);
          Set32(off, (old & value & kViInt) | (value & ~kViInt));  // escrever 0 em bit 31 limpa
          RefreshViIrq();
          return true;
        }
        break;
    }
  }
  WrBE(raw_ + off, size, value);
  return true;
}

void MmioHandler::OnVerticalRetrace() {
  ++frames_;
  for (uint32_t off = VI_DISPINT0; off <= VI_DISPINT3; off += 4) {
    const uint32_t v = Get32(off);
    if (v & kViEnable) Set32(off, v | kViInt);
  }
  RefreshViIrq();
  Set32(SI_SR, Get32(SI_SR) | kSiRdst0);  // novo dado do controle disponivel a cada quadro
}

void MmioHandler::Tick(uint64_t cpu_steps) {
  frame_steps_ += cpu_steps;
  while (frame_steps_ >= kStepsPerFrame) {
    frame_steps_ -= kStepsPerFrame;
    OnVerticalRetrace();
  }
}

}  // namespace dps3
