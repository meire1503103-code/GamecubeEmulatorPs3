#include "system.h"

#include <algorithm>

namespace dps3 {

StopReason RunSystem(Cpu& cpu, MmioHandler& hw, uint64_t max_steps, PadSource pad) {
  constexpr uint64_t kChunk = 4096;
  uint64_t done = 0;
  while (done < max_steps) {
    const uint64_t n = std::min<uint64_t>(kChunk, max_steps - done);
    const StopReason r = cpu.Run(n);
    done += n;
    hw.Tick(n);
    if (pad) { GameCubePadState p; if (pad(p)) hw.SetPad(p); }
    if (hw.InterruptPending()) cpu.RequestExternalInterrupt(); else cpu.ClearExternalInterrupt();
    if (r != StopReason::StepLimit) return r;
  }
  return StopReason::StepLimit;
}

}  // namespace dps3
