// DolphinGC V.01 - Apploader do GameCube (executado de verdade na CPU emulada).
//
// O apploader fica no disco em 0x2440 (header de 0x20 bytes + imagem em 0x2460) e e carregado em
// 0x81200000. Fluxo (igual ao BS2 real / HLE do Dolphin):
//   entry(&init, &main, &close) -> init(OSReport) -> main(&dest,&size,&off) em laco, copiando
//   cada trecho do disco para a RAM, ate main devolver 0 -> close() devolve o entry do jogo.
#pragma once
#include <cstdint>
#include <string>

namespace dps3 {

class DiscReader;
class Memory;
class Cpu;

constexpr uint32_t kApploaderDiscOffset = 0x2440;
constexpr uint32_t kApploaderLoadAddr = 0x81200000u;

class Apploader {
 public:
  // Devolve true e o entry point do jogo em `game_entry`. Em erro, `err` descreve onde parou.
  bool LoadAndRun(DiscReader& disc, Memory& mem, Cpu& cpu, uint32_t& game_entry, std::string& err);

  // Diagnostico: quantos trechos o apploader pediu e quantos bytes copiou.
  unsigned chunks() const { return chunks_; }
  uint64_t bytes() const { return bytes_; }

 private:
  unsigned chunks_ = 0;
  uint64_t bytes_ = 0;
};

}  // namespace dps3
