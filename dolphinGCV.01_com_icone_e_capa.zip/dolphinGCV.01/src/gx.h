// DolphinGC V.01 - fase 11: Processador Gráfico (GX / FIFO & Command Processor)
#pragma once
#include <cstddef>
#include <cstdint>
#include <vector>

namespace dps3 {

class Memory;

class GraphicsProcessor {
public:
  bool Init();
  // Processa pacotes de comandos gráficos (Display Lists) enviados para a FIFO
  bool ProcessFifo(const uint8_t* data, size_t size, Memory& mem);
  // Registo de comandos GX básicos
  void WriteReg(uint8_t cmd, uint32_t value);
  uint32_t ReadReg(uint8_t cmd) const;

private:
  uint32_t fifo_base_ = 0;
  uint32_t fifo_end_ = 0;
  bool processing_ = false;
};

} // namespace dps3
