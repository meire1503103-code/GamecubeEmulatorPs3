// DolphinGC V.01 - menu principal (texto) navegavel pelo controle PS3 ou por numero (teclado/host).
#pragma once
#include <cstdio>
#include <string>
#include <vector>

#include "input.h"

namespace dps3 {

enum MenuAction {
  MENU_ACTION_EXIT = 0,
  MENU_ACTION_LOAD_ISO = 1,
  MENU_ACTION_LIST_FST = 2,
  MENU_ACTION_CONTROLS = 3,
  MENU_ACTION_INFO = 4,
  MENU_ACTION_LOAD_MKDD = 5
};

struct MenuItem {
  std::string label;
  int action_id;
};

// Evento de navegacao (independente de a origem ser o pad ou o teclado).
enum class MenuInput { None, Up, Down, Confirm, Back };

class MenuSystem {
public:
  bool Init();
  // Troca o conjunto de itens (cursor volta ao primeiro).
  void SetItems(const std::vector<MenuItem>& items, const std::string& title);
  void AddItem(const std::string& label, int action_id);

  // Imprime o menu em `out` (stdout / log.txt). O item selecionado leva o marcador "> ".
  void RenderConsole(std::FILE* out = stdout) const;

  // Navegacao: o cursor da a volta nas pontas. Confirm devolve o action_id do item
  // selecionado; Back devolve `back_action` (-1 = sem acao); outros devolvem -1.
  int Handle(MenuInput in);
  // Selecao direta pelo numero mostrado na tela (0-based); -1 se invalido.
  int SelectOption(int choice) const;

  int selected() const { return selected_; }
  void set_back_action(int action_id, bool enabled) { back_action_ = action_id; has_back_ = enabled; }
  const std::string& title() const { return title_; }
  const std::vector<MenuItem>& items() const { return items_; }

private:
  std::vector<MenuItem> items_;
  std::string title_ = "DOLPHINGC V.01 - MENU PRINCIPAL";
  int selected_ = 0;
  int back_action_ = -1;
  bool has_back_ = false;
};

// Converte o estado do pad em um evento de menu, so na BORDA (apertou agora e nao estava
// apertado no quadro anterior), para nao pular varios itens por quadro. Cruz/Start = confirma,
// Bolinha = volta, D-Pad ou analogico esquerdo = cima/baixo.
MenuInput MenuInputFromPad(const Ps3PadState& prev, const Ps3PadState& cur);

// Tela de "Configurar controles": ciclo entre os perfis e mostra o mapeamento ativo.
ControllerProfile NextProfile(ControllerProfile p);
ControllerProfile PrevProfile(ControllerProfile p);
void RenderControlsScreen(ControllerProfile p, std::FILE* out = stdout);

} // namespace dps3
