#include "menu.h"

#include <cstdio>

namespace dps3 {

bool MenuSystem::Init() {
  items_.clear();
  selected_ = 0;
  has_back_ = false;
  title_ = "DOLPHINGC V.01 - MENU PRINCIPAL";
  AddItem("Rodar Mario Kart Double Dash (pasta DolphinGC)", MENU_ACTION_LOAD_MKDD);
  AddItem("Carregar outro jogo / ISO (GameCube)", MENU_ACTION_LOAD_ISO);
  AddItem("Listar FST do Disco (File System)", MENU_ACTION_LIST_FST);
  AddItem("Ver controles (PS3 -> GameCube)", MENU_ACTION_CONTROLS);
  AddItem("Informacoes do Sistema / Versao", MENU_ACTION_INFO);
  AddItem("Sair / Desligar", MENU_ACTION_EXIT);
  return true;
}

void MenuSystem::SetItems(const std::vector<MenuItem>& items, const std::string& title) {
  items_ = items;
  title_ = title;
  selected_ = 0;
  has_back_ = false;
}

void MenuSystem::AddItem(const std::string& label, int action_id) {
  items_.push_back(MenuItem{label, action_id});
}

void MenuSystem::RenderConsole(std::FILE* out) const {
  std::fprintf(out, "\n========================================\n");
  std::fprintf(out, "  %s\n", title_.c_str());
  std::fprintf(out, "========================================\n");
  for (size_t i = 0; i < items_.size(); ++i) {
    std::fprintf(out, " %s[%d] %s\n", static_cast<int>(i) == selected_ ? "> " : "  ",
                 static_cast<int>(i), items_[i].label.c_str());
  }
  std::fprintf(out, "========================================\n");
  std::fflush(out);
}

int MenuSystem::Handle(MenuInput in) {
  const int n = static_cast<int>(items_.size());
  switch (in) {
    case MenuInput::Up:
      if (n) selected_ = (selected_ + n - 1) % n;
      return -1;
    case MenuInput::Down:
      if (n) selected_ = (selected_ + 1) % n;
      return -1;
    case MenuInput::Confirm:
      return SelectOption(selected_);
    case MenuInput::Back:
      return has_back_ ? back_action_ : -1;
    case MenuInput::None:
      break;
  }
  return -1;
}

int MenuSystem::SelectOption(int choice) const {
  if (choice < 0 || choice >= static_cast<int>(items_.size())) return -1;
  return items_[choice].action_id;
}

MenuInput MenuInputFromPad(const Ps3PadState& prev, const Ps3PadState& cur) {
  // Analogico esquerdo conta como direcional, com histerese simples (>= 64 do centro).
  const bool prev_up = prev.dpad_up || prev.left_stick_y <= 64;
  const bool prev_down = prev.dpad_down || prev.left_stick_y >= 192;
  const bool cur_up = cur.dpad_up || cur.left_stick_y <= 64;
  const bool cur_down = cur.dpad_down || cur.left_stick_y >= 192;

  if (cur_up && !prev_up) return MenuInput::Up;
  if (cur_down && !prev_down) return MenuInput::Down;
  if ((cur.cross && !prev.cross) || (cur.start && !prev.start)) return MenuInput::Confirm;
  if (cur.circle && !prev.circle) return MenuInput::Back;
  return MenuInput::None;
}

// Existe um unico perfil (GameCube); as funcoes ficam para o menu continuar igual.
ControllerProfile NextProfile(ControllerProfile) { return ControllerProfile::GameCube; }
ControllerProfile PrevProfile(ControllerProfile) { return ControllerProfile::GameCube; }

void RenderControlsScreen(ControllerProfile p, std::FILE* out) {
  std::fprintf(out, "\n========================================\n");
  std::fprintf(out, "  CONTROLES - perfil: %s\n", ProfileName(p));
  std::fprintf(out, "========================================\n");
  std::fputs(DescribeMapping(p).c_str(), out);
  std::fprintf(out, "========================================\n");
  std::fprintf(out, "  Bolinha: voltar\n");
  std::fflush(out);
}

} // namespace dps3
