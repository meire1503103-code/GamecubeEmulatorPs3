// DolphinGC V.01 - emulador SOMENTE de GameCube para PS3 (em desenvolvimento).
// Foco do V.01: Mario Kart: Double Dash!! (GM4E / GM4P / GM4J).
// Jogos ficam na pasta DolphinGC (PS3: /dev_hdd0/DolphinGC; PC: ./DolphinGC).
// Ainda NAO ha MMIO, GPU, DSP, audio nem input: o boot roda ate a primeira instrucao
// nao implementada ou acesso a memoria nao mapeada (normalmente os registradores de
// hardware em 0xCC00xxxx) e mostra onde parou.
//
// Build PS3: adicionar src/*.cpp ao Makefile PSL1GHT do projeto e definir
// -DDOLPHINPS3_PLATFORM_PS3. Sem essa macro compila como host (g++) para testes.
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <dirent.h>
#include <fstream>
#include <sstream>
#include <sys/stat.h>
#include <string>
#include <vector>
#ifdef DOLPHINPS3_PLATFORM_PS3
#include <unistd.h>
#endif

#include "args.h"
#include "boot.h"
#include "cpu.h"
#include "disc.h"
#include "dol.h"
#include "fst.h"
#include "input.h"
#include "memory.h"
#include "menu.h"
#include "mmio.h"
#include "system.h"

namespace {

constexpr const char* kVersion = "DolphinGC V.01 (somente GameCube; alvo: Mario Kart Double Dash)";

// Fonte do controle para o jogo: no PS3 le o pad (libpad) e converte para GameCube.
bool GamePadSource(dps3::GameCubePadState& out) {
#ifdef DOLPHINPS3_PLATFORM_PS3
  dps3::Ps3PadState ps3;
  if (!dps3::PadPoll(ps3)) return false;
  out = dps3::MapPs3ToGameCube(ps3);
  return true;
#else
  (void)out;
  return false;
#endif
}

// Limite de seguranca do primeiro boot (instrucoes interpretadas).
constexpr uint64_t kMaxBootSteps = 50000000ull;

#ifdef DOLPHINPS3_PLATFORM_PS3
// PS3 nao tem linha de comando nem console visivel. Ao instalar o .pkg, o app
// fica em /dev_hdd0/game/DGCV00001/USRDIR/ (mesmo ID do sfo.xml/Makefile).
//  - args.txt : mesmos argumentos da CLI, ex.:  /dev_hdd0/DolphinGC/jogo.iso
//  - log.txt  : tudo que o programa imprimiria (stdout/stderr) vai para este arquivo
constexpr const char* kArgsFile = "/dev_hdd0/game/DGCV00001/USRDIR/args.txt";
constexpr const char* kLogFile = "/dev_hdd0/game/DGCV00001/USRDIR/log.txt";

void RedirectOutputToLog() {
  // Trunca uma vez e abre stdout/stderr em modo append (evita um sobrescrever o outro).
  if (std::FILE* t = std::fopen(kLogFile, "w")) std::fclose(t);
  std::freopen(kLogFile, "a", stdout);
  std::freopen(kLogFile, "a", stderr);
  std::setvbuf(stdout, nullptr, _IONBF, 0);  // sem buffer: o log sobrevive a um travamento
  std::setvbuf(stderr, nullptr, _IONBF, 0);
}
#endif

std::vector<std::string> CollectArgs(int argc, char** argv) {
  std::vector<std::string> a;
#ifdef DOLPHINPS3_PLATFORM_PS3
  (void)argc; (void)argv;
  std::ifstream in(kArgsFile);
  if (in) {
    std::stringstream ss;
    ss << in.rdbuf();
    a = dps3::TokenizeArgsText(ss.str());
  }
#else
  for (int i = 1; i < argc; ++i) a.push_back(argv[i]);
#endif
  return a;
}


// Pasta onde ficam os jogos: DolphinGC. No PS3 fica em /dev_hdd0; no PC, ao lado do programa.
#ifdef DOLPHINPS3_PLATFORM_PS3
constexpr const char* kIsoDir = "/dev_hdd0/DolphinGC";
#else
constexpr const char* kIsoDir = "DolphinGC";
#endif

// Cria a pasta DolphinGC se ainda nao existir (para o usuario so copiar os jogos para la).
void EnsureGameDir() {
#ifdef DOLPHINPS3_PLATFORM_PS3
  mkdir(kIsoDir, 0777);
#else
  mkdir(kIsoDir, 0777);
#endif
}

bool HasDiscExtension(const std::string& name) {
  const size_t dot = name.rfind('.');
  if (dot == std::string::npos) return false;
  std::string ext = name.substr(dot);
  std::transform(ext.begin(), ext.end(), ext.begin(), [](unsigned char c) { return std::tolower(c); });
  return ext == ".iso" || ext == ".gcm";
}

std::vector<std::string> ListDiscs(const std::string& dir) {
  std::vector<std::string> out;
  if (DIR* d = opendir(dir.c_str())) {
    while (const dirent* e = readdir(d)) {
      const std::string name = e->d_name;
      if (HasDiscExtension(name)) out.push_back(dir + "/" + name);
    }
    closedir(d);
  }
  std::sort(out.begin(), out.end());
  return out;
}

// Le o proximo evento de menu. No PS3 consulta o pad (com borda); no host le uma linha do
// teclado: numero = escolhe o item, "w"/"s" = cima/baixo, vazio = confirma, "b" = voltar.
// Devolve false quando nao ha mais entrada (EOF no host) -> o chamador deve sair do menu.
bool ReadMenuInput(dps3::MenuSystem& menu, dps3::Ps3PadState& prev, dps3::MenuInput& ev,
                   int& direct_choice) {
  direct_choice = -1;
  ev = dps3::MenuInput::None;
#ifdef DOLPHINPS3_PLATFORM_PS3
  (void)menu;
  for (;;) {
    dps3::Ps3PadState cur;
    if (dps3::PadPoll(cur)) {
      ev = dps3::MenuInputFromPad(prev, cur);
      prev = cur;
      if (ev != dps3::MenuInput::None) return true;
    }
    usleep(16000);
  }
#else
  (void)prev;
  char line[64];
  std::printf("> ");
  std::fflush(stdout);
  if (!std::fgets(line, sizeof line, stdin)) return false;
  if (line[0] == 'w') ev = dps3::MenuInput::Up;
  else if (line[0] == 's') ev = dps3::MenuInput::Down;
  else if (line[0] == 'b') ev = dps3::MenuInput::Back;
  else if (line[0] == '\n') ev = dps3::MenuInput::Confirm;
  else if (line[0] >= '0' && line[0] <= '9') direct_choice = std::atoi(line);
  else return ReadMenuInput(menu, prev, ev, direct_choice);  // entrada invalida: pergunta de novo
  return true;
#endif
}

// Carrega e (opcionalmente) lista a FST / executa o boot de um disco. Devolve o codigo de saida.
int RunTarget(const std::string& target, bool list_files) {
  std::string err;
  dps3::DiscReader disc;
  if (!disc.Open(target, err)) {
    std::fprintf(stderr, "erro ao abrir disco: %s\n", err.c_str());
    return 1;
  }
  std::printf("Console : %s\nGame ID : %s\nTitulo  : %s\nDisco   : %u  Versao: %u\nTamanho : %llu bytes\n",
              dps3::KindName(disc.kind()), disc.game_id().c_str(), disc.title().c_str(),
              disc.disc_number(), disc.version(),
              static_cast<unsigned long long>(disc.size()));
  if (dps3::IsMarioKartDoubleDash(disc.game_id()))
    std::printf("Alvo    : Mario Kart: Double Dash!! detectado (regiao %c)\n", disc.game_id()[3]);

  if (list_files) {
    dps3::GameCubeFst fst;
    std::string fst_error;
    if (!fst.Load(disc, fst_error)) {
      std::fprintf(stderr, "Erro ao carregar FST: %s\n", fst_error.c_str());
      return 1;
    }
    std::printf("\n=== GAMECUBE FILE SYSTEM ===\n");
    for (const auto& entry : fst.entries()) {
      if (entry.type == dps3::FstEntryType::Directory) {
        std::printf("[DIR]  %s\n", entry.path.c_str());
      } else {
        std::printf("[FILE] %s | Offset: %llu | Size: %llu\n", entry.path.c_str(),
                    static_cast<unsigned long long>(entry.offset),
                    static_cast<unsigned long long>(entry.size));
      }
    }
    std::printf("\nTotal de entradas: %lu\n", static_cast<unsigned long>(fst.entries().size()));
    return 0;
  }

  // ---- boot: apploader real (preferido) ou, se falhar, DOL direto ----
  dps3::Memory mem;
  if (!mem.Init(err)) { std::fprintf(stderr, "erro: %s\n", err.c_str()); return 1; }
  dps3::MmioHandler hw;
  mem.SetMmio(&hw);
  hw.Attach(&mem, &disc);
  dps3::Cpu cpu(mem);

  uint32_t entry = 0;
  std::string app_err;
  if (dps3::BootGameCubeApploader(disc, mem, cpu, entry, app_err)) {
    std::printf("\nBoot    : apploader executado na CPU, entry do jogo 0x%08X\n", entry);
  } else {
    std::printf("\nBoot    : apploader falhou (%s)\n          usando o DOL principal direto.\n", app_err.c_str());
    // O apploader pode ter sujado a RAM/CPU: recomeca limpo.
    if (!mem.Init(err)) { std::fprintf(stderr, "erro: %s\n", err.c_str()); return 1; }
    hw.Reset();
    dps3::DolImage dol;
    if (!dps3::BootGameCubeDol(disc, mem, cpu, dol, err)) {
      std::fprintf(stderr, "erro ao carregar o DOL: %s\n", err.c_str());
      return 1;
    }
    std::printf("DOL     : %lu secoes, entry 0x%08X, bss 0x%08X (+0x%X)\n",
                static_cast<unsigned long>(dol.sections.size()), dol.entry, dol.bss_address, dol.bss_size);
  }

  const dps3::StopReason why = dps3::RunSystem(cpu, hw, kMaxBootSteps, GamePadSource);
  std::printf("\nCPU parou: %s\n", dps3::StopReasonName(why));
  std::printf("  passos : %llu\n  pc     : 0x%08X   instr: 0x%08X\n",
              static_cast<unsigned long long>(cpu.steps()), cpu.pc, cpu.last_instr);
  if (why == dps3::StopReason::MemFault)
    std::printf("  endereco acessado: 0x%08X\n", cpu.fault_addr);
  std::printf("  lr=0x%08X ctr=0x%08X cr=0x%08X xer=0x%08X msr=0x%08X\n", cpu.lr, cpu.ctr, cpu.cr, cpu.xer, cpu.msr);
  for (int i = 0; i < 32; i += 4)
    std::printf("  r%-2d=%08X r%-2d=%08X r%-2d=%08X r%-2d=%08X\n", i, cpu.gpr[i], i + 1,
                cpu.gpr[i + 1], i + 2, cpu.gpr[i + 2], i + 3, cpu.gpr[i + 3]);
  std::printf("\nHardware: %llu acessos MMIO, %llu quadros de VI, DVD: %llu leituras / %llu bytes / %llu erros\n"
              "          interrupcoes PI pendentes: 0x%08X\n",
              static_cast<unsigned long long>(hw.mmio_accesses()), static_cast<unsigned long long>(hw.frames()),
              static_cast<unsigned long long>(hw.dvd_reads()), static_cast<unsigned long long>(hw.dvd_bytes()),
              static_cast<unsigned long long>(hw.dvd_errors()), hw.pi_cause());

  std::printf("\n[status V.01] ainda faltam para o jogo aparecer: video GX->RSX, audio DSP\n"
              "  de verdade, mais instrucoes/hardware (veja onde a CPU parou acima).\n");
  return 0;
}

// Procura na pasta DolphinGC a primeira imagem que seja Mario Kart: Double Dash!!. "" se nao achar.
std::string FindMarioKart() {
  for (const std::string& path : ListDiscs(kIsoDir)) {
    dps3::DiscReader d;
    std::string e;
    if (d.Open(path, e) && dps3::IsMarioKartDoubleDash(d.game_id())) return path;
  }
  return "";
}

// Menu de escolha de ISO. Devolve "" se o usuario voltou/cancelou.
std::string ChooseDisc(dps3::Ps3PadState& prev) {
  std::vector<std::string> discs = ListDiscs(kIsoDir);
#ifndef DOLPHINPS3_PLATFORM_PS3
  if (discs.empty()) {
    std::printf("Nenhuma ISO em %s. Digite o caminho de uma ISO (vazio = voltar): ", kIsoDir);
    std::fflush(stdout);
    char line[1024];
    if (!std::fgets(line, sizeof line, stdin)) return "";
    std::string p = line;
    while (!p.empty() && (p.back() == '\n' || p.back() == '\r')) p.pop_back();
    return p;
  }
#else
  if (discs.empty()) {
    std::printf("Nenhuma ISO/GCM em %s. Copie o jogo (ex.: Mario Kart Double Dash) para a pasta DolphinGC e abra de novo.\n", kIsoDir);
    return "";
  }
#endif
  dps3::MenuSystem pick;
  std::vector<dps3::MenuItem> items;
  for (size_t i = 0; i < discs.size(); ++i) {
    const size_t slash = discs[i].rfind('/');
    items.push_back({slash == std::string::npos ? discs[i] : discs[i].substr(slash + 1),
                     static_cast<int>(i)});
  }
  items.push_back({"Voltar", -2});
  pick.SetItems(items, "ESCOLHA O JOGO");
  pick.set_back_action(-2, true);
  for (;;) {
    pick.RenderConsole();
    dps3::MenuInput ev; int direct;
    if (!ReadMenuInput(pick, prev, ev, direct)) return "";
    const int act = direct >= 0 ? pick.SelectOption(direct) : pick.Handle(ev);
    if (act == -2) return "";
    if (act >= 0 && act < static_cast<int>(discs.size())) return discs[act];
  }
}

void ControlsScreen(dps3::ControllerProfile& profile, dps3::Ps3PadState& prev) {
  for (;;) {
    dps3::RenderControlsScreen(profile, stdout);
    dps3::MenuInput ev = dps3::MenuInput::None;
    dps3::Ps3PadState cur;
#ifdef DOLPHINPS3_PLATFORM_PS3
    for (;;) {  // aqui Esquerda/Direita trocam o perfil, entao lemos o pad direto
      if (dps3::PadPoll(cur)) {
        if (cur.circle && !prev.circle) { prev = cur; return; }
        if (cur.dpad_right && !prev.dpad_right) { profile = dps3::NextProfile(profile); prev = cur; break; }
        if (cur.dpad_left && !prev.dpad_left) { profile = dps3::PrevProfile(profile); prev = cur; break; }
        prev = cur;
      }
      usleep(16000);
    }
#else
    (void)prev; (void)cur; (void)ev;
    std::printf("[d] proximo perfil  [a] anterior  [b] voltar > ");
    std::fflush(stdout);
    char line[64];
    if (!std::fgets(line, sizeof line, stdin)) return;
    if (line[0] == 'd') profile = dps3::NextProfile(profile);
    else if (line[0] == 'a') profile = dps3::PrevProfile(profile);
    else if (line[0] == 'b') return;
#endif
  }
}

int RunMenu() {
  dps3::MenuSystem menu;
  menu.Init();
  std::printf("[Menu] Sistema de Menu inicializado com sucesso.\n");
  if (!dps3::PadInit()) {
#ifdef DOLPHINPS3_PLATFORM_PS3
    std::fprintf(stderr, "[Menu] libpad nao inicializou: sem controle nao ha como navegar.\n");
    return 1;
#endif
  }
  dps3::ControllerProfile profile = dps3::ControllerProfile::GameCube;
  dps3::Ps3PadState prev;
  int rc = 0;
  for (;;) {
    menu.RenderConsole();
    dps3::MenuInput ev; int direct;
    if (!ReadMenuInput(menu, prev, ev, direct)) break;  // EOF
    const int act = direct >= 0 ? menu.SelectOption(direct) : menu.Handle(ev);
    if (act < 0) continue;
    if (act == dps3::MENU_ACTION_EXIT) break;
    if (act == dps3::MENU_ACTION_LOAD_MKDD) {
      const std::string path = FindMarioKart();
      if (path.empty())
        std::printf("Mario Kart Double Dash nao encontrado em %s (copie o ISO/GCM para essa pasta).\n", kIsoDir);
      else
        rc = RunTarget(path, false);
    } else if (act == dps3::MENU_ACTION_LOAD_ISO || act == dps3::MENU_ACTION_LIST_FST) {
      const std::string path = ChooseDisc(prev);
      if (!path.empty()) rc = RunTarget(path, act == dps3::MENU_ACTION_LIST_FST);
    } else if (act == dps3::MENU_ACTION_CONTROLS) {
      ControlsScreen(profile, prev);
    } else if (act == dps3::MENU_ACTION_INFO) {
      std::printf("\n%s\nPerfil de controle ativo: %s\n", kVersion, dps3::ProfileName(profile));
    }
  }
  dps3::PadShutdown();
  return rc;
}

}  // namespace

int main(int argc, char** argv) {
#ifdef DOLPHINPS3_PLATFORM_PS3
  RedirectOutputToLog();
#endif
  dps3::LaunchOptions opt;
  std::string err;
  if (!dps3::ParseArgs(CollectArgs(argc, argv), opt, err)) {
    std::fprintf(stderr, "erro: %s\n\n%s", err.c_str(), dps3::UsageText());
    return 2;
  }
  if (opt.show_help) { std::fputs(dps3::UsageText(), stdout); return 0; }
  if (opt.show_version) { std::printf("%s\n", kVersion); return 0; }

  EnsureGameDir();
  std::printf("%s\n", kVersion);

  // Prioridade do alvo de boot: --exec, depois primeiro FILE posicional.
  std::string target = !opt.exec_file.empty() ? opt.exec_file
                       : (!opt.files.empty() ? opt.files[0] : std::string());
  if (target.empty()) return RunMenu();  // sem disco informado: abre o menu
  return RunTarget(target, opt.list_files);
}
