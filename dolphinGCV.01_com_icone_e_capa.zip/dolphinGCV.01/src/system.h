// DolphinGC V.01 - laco principal: CPU + relogio de hardware (retrace, interrupcoes, controle).
#pragma once
#include <cstdint>

#include "cpu.h"
#include "input.h"
#include "mmio.h"

namespace dps3 {

// Fonte do controle (PS3: libpad -> GameCube). Devolve false se nao ha controle conectado.
typedef bool (*PadSource)(GameCubePadState& out);

// Roda a CPU em blocos; entre blocos avanca o hardware (VI/retrace), entrega interrupcoes
// externas (0x500) e atualiza o controle. Para na primeira condicao de parada da CPU.
StopReason RunSystem(Cpu& cpu, MmioHandler& hw, uint64_t max_steps, PadSource pad = nullptr);

}  // namespace dps3
