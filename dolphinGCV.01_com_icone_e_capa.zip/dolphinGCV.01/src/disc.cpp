#include "disc.h"

#include <cstring>
#include <limits>
#include <sys/types.h>

namespace dps3 {
namespace {

uint32_t BE32(const uint8_t* p) {
  return (uint32_t(p[0]) << 24) | (uint32_t(p[1]) << 16) | (uint32_t(p[2]) << 8) | p[3];
}

// Offsets do header de disco GC (o magic Wii e so reconhecido para recusar com erro claro) (campos big-endian):
// 0x00 game ID (4) + 0x04 maker (2), 0x06 disc number, 0x07 version,
// 0x18 magic Wii 0x5D1C9EA3, 0x1C magic GC 0xC2339F3D, 0x20 titulo (64 bytes).
constexpr uint32_t kWiiMagic = 0x5D1C9EA3u;
constexpr uint32_t kGcMagic = 0xC2339F3Du;
constexpr size_t kHeaderProbe = 0x60;

bool IsPrintable(char c) { return c >= 0x20 && c < 0x7F; }

}  // namespace

DiscReader::~DiscReader() { Close(); }

void DiscReader::Close() {
  if (f_) std::fclose(f_);
  f_ = nullptr;
  size_ = 0;
  kind_ = DiscKind::Unknown;
  game_id_.clear();
  title_.clear();
  disc_number_ = 0;
  version_ = 0;
}

bool DiscReader::Read(uint64_t offset, void* dst, size_t len) {
  if (!f_) return false;
  if (offset > size_ || static_cast<uint64_t>(len) > size_ - offset) return false;
  if (len == 0) return true;
  if (!dst) return false;
  if (offset > static_cast<uint64_t>(std::numeric_limits<off_t>::max())) return false;
  if (fseeko(f_, static_cast<off_t>(offset), SEEK_SET) != 0) return false;
  return std::fread(dst, 1, len, f_) == len;
}

bool DiscReader::Open(const std::string& path, std::string& err) {
  Close();
  f_ = std::fopen(path.c_str(), "rb");
  if (!f_) { err = "nao foi possivel abrir: " + path; return false; }
  if (fseeko(f_, 0, SEEK_END) != 0) { err = "seek falhou"; Close(); return false; }
  const off_t end = ftello(f_);
  if (end < 0) { err = "ftello falhou"; Close(); return false; }
  size_ = static_cast<uint64_t>(end);

  uint8_t h[kHeaderProbe];
  if (size_ < kHeaderProbe || !Read(0, h, sizeof h)) {
    err = "arquivo menor que o header minimo de disco";
    Close();
    return false;
  }

  // Containers comprimidos: reconhecer para dar erro claro, sem decodificar.
  if (std::memcmp(h, "RVZ\x01", 4) == 0 || std::memcmp(h, "WIA\x01", 4) == 0) {
    err = "container RVZ/WIA ainda nao suportado (converta para ISO com dolphin-tool no PC)";
    Close();
    return false;
  }
  // GCZ: magic 0xB10BC001 gravado em little-endian. Confirmar contra o fonte do Dolphin.
  if (h[0] == 0x01 && h[1] == 0xC0 && h[2] == 0x0B && h[3] == 0xB1) {
    err = "container GCZ ainda nao suportado (converta para ISO)";
    Close();
    return false;
  }

  if (BE32(h + 0x18) == kWiiMagic) {
    err = "disco Wii recusado: o DolphinGC V.01 e somente GameCube";
    Close();
    return false;
  }
  if (BE32(h + 0x1C) == kGcMagic) kind_ = DiscKind::GameCube;
  else {
    err = "magic de GameCube nao encontrado (nao e um ISO de GameCube valido ou esta embaralhado)";
    Close();
    return false;
  }

  game_id_.assign(reinterpret_cast<char*>(h), 6);
  for (char c : game_id_) {
    if (!IsPrintable(c)) { err = "Game ID invalido"; Close(); return false; }
  }
  disc_number_ = h[6];
  version_ = h[7];
  title_.assign(reinterpret_cast<char*>(h + 0x20), 64);
  title_.resize(std::strlen(title_.c_str()));
  return true;
}

const char* KindName(DiscKind k) {
  switch (k) {
    case DiscKind::GameCube: return "GameCube";
    default: return "Desconhecido";
  }
}

}  // namespace dps3

namespace dps3 {

// Mario Kart: Double Dash!! -> IDs GM4E (EUA), GM4P (Europa), GM4J (Japao); o 4o char e a regiao.
bool IsMarioKartDoubleDash(const std::string& game_id) {
  return game_id.size() >= 4 && game_id.compare(0, 3, "GM4") == 0 &&
         (game_id[3] == 'E' || game_id[3] == 'P' || game_id[3] == 'J');
}

}  // namespace dps3
