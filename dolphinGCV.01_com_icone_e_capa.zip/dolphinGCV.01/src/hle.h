// DolphinGC V.01 - fase 9: HLE (High-Level Emulation) de rotinas do OS (OSInit, OSLink, etc.)
#pragma once
#include <cstdint>
#include <string>

namespace dps3 {

class Memory;
class Cpu;

// ATENCAO: NAO esta ligado ao boot. Os enderecos 0x8000xxxx usados em hle.cpp sao FICTICIOS
// (nao correspondem a funcoes reais do SDK); ligar isto a um jogo real corromperia o codigo dele.
class HleManager {
public:
  // Verifica se o PC atual corresponde a um endereço de stub HLE e executa a rotina simulada
  bool CheckAndExecute(uint32_t pc, Cpu& cpu, Memory& mem);

  // Regista pontos de intercepção para funções conhecidas da SDK do GameCube
  void RegisterStubs();
};

} // namespace dps3
