// Testes da FST do GameCube.
//   [SIM]  : imagens SINTETICAS geradas aqui. Validam a logica do parser, NAO
//            provam compatibilidade com discos reais.
//   [REAL] : so roda se DPS3_TEST_ISO apontar para uma ISO GameCube valida.
#include "disc.h"
#include "fst.h"

#include <cstdint>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <string>
#include <vector>

namespace {

int g_pass = 0, g_fail = 0;

#define CHECK(c)                                                         \
  do {                                                                   \
    if (c) { ++g_pass; }                                                 \
    else { ++g_fail; std::printf("    FAIL %s:%d: %s\n", __FILE__, __LINE__, #c); } \
  } while (0)

const char* kPath = "/tmp/dps3_fst_test.iso";

struct N { uint32_t flags_name, a, b; };

void Put32(std::vector<uint8_t>& v, size_t off, uint32_t x) {
  if (off + 4 > v.size()) return;
  v[off] = uint8_t(x >> 24); v[off + 1] = uint8_t(x >> 16);
  v[off + 2] = uint8_t(x >> 8); v[off + 3] = uint8_t(x);
}

struct Img {
  std::vector<N> nodes;
  std::string strs = std::string(1, '\0');  // offset 0 = string vazia (raiz)
  uint32_t fst_off = 0x500;       // onde os bytes da FST sao gravados
  bool field_override = false;
  uint32_t fst_off_field = 0;     // valor gravado em 0x424 (se field_override)
  bool size_override = false;
  uint32_t fst_size_value = 0;
  uint32_t fst_max = 0;
  size_t total = 0x4000;
  bool wii = false;

  uint32_t Name(const char* s) {
    const uint32_t o = uint32_t(strs.size());
    strs.append(s);
    strs.push_back('\0');
    return o;
  }
  void Add(uint8_t type, const char* name, uint32_t a, uint32_t b) {
    const uint32_t n = Name(name);
    nodes.push_back(N{(uint32_t(type) << 24) | n, a, b});
  }
};

// Arvore valida (indice: tipo nome pai/offset next/size):
// 0 raiz | 1 dir1 | 2 dir1/a.txt | 3 dir1/sub | 4 dir1/sub/b.bin |
// 5 empty (dir vazio) | 6 zero.dat (arquivo vazio) | 7 root.txt
Img Valid() {
  Img i;
  i.nodes.push_back(N{1u << 24, 0, 8});
  i.Add(1, "dir1", 0, 5);
  i.Add(0, "a.txt", 0x2000, 16);
  i.Add(1, "sub", 1, 5);
  i.Add(0, "b.bin", 0x2010, 8);
  i.Add(1, "empty", 0, 6);
  i.Add(0, "zero.dat", 0x2018, 0);
  i.Add(0, "root.txt", 0x2000, 4);
  return i;
}

bool Write(const Img& im, const char* path) {
  std::vector<uint8_t> v(im.total, 0);
  std::memcpy(v.data(), "GTEST0", 6);
  Put32(v, im.wii ? 0x18 : 0x1C, im.wii ? 0x5D1C9EA3u : 0xC2339F3Du);

  const size_t fst_bytes = im.nodes.size() * 12 + im.strs.size();
  Put32(v, 0x424, im.field_override ? im.fst_off_field : im.fst_off);
  Put32(v, 0x428, im.size_override ? im.fst_size_value : uint32_t(fst_bytes));
  Put32(v, 0x42C, im.fst_max);

  std::vector<uint8_t> f(fst_bytes, 0);
  for (size_t k = 0; k < im.nodes.size(); ++k) {
    Put32(f, k * 12, im.nodes[k].flags_name);
    Put32(f, k * 12 + 4, im.nodes[k].a);
    Put32(f, k * 12 + 8, im.nodes[k].b);
  }
  if (!im.strs.empty()) std::memcpy(f.data() + im.nodes.size() * 12, im.strs.data(), im.strs.size());
  for (size_t k = 0; k < f.size(); ++k)
    if (size_t(im.fst_off) + k < v.size()) v[size_t(im.fst_off) + k] = f[k];

  for (size_t k = 0; k < 0x40; ++k)
    if (0x2000 + k < v.size()) v[0x2000 + k] = uint8_t(0xA0 + k);

  std::FILE* fp = std::fopen(path, "wb");
  if (!fp) return false;
  const bool ok = std::fwrite(v.data(), 1, v.size(), fp) == v.size();
  std::fclose(fp);
  return ok;
}

bool OpenImg(const Img& im, dps3::DiscReader& d) {
  std::string err;
  return Write(im, kPath) && d.Open(kPath, err);
}

void ExpectFail(const char* name, const Img& im) {
  dps3::DiscReader d;
  dps3::GameCubeFst fst;
  std::string err;
  const bool opened = OpenImg(im, d);
  const bool loaded = opened && fst.Load(d, err);
  CHECK(opened);
  CHECK(!loaded);
  CHECK(fst.entries().empty());  // falha nao pode deixar estado parcial
  std::printf("  [SIM] %-34s -> %s\n", name, err.c_str());
}

void TestValidTree() {
  std::printf("[SIM] arvore valida\n");
  dps3::DiscReader d;
  dps3::GameCubeFst fst;
  std::string err;
  CHECK(OpenImg(Valid(), d));
  CHECK(fst.Load(d, err));
  CHECK(fst.entries().size() == 8);
  if (fst.entries().size() != 8) return;

  const char* paths[8] = {"", "dir1", "dir1/a.txt", "dir1/sub", "dir1/sub/b.bin",
                          "empty", "zero.dat", "root.txt"};
  for (uint32_t i = 0; i < 8; ++i) CHECK(fst.Get(i)->path == paths[i]);
  CHECK(fst.Get(8) == nullptr);

  CHECK(fst.Get(2)->parent_index == 1);
  CHECK(fst.Get(4)->parent_index == 3);
  CHECK(fst.Get(5)->type == dps3::FstEntryType::Directory);
  CHECK(fst.Get(5)->next_index == 6);          // diretorio vazio
  CHECK(fst.Get(6)->size == 0);                // arquivo vazio
  CHECK(fst.Get(7)->parent_index == 0);        // volta a raiz apos dirs aninhados
  CHECK(fst.Get(1)->next_index == 5);

  // leitura inteira
  std::vector<uint8_t> out;
  CHECK(fst.ReadFile(d, 2, out, err));
  CHECK(out.size() == 16);
  for (size_t k = 0; k < out.size(); ++k) CHECK(out[k] == uint8_t(0xA0 + k));
  CHECK(fst.ReadFile(d, 4, out, err));
  CHECK(out.size() == 8 && out[0] == 0xB0);
  CHECK(fst.ReadFile(d, 6, out, err));  // arquivo vazio
  CHECK(out.empty());

  // leitura por blocos de 3 bytes reconstitui o arquivo
  std::vector<uint8_t> acc;
  for (uint64_t off = 0; off < 16; off += 3) {
    uint8_t buf[3];
    const size_t n = (16 - off) < 3 ? size_t(16 - off) : 3;
    CHECK(fst.ReadFileChunk(d, 2, off, buf, n, err));
    acc.insert(acc.end(), buf, buf + n);
  }
  CHECK(acc.size() == 16);
  for (size_t k = 0; k < acc.size() && k < 16; ++k) CHECK(acc[k] == uint8_t(0xA0 + k));

  // limites e erros de leitura
  uint8_t b[32];
  CHECK(fst.ReadFileChunk(d, 2, 16, b, 0, err));    // fim exato, len 0
  CHECK(!fst.ReadFileChunk(d, 2, 16, b, 1, err));   // alem do fim
  CHECK(!fst.ReadFileChunk(d, 2, 8, b, 9, err));    // atravessa o fim
  CHECK(!fst.ReadFileChunk(d, 2, 17, b, 0, err));   // offset > size
  CHECK(!fst.ReadFileChunk(d, 2, UINT64_MAX, b, 1, err));
  CHECK(!fst.ReadFileChunk(d, 2, 0, nullptr, 4, err));
  CHECK(!fst.ReadFileChunk(d, 1, 0, b, 1, err));    // diretorio
  CHECK(!fst.ReadFileChunk(d, 99, 0, b, 1, err));   // indice inexistente
  CHECK(!fst.ReadFile(d, 0, out, err));
  CHECK(out.empty());
}

void TestOtherValid() {
  std::printf("[SIM] outras FSTs validas\n");
  std::string err;
  {  // somente raiz, sem tabela de strings
    Img im;
    im.nodes.push_back(N{1u << 24, 0, 1});
    im.strs.clear();
    dps3::DiscReader d; dps3::GameCubeFst fst;
    CHECK(OpenImg(im, d));
    CHECK(fst.Load(d, err));
    CHECK(fst.entries().size() == 1);
  }
  {  // fst_max_size exatamente igual ao tamanho
    Img im = Valid();
    im.fst_max = uint32_t(im.nodes.size() * 12 + im.strs.size());
    dps3::DiscReader d; dps3::GameCubeFst fst;
    CHECK(OpenImg(im, d));
    CHECK(fst.Load(d, err));
  }
  {  // 100 diretorios aninhados + 1 arquivo
    const uint32_t depth = 100;
    Img im;
    im.nodes.push_back(N{1u << 24, 0, depth + 2});
    for (uint32_t k = 1; k <= depth; ++k) im.Add(1, "d", k - 1, depth + 2);
    im.Add(0, "f", 0x2000, 4);
    dps3::DiscReader d; dps3::GameCubeFst fst;
    CHECK(OpenImg(im, d));
    CHECK(fst.Load(d, err));
    CHECK(fst.entries().size() == depth + 2);
    std::string expect;
    for (uint32_t k = 0; k < depth; ++k) expect += "d/";
    expect += "f";
    if (fst.entries().size() == depth + 2) CHECK(fst.entries().back().path == expect);
  }
}

void TestInvalid() {
  std::printf("[SIM] FSTs invalidas (todas devem falhar)\n");
  Img im;

  im = Valid(); im.nodes[2].a = 0x10000;               ExpectFail("offset de arquivo fora da ISO", im);
  im = Valid(); im.nodes[2].b = 0x10000;               ExpectFail("tamanho de arquivo fora da ISO", im);
  im = Valid(); im.nodes[2].a = 0x3FF0; im.nodes[2].b = 0x100; ExpectFail("offset+size passa do fim", im);
  im = Valid(); im.nodes[2].a = 0xFFFFFFF0u; im.nodes[2].b = 0x20; ExpectFail("offset+size estoura 32 bits", im);
  im = Valid(); im.nodes[0].a = 1;                     ExpectFail("raiz com pai != 0", im);
  im = Valid(); im.nodes[0].flags_name = 0;            ExpectFail("raiz como arquivo", im);
  im = Valid(); im.nodes[0].b = 9;                     ExpectFail("raiz com contagem > nos reais", im);
  im = Valid(); im.nodes[0].b = 0;                     ExpectFail("raiz com contagem 0", im);
  im = Valid(); im.nodes[3].b = 6;                     ExpectFail("next do filho > next do pai", im);
  im = Valid(); im.nodes[3].a = 0;                     ExpectFail("indice pai de diretorio errado", im);
  im = Valid(); im.nodes[1].b = 1;                     ExpectFail("next <= proprio indice", im);
  im = Valid(); im.nodes[5].b = 99;                    ExpectFail("next > numero de nos", im);
  im = Valid(); im.nodes[2].flags_name = (2u << 24) | (im.nodes[2].flags_name & 0xFFFFFF);
                                                       ExpectFail("tipo de no desconhecido", im);
  im = Valid(); im.nodes[2].flags_name = (im.nodes[2].flags_name & 0xFF000000u) | 0xFFFFFF;
                                                       ExpectFail("offset de nome fora da tabela", im);
  im = Valid(); im.strs.pop_back();                    ExpectFail("string sem terminador", im);
  im = Valid(); im.fst_max = 10;                       ExpectFail("fst_size > fst_max_size", im);
  im = Valid(); im.size_override = true; im.fst_size_value = 8;
                                                       ExpectFail("fst_size < 12", im);
  im = Valid(); im.size_override = true; im.fst_size_value = 36;
                                                       ExpectFail("FST truncada (36 bytes, 8 nos)", im);
  im = Valid(); im.size_override = true; im.fst_size_value = 0x10000000u;
                                                       ExpectFail("fst_size gigante", im);
  im = Valid(); im.field_override = true; im.fst_off_field = 0; ExpectFail("fst_offset 0", im);
  im = Valid(); im.fst_off = 0x10000;                  ExpectFail("fst_offset fora da ISO", im);
  im = Valid(); im.fst_off = 0x3FF0;                   ExpectFail("FST passa do fim da ISO", im);
  im = Valid(); im.total = 0x520;                      ExpectFail("ISO truncada no meio da FST", im);
  {  // disco Wii: agora recusado ja na abertura (DolphinGC V.01 e so GameCube)
    im = Valid(); im.wii = true;
    dps3::DiscReader d; std::string e;
    CHECK(!OpenImg(im, d));
    std::printf("  [SIM] %-34s -> abertura recusada\n", "disco Wii recusado");
  }
}

void TestDiscRead() {
  std::printf("[SIM] DiscReader::Read\n");
  dps3::DiscReader d;
  CHECK(OpenImg(Valid(), d));
  uint8_t b[4];
  const uint64_t sz = d.size();
  CHECK(sz == 0x4000);
  CHECK(d.Read(0, nullptr, 0));
  CHECK(d.Read(sz, b, 0));
  CHECK(!d.Read(sz, b, 1));
  CHECK(!d.Read(sz - 1, b, 2));
  CHECK(!d.Read(UINT64_MAX, b, 1));
  CHECK(!d.Read(0, nullptr, 1));
  CHECK(d.Read(0x2000, b, 4) && b[0] == 0xA0);
  d.Close();
  CHECK(!d.Read(0, b, 1));  // fechado
  std::string err;
  Img small; small.total = 0x100;  // header de disco ok (0x60), mas sem boot.bin completo (0x430)
  CHECK(Write(small, kPath));
  CHECK(d.Open(kPath, err));
  dps3::GameCubeFst fst;
  CHECK(!fst.Load(d, err));
  std::printf("  [SIM] disco sem boot.bin completo        -> %s\n", err.c_str());
  Img tiny; tiny.total = 0x40;     // menor que o header minimo
  CHECK(Write(tiny, kPath));
  CHECK(!d.Open(kPath, err));
  std::printf("  [SIM] arquivo menor que o header         -> %s\n", err.c_str());
  CHECK(!d.Open("/tmp/dps3_nao_existe.iso", err));
  CHECK(d.size() == 0 && d.kind() == dps3::DiscKind::Unknown);
}

int RunReal(const char* iso) {
  std::printf("[REAL] %s\n", iso);
  dps3::DiscReader d;
  dps3::GameCubeFst fst;
  std::string err;
  if (!d.Open(iso, err)) { std::printf("  FAIL abrir: %s\n", err.c_str()); return 1; }
  std::printf("  console=%s id=%s tamanho=%llu\n", dps3::KindName(d.kind()),
              d.game_id().c_str(), static_cast<unsigned long long>(d.size()));
  if (d.kind() != dps3::DiscKind::GameCube) { std::printf("  FAIL: nao e GameCube\n"); return 1; }
  if (!fst.Load(d, err)) { std::printf("  FAIL FST: %s\n", err.c_str()); return 1; }
  size_t files = 0, dirs = 0, bad = 0;
  for (const dps3::FstEntry& e : fst.entries()) {
    if (e.type == dps3::FstEntryType::Directory) { ++dirs; continue; }
    ++files;
    uint8_t first = 0, last = 0;
    if (e.size > 0) {
      if (!fst.ReadFileChunk(d, e.index, 0, &first, 1, err) ||
          !fst.ReadFileChunk(d, e.index, e.size - 1, &last, 1, err)) {
        ++bad;
        std::printf("  FAIL leitura: %s (%s)\n", e.path.c_str(), err.c_str());
      }
    }
  }
  std::printf("  diretorios=%zu arquivos=%zu falhas_de_leitura=%zu\n", dirs, files, bad);
  return bad ? 1 : 0;
}

}  // namespace

int main() {
  TestValidTree();
  TestOtherValid();
  TestInvalid();
  TestDiscRead();
  std::remove(kPath);

  std::printf("\n[SIM] resultado: %d checks ok, %d falhas\n", g_pass, g_fail);

  int real_rc = 0;
  const char* iso = std::getenv("DPS3_TEST_ISO");
  if (iso && *iso) {
    real_rc = RunReal(iso);
    std::printf("[REAL] %s\n", real_rc == 0 ? "OK" : "FALHOU");
  } else {
    std::printf("[REAL] NAO EXECUTADO: DPS3_TEST_ISO nao definido (nenhuma ISO real disponivel)\n");
  }
  return (g_fail || real_rc) ? 1 : 0;
}
