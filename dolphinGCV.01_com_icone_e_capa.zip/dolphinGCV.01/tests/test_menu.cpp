#include "check.h"
#include "menu.h"

#include <cstdio>

int g_pass = 0, g_fail = 0;

namespace {
using namespace dps3;

void TestNavigation() {
  std::printf("[SIM] menu: navegacao, selecao direta e volta\n");
  MenuSystem m;
  CHECK(m.Init());
  CHECK(m.items().size() == 6);
  CHECK(m.selected() == 0);
  CHECK(m.Handle(MenuInput::Confirm) == MENU_ACTION_LOAD_MKDD);  // 1o item: Mario Kart
  CHECK(m.Handle(MenuInput::Up) == -1 && m.selected() == 5);   // da a volta para cima
  CHECK(m.Handle(MenuInput::Confirm) == MENU_ACTION_EXIT);
  CHECK(m.Handle(MenuInput::Down) == -1 && m.selected() == 0); // da a volta para baixo
  m.Handle(MenuInput::Down); m.Handle(MenuInput::Down); m.Handle(MenuInput::Down);
  CHECK(m.Handle(MenuInput::Confirm) == MENU_ACTION_CONTROLS);
  CHECK(m.Handle(MenuInput::None) == -1);
  CHECK(m.Handle(MenuInput::Back) == -1);                      // menu principal nao tem "voltar"
  CHECK(m.SelectOption(0) == MENU_ACTION_LOAD_MKDD);
  CHECK(m.SelectOption(1) == MENU_ACTION_LOAD_ISO);
  CHECK(m.SelectOption(5) == MENU_ACTION_EXIT);
  CHECK(m.SelectOption(6) == -1 && m.SelectOption(-1) == -1);

  m.SetItems({{"a", 10}, {"Voltar", -2}}, "sub");
  m.set_back_action(-2, true);
  CHECK(m.selected() == 0 && m.Handle(MenuInput::Back) == -2);

  MenuSystem empty;
  CHECK(empty.Handle(MenuInput::Down) == -1 && empty.Handle(MenuInput::Confirm) == -1);
}

void TestPadEdges() {
  std::printf("[SIM] menu: eventos do pad so na borda\n");
  Ps3PadState a, b;
  CHECK(MenuInputFromPad(a, b) == MenuInput::None);
  b.dpad_down = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Down);
  CHECK(MenuInputFromPad(b, b) == MenuInput::None);            // segurando nao repete
  b = Ps3PadState(); b.dpad_up = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Up);
  b = Ps3PadState(); b.left_stick_y = 255;                      // analogico para baixo
  CHECK(MenuInputFromPad(a, b) == MenuInput::Down);
  b = Ps3PadState(); b.left_stick_y = 0;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Up);
  b = Ps3PadState(); b.cross = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Confirm);
  b = Ps3PadState(); b.start = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Confirm);
  b = Ps3PadState(); b.circle = true;
  CHECK(MenuInputFromPad(a, b) == MenuInput::Back);
}

void TestProfiles() {
  std::printf("[SIM] menu: perfil unico (GameCube)\n");
  ControllerProfile p = ControllerProfile::GameCube;
  CHECK(NextProfile(p) == ControllerProfile::GameCube);
  CHECK(PrevProfile(p) == ControllerProfile::GameCube);
}

}  // namespace

int main() {
  TestNavigation();
  TestPadEdges();
  TestProfiles();
  std::printf("\n[SIM] test_menu: %d checks ok, %d falhas\n", g_pass, g_fail);
  return g_fail ? 1 : 0;
}
