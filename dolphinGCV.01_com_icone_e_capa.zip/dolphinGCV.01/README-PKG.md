# DolphinGC V.01 - emulador de GameCube para PS3

> **Status honesto:** este projeto ainda **nao roda jogos**. Nada aqui foi testado num PS3 nem com o
> PSL1GHT real (so no PC, com testes automaticos). O alvo do V.01 e **Mario Kart: Double Dash!!**,
> mas ele ainda nao chega na tela. Veja "O que ainda falta" abaixo.

Esta versao e **somente GameCube**: o suporte a Wii (Wiimote, Nunchuk, Classic, discos Wii) foi removido.
Discos Wii e arquivos RVZ/WIA/GCZ sao recusados com mensagem clara.

## Pasta dos jogos: `DolphinGC`
- **PS3:** `/dev_hdd0/DolphinGC/`  (o app cria a pasta sozinho ao abrir)
- **PC (testes):** `./DolphinGC/` ao lado do programa (ja vem uma pasta aqui no zip)
- Coloque la o ISO/GCM. Para o Mario Kart Double Dash o menu tem um item direto:
  **"Rodar Mario Kart Double Dash"** (acha sozinho os IDs `GM4E`, `GM4P` ou `GM4J`).

## Compilar (PS3)
```
export PS3DEV=/usr/local/ps3dev ; export PSL1GHT=$PS3DEV
export PATH=$PATH:$PS3DEV/bin:$PS3DEV/ppu/bin:$PS3DEV/spu/bin
make          # gera dolphinGCV.01.elf
make pkg      # gera dolphinGCV.01.pkg (ID do app: DGCV00001)
```
Se `make pkg` falhar, use os passos manuais do `Makefile` (sfo.py / pkg.py) ajustando os nomes das ferramentas.

## Usar no PS3
1. Instale o `.pkg` e copie o jogo para `/dev_hdd0/DolphinGC/`.
2. Abra o app: D-Pad ou analogico esquerdo navega, **X/Start** confirma, **Bolinha** volta.
3. Alternativa sem menu: `/dev_hdd0/game/DGCV00001/USRDIR/args.txt` com o caminho da ISO.
4. A saida vai para `/dev_hdd0/game/DGCV00001/USRDIR/log.txt` (ainda nao ha video na TV).

## Testar no PC
```
make -f Makefile.host all     # build/dolphinGCV.01_host (menu no terminal)
make -f Makefile.host test    # 13 suites de teste
make -f Makefile.host bench   # mede passos/segundo do interpretador
make -f Makefile.host asan    # mesmos testes com AddressSanitizer
```

## O que ja existe (ate agora)
- **Boot pelo apploader real:** o app carrega o apploader do disco (0x2440), executa ele na CPU emulada
  (`entry -> init -> main -> close`) e deixa ele copiar o jogo para a RAM. Se o apploader falhar, cai no
  boot direto do DOL e mostra o motivo. Testado com um apploader sintetico (`tests/test_apploader.cpp`);
  **nao foi testado com o apploader do Mario Kart**.
- **Hardware simplificado ligado a memoria** (`src/mmio.*`): leitura de disco por DMA (DI) com
  interrupcao, controle (SI) alimentado pelo pad do PS3, retrace de video e interrupcoes (VI/PI),
  mailbox do DSP. Antes disso, qualquer acesso a 0xCC00xxxx falhava na hora.
- **Laco do sistema** (`src/system.*`): avanca o relogio, entrega interrupcoes externas e le o controle.
- **CPU ~2,4x mais rapida** no PC (79 -> ~193 milhoes de instrucoes/s no `make -f Makefile.host bench`).
  No PS3 real a velocidade sera bem menor; ainda nao foi medida la.
- O `hle.cpp` NAO esta ligado: os enderecos dele sao ficticios.

## O que ainda falta para o Mario Kart Double Dash aparecer
1. Rodar com o ISO real e corrigir o que parar primeiro (instrucoes da CPU ainda nao implementadas,
   registradores de hardware que o jogo espera). O log mostra pc, instrucao e acessos MMIO.
2. Video: traduzir o FIFO do GX para RSX (hoje `gx.cpp` so imprime os comandos).
3. Audio: DSP e AI de verdade (hoje so o mailbox inicial).
4. Fidelidade: o hardware atual e simplificado (nao ciclo-exato); jogos podem exigir mais detalhes.
5. Desempenho no PS3: provavelmente precisara de otimizacao pesada ou recompilador dinamico.

## Controles (PS3 -> GameCube)
Veja `config/mapeamento_botoes.txt` (o menu mostra o mesmo texto).

## Arquivos
`Makefile` (PS3), `Makefile.host` (PC), `sfo.xml`, `ICON0.PNG` (capa personalizada 320x176), `src/`, `tests/`, `config/`, `DolphinGC/`.
